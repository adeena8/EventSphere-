# EventSphere Management — MERN

Expo & trade-show management platform built with **MongoDB · Express · React · Node.js**.

```
eventmanagement/
├── backend/          Express REST API + Socket.IO + MongoDB (Mongoose)
│   ├── src/
│   │   ├── config/       env + MongoDB connection
│   │   ├── models/       User, Expo, Booth, ExhibitorApplication, Session, Registration,
│   │   │                 Message, Notification, Feedback, BoothVisit, GalleryItem, Activity
│   │   ├── controllers/  auth, expos, booths, applications, sessions, messages, analytics, misc
│   │   ├── routes/       all /api routes (role-protected)
│   │   ├── middleware/   JWT auth + RBAC, sanitising, rate limits, uploads, errors
│   │   ├── services/     socket.io, notifications, mailer, reminders, backups, logger
│   │   └── seed/         demo data
│   ├── scripts/          backup / restore
│   ├── tests/            integration tests (in-memory MongoDB)
│   ├── uploads/  logs/  backups/
│   └── .env              ← configure MONGO_URI here
└── frontend/         React 18 + Vite + React Router + Framer Motion + Lenis
    ├── public/           hero video + poster
    └── src/
        ├── pages/            public pages, auth pages, dashboard/*
        ├── components/       layout, motion (parallax), ui, FloorPlan, cards
        ├── context/          Auth, Socket (real-time), Toast
        └── styles/           base, home (parallax), app (dashboard)
```

---

## 1. Requirements

- **Node.js 18+** (20 LTS recommended)
- **MongoDB** — either
  - local: [MongoDB Community Server](https://www.mongodb.com/try/download/community) (runs on `mongodb://127.0.0.1:27017`), or
  - cloud: a free [MongoDB Atlas](https://www.mongodb.com/atlas) cluster (copy its connection string)

## 2. Setup

```bash
cd eventmanagement

# install root + backend + frontend packages
npm run install:all

# configure the database (already created with safe defaults)
#   backend/.env  →  MONGO_URI=mongodb://127.0.0.1:27017/eventsphere
#   (for Atlas paste your mongodb+srv://… string instead)

# fill MongoDB with demo data
npm run seed

# start API (http://localhost:5000) + React app (http://localhost:5173)
npm run dev
```

Open **http://localhost:5173**.

> Running separately: `cd backend && npm run dev` and in another terminal `cd frontend && npm run dev`.

### Demo accounts (after `npm run seed`)

| Role      | Email                         | Password        |
|-----------|-------------------------------|-----------------|
| Admin     | admin@eventsphere.com         | Admin@123       |
| Organizer | organizer@eventsphere.com     | Organizer@123   |
| Exhibitor | techvision@eventsphere.com    | Exhibitor@123   |
| Attendee  | ali@eventsphere.com           | Attendee@123    |

More: `cloudnest@`, `nova@`, `greenleaf@`, `artisan@`, `medicore@`, `pixelcraft@` (Exhibitor@123) ·
`sara@`, `ahmed@`, `fatima@`, `bilal@` (Attendee@123) · `organizer2@` · `pending@` (organizer awaiting approval).

### Production

```bash
npm start      # builds the React app, then serves it + the API from Express on PORT (5000)
```
Set `NODE_ENV=production`, a strong `JWT_SECRET`, your `ENCRYPTION_KEY`, `CLIENT_URL` and SMTP settings in `backend/.env`.
Put the app behind HTTPS (Nginx / a PaaS) so all traffic is encrypted in transit.

---

## 3. Requirement → implementation map

### User authentication
| Requirement | Where |
|---|---|
| Register / login for organizers, exhibitors, attendees | `POST /api/auth/register`, `/login` · Register page has a role picker |
| Role differentiation | `User.role` = admin · organizer · exhibitor · attendee; organizer sign-ups wait for admin approval |
| Forgot / reset password | `/forgot-password` → emailed link (shown on screen in dev when SMTP is not set) → `/reset-password/:token` (30 min, hashed token) |
| Password encryption | bcrypt (12 rounds) |

### Admin / Organizer dashboard
| Requirement | Where |
|---|---|
| Create / edit / delete expos (title, dates, location, description, theme…) | Dashboard → **Expos** |
| Allocate booth spaces on the floor plan | Dashboard → **Floor plans** (grid generator, edit size/price, block, assign/unassign) |
| View / approve / reject exhibitor applications, assign booths | Dashboard → **Exhibitor applications** (documents, floor-plan booth picker, notes) |
| Schedules: time slots, sessions, speakers, topics, locations, updates | Dashboard → **Schedules** (room double-booking prevented, attendees notified of changes) |
| Reports on attendee engagement, booth traffic, session popularity | Dashboard → **Analytics** (+ CSV export) |
| Real-time analytics | Socket.IO pushes `analytics:update` on every registration, check-in, booth visit and seat booking |
| Extra | QR ticket **check-in**, **announcements** broadcast, **feedback inbox**, admin **users**, **system & backups** with activity log |

### Exhibitor portal
| Requirement | Where |
|---|---|
| Register for expos with company details, products, documents | “Apply to exhibit” (expo page or Dashboard → Applications) — up to 5 PDF/DOC/image files |
| Update profile: logo, description, contact info | Dashboard → **Company profile** |
| View available booths, select & reserve | Interactive floor plan inside the application form — booth is held (*reserved*) until reviewed |
| Manage booth: products showcased, staff | Dashboard → **My booths** |
| Contact organizers / neighbouring exhibitors | **Messages** (real-time chat) + “Neighbouring exhibitors” list on each booth |

### Attendee interface
| Requirement | Where |
|---|---|
| Event details, schedule, exhibitor list, floor plan | Expo page tabs: Overview · Schedule · Exhibitors · Floor plan |
| Register for events / sessions / workshops | “Register — free” (QR ticket) + “Reserve seat” per session (capacity enforced atomically) |
| Search & filter exhibitors by category, product, keyword | Exhibitors tab and `/exhibitors` directory |
| View exhibitor profile + booth location | `/exhibitors/:id` with highlighted booth on the floor plan |
| Contact exhibitors | “Send a message” → real-time chat |
| Browse schedules, bookmark, reminders | ★ bookmark; a cron job sends a notification 30 min before bookmarked/reserved sessions |

### General
| Requirement | Where |
|---|---|
| Real-time updates (schedules, booths, event details) | Socket.IO rooms per expo; pages refresh live and show a “updated live” banner |
| Feedback & support | `/contact` (guests) and Dashboard → **Support** (ratings, suggestions, issues) |

### Non-functional
| Requirement | How |
|---|---|
| Performance | Indexed queries, lean reads, pagination, connection pool 20, lazy-loaded React pages, slow-request (>2 s) warnings, `X-Response-Time` header |
| Security | JWT auth, role-based access control on every route, ownership checks, bcrypt, AES-256-GCM encryption of phone numbers at rest, Helmet headers, rate limiting, NoSQL-injection sanitiser, upload type/size limits |
| Privacy (GDPR) | Consent recorded at sign-up, privacy toggles, **export my data** (JSON) and **delete my account** in Account & privacy |
| Reliability / backups | Daily automatic JSON backups (`BACKUP_CRON`, keeps `BACKUP_KEEP`), `npm run backup`, `npm run restore -- <folder>`, admin “Back up now” button |
| Logging & monitoring | `backend/logs/app-*.log`, `error-*.log`, activity audit log (admin → System), `/api/health`, system stats |
| Usability / accessibility | Responsive layout (mobile drawer & menu), keyboard focus styles, ARIA labels, `prefers-reduced-motion` respected (parallax + smooth scroll switch off) |
| Testing | `npm test` → integration tests with in-memory MongoDB (auth, RBAC, injection, expos, applications, booths, sessions, reminders, messaging, analytics, GDPR) |
| Documentation | This README, in-app **Help** page (`/faq`) with step-by-step guides per role, API list below |

---

## 4. Frontend highlights

- **React 18 + Vite**, React Router v6, code-split pages
- **Smooth scrolling** with Lenis (auto-disabled for reduced motion)
- **Parallax** with Framer Motion:
  - pinned hero: video zooms, wordmark lifts & fades, floating chips move at different speeds
  - scroll-linked marquee, staggered role cards drifting at different speeds
  - **horizontal scrolling** “Upcoming expos” section driven by vertical scroll (live data)
  - parallax image band, parallax page headers on every inner page, scroll-drawn timeline, 3-column drifting gallery
- 3D tilt cards, magnetic buttons, animated counters, page transitions, toasts
- Same classical espresso / antique-gold / wine palette and Cinzel + Cormorant typography as the original site

---

## 5. API reference (all under `/api`)

| Method | Path | Access |
|---|---|---|
| POST | /auth/register · /auth/login · /auth/forgot-password · /auth/reset-password/:token | public |
| GET/PUT | /auth/me · PUT /auth/password · PUT /auth/privacy · GET /auth/me/export · DELETE /auth/me | logged in |
| GET | /expos · /expos/:id · /expos/:id/sessions · /expos/:id/booths · /expos/:id/exhibitors | public |
| POST/PUT/DELETE | /expos · /expos/:id | organizer/admin |
| POST | /expos/:id/booths (single or `{generate:true}`) | organizer/admin |
| PUT/DELETE/PATCH | /booths/:id · /booths/:id/assign | organizer/admin |
| PUT | /booths/:id/details | owning exhibitor / staff |
| GET | /booths/mine · /booths/:id/neighbors · POST /booths/:id/visit | exhibitor / public |
| POST/DELETE | /expos/:id/register | attendee |
| GET | /registrations/mine · POST /registrations/check-in | attendee · staff |
| POST · GET | /applications · /applications/mine · PATCH /applications/:id/status · DELETE /applications/:id | exhibitor · staff |
| POST/PUT/DELETE | /sessions · /sessions/:id | staff |
| POST/DELETE | /sessions/:id/register · POST /sessions/:id/bookmark · GET /sessions/mine | logged in |
| GET/POST | /messages/conversations · /messages/with/:id · /messages/contacts · /messages | logged in |
| GET/PATCH/DELETE | /notifications · /notifications/:id/read · /notifications/read-all · POST /notifications/broadcast | logged in · staff |
| POST · GET · PATCH | /feedback · /feedback/mine · /feedback · /feedback/:id | public · staff |
| GET | /exhibitors · /exhibitors/:id · /gallery | public |
| GET | /analytics/overview · /analytics/exhibitor | staff · exhibitor |
| GET/PATCH/DELETE | /admin/users · /admin/activity · /admin/backups · /admin/system | admin |
| GET | /health | public |

Socket.IO events: `notification:new`, `message:new`, `message:read`, `typing`, `presence`,
`schedule:updated`, `booths:updated`, `expo:updated`, `analytics:update`, `applications:updated`, `feedback:new`.

---

## 6. Troubleshooting

- **“Could not connect to MongoDB”** — start MongoDB (`mongod`) or fix `MONGO_URI` in `backend/.env`.
- **Frontend shows “Cannot reach the server”** — the backend isn't running on port 5000.
- **Port in use** — change `PORT` in `backend/.env` and run the frontend with `VITE_PROXY_TARGET=http://localhost:<port> npm run dev`.
- **Password reset email** — without SMTP settings the link is printed in the backend console and shown on the page (development only).
