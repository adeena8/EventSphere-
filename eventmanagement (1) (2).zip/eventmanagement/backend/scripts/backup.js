/** Manual backup:  npm run backup */
import mongoose from "mongoose";
import { connectDB } from "../src/config/db.js";
import { runBackup } from "../src/services/backup.js";

await connectDB();
const result = await runBackup();
console.log("Backup saved:", result);
await mongoose.disconnect();
