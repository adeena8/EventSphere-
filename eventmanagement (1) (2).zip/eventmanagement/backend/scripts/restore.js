/** Restore a backup:  npm run restore -- <backup-folder-name>   (see backend/backups) */
import mongoose from "mongoose";
import { connectDB } from "../src/config/db.js";
import { restoreBackup, listBackups } from "../src/services/backup.js";

const folder = process.argv[2] || listBackups()[0];
if (!folder) {
  console.error("No backups found. Run `npm run backup` first.");
  process.exit(1);
}
await connectDB();
console.log(`Restoring from ${folder} …`);
await restoreBackup(folder);
console.log("Restore complete.");
await mongoose.disconnect();
