import path from "node:path";
import fs from "node:fs";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import mongoose from "mongoose";
import env, { ROOT_DIR } from "./config/env.js";
import logger from "./services/logger.js";
import routes from "./routes/index.js";
import { sanitize, apiLimiter, notFound, errorHandler } from "./middleware/common.js";

export function createApp() {
  const app = express();
  app.set("trust proxy", 1);
  app.disable("x-powered-by");

  app.use(
    helmet({
      crossOriginResourcePolicy: { policy: "cross-origin" }, // allow the React app to load /uploads images
    })
  );
  app.use(
    cors({
      origin: env.clientUrl.split(",").map((s) => s.trim()),
      credentials: true,
    })
  );
  app.use(express.json({ limit: "1mb" }));
  app.use(express.urlencoded({ extended: true, limit: "1mb" }));
  app.use(sanitize);
  if (!env.isTest) app.use(morgan(env.isProd ? "combined" : "dev", { stream: logger.stream }));

  // response-time header for performance monitoring
  app.use((req, res, next) => {
    const start = process.hrtime.bigint();
    const end = res.end;
    res.end = function patchedEnd(...args) {
      const ms = Number(process.hrtime.bigint() - start) / 1e6;
      if (!res.headersSent) res.setHeader("X-Response-Time", `${ms.toFixed(1)}ms`);
      if (ms > 2000) logger.warn(`Slow request ${req.method} ${req.originalUrl} took ${ms.toFixed(0)}ms`);
      return end.apply(this, args);
    };
    next();
  });

  app.use("/uploads", express.static(env.uploadsDir, { maxAge: "7d" }));

  app.get("/api/health", (_req, res) => {
    res.json({
      status: "ok",
      db: ["disconnected", "connected", "connecting", "disconnecting"][mongoose.connection.readyState],
      uptime: Math.round(process.uptime()),
      time: new Date(),
    });
  });

  app.use("/api", apiLimiter, routes);

  // In production, serve the built React app from ../frontend/dist
  const dist = path.resolve(ROOT_DIR, "../frontend/dist");
  if (env.isProd && fs.existsSync(dist)) {
    app.use(express.static(dist, { maxAge: "1h" }));
    app.get(/^(?!\/api|\/uploads|\/socket\.io).*/, (_req, res) => res.sendFile(path.join(dist, "index.html")));
  }

  app.use(notFound);
  app.use(errorHandler);
  return app;
}
