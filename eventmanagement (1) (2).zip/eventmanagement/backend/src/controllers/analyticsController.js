import mongoose from "mongoose";
import { Expo, Booth, Session, Registration, ExhibitorApplication, BoothVisit, Feedback, User } from "../models/index.js";
import { getManageableExpo } from "./expoController.js";
import { onlineUsers } from "../services/socket.js";
import { asyncHandler } from "../utils/helpers.js";

const DAY = 86400000;

function dayBuckets(days) {
  const out = [];
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  for (let i = days - 1; i >= 0; i--) out.push(new Date(+today - i * DAY).toISOString().slice(0, 10));
  return out;
}

async function perDay(Model, match, days) {
  const since = new Date(Date.now() - days * DAY);
  const rows = await Model.aggregate([
    { $match: { ...match, createdAt: { $gte: since } } },
    { $group: { _id: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } }, n: { $sum: 1 } } },
  ]);
  const map = Object.fromEntries(rows.map((r) => [r._id, r.n]));
  return dayBuckets(days).map((d) => ({ date: d, value: map[d] || 0 }));
}

/**
 * GET /api/analytics/overview?expo=<id>
 * Organizer → their expos only; Admin → everything.
 */
export const overview = asyncHandler(async (req, res) => {
  let expoIds;
  if (req.query.expo) {
    const expo = await getManageableExpo(req, req.query.expo);
    expoIds = [expo._id];
  } else if (req.user.role === "organizer") {
    expoIds = await Expo.find({ organizer: req.user._id }).distinct("_id");
  } else {
    expoIds = await Expo.find({}).distinct("_id");
  }
  const ids = expoIds.map((id) => new mongoose.Types.ObjectId(String(id)));
  const inExpo = { expo: { $in: ids } };

  const [
    expos, boothStatus, regs, checkedIn, sessions, appStatus, visits, ratings,
    registrationsByDay, visitsByDay, topSessionsRaw, boothTrafficRaw, perExpoRegs, perExpoBooths, sessionTypes,
  ] = await Promise.all([
    Expo.find({ _id: { $in: ids } }).select("title status startDate endDate capacity").lean(),
    Booth.aggregate([{ $match: inExpo }, { $group: { _id: "$status", n: { $sum: 1 } } }]),
    Registration.countDocuments({ ...inExpo, status: "confirmed" }),
    Registration.countDocuments({ ...inExpo, status: "confirmed", checkedIn: true }),
    Session.countDocuments(inExpo),
    ExhibitorApplication.aggregate([{ $match: inExpo }, { $group: { _id: "$status", n: { $sum: 1 } } }]),
    BoothVisit.countDocuments(inExpo),
    Feedback.aggregate([{ $match: { rating: { $ne: null }, ...(req.query.expo ? inExpo : {}) } }, { $group: { _id: null, avg: { $avg: "$rating" }, n: { $sum: 1 } } }]),
    perDay(Registration, { ...inExpo, status: "confirmed" }, 30),
    perDay(BoothVisit, inExpo, 14),
    Session.aggregate([
      { $match: inExpo },
      { $project: { title: 1, type: 1, startTime: 1, capacity: 1, expo: 1, registered: { $size: { $ifNull: ["$attendees", []] } }, bookmarks: { $size: { $ifNull: ["$bookmarkedBy", []] } } } },
      { $addFields: { score: { $add: ["$registered", { $multiply: ["$bookmarks", 0.5] }] } } },
      { $sort: { score: -1 } },
      { $limit: 8 },
    ]),
    BoothVisit.aggregate([
      { $match: inExpo },
      { $group: { _id: "$booth", visits: { $sum: 1 }, unique: { $addToSet: "$visitor" } } },
      { $sort: { visits: -1 } },
      { $limit: 10 },
      { $lookup: { from: "booths", localField: "_id", foreignField: "_id", as: "booth" } },
      { $unwind: "$booth" },
      { $lookup: { from: "users", localField: "booth.exhibitor", foreignField: "_id", as: "ex" } },
      { $project: { visits: 1, uniqueVisitors: { $size: "$unique" }, code: "$booth.code", hall: "$booth.hall", company: { $ifNull: [{ $arrayElemAt: ["$ex.company.name", 0] }, "$booth.displayName"] } } },
    ]),
    Registration.aggregate([{ $match: { ...inExpo, status: "confirmed" } }, { $group: { _id: "$expo", n: { $sum: 1 }, checked: { $sum: { $cond: ["$checkedIn", 1, 0] } } } }]),
    Booth.aggregate([{ $match: inExpo }, { $group: { _id: "$expo", total: { $sum: 1 }, occupied: { $sum: { $cond: [{ $eq: ["$status", "occupied"] }, 1, 0] } } } }]),
    Session.aggregate([{ $match: inExpo }, { $group: { _id: "$type", n: { $sum: 1 } } }]),
  ]);

  const booths = Object.fromEntries(boothStatus.map((b) => [b._id, b.n]));
  const apps = Object.fromEntries(appStatus.map((a) => [a._id, a.n]));
  const boothTotal = boothStatus.reduce((s, b) => s + b.n, 0);
  const sessionSeats = await Session.aggregate([
    { $match: inExpo },
    { $group: { _id: null, seats: { $sum: { $size: { $ifNull: ["$attendees", []] } } } } },
  ]);

  const expoMap = Object.fromEntries(expos.map((e) => [String(e._id), e]));
  const topSessions = topSessionsRaw.map((s) => ({ ...s, expoTitle: expoMap[String(s.expo)]?.title }));

  const perExpo = expos
    .map((e) => {
      const r = perExpoRegs.find((x) => String(x._id) === String(e._id));
      const b = perExpoBooths.find((x) => String(x._id) === String(e._id));
      return {
        _id: e._id,
        title: e.title,
        status: e.status,
        startDate: e.startDate,
        attendees: r?.n || 0,
        checkedIn: r?.checked || 0,
        booths: b?.total || 0,
        occupied: b?.occupied || 0,
        occupancy: b?.total ? Math.round((b.occupied / b.total) * 100) : 0,
      };
    })
    .sort((a, b) => new Date(b.startDate) - new Date(a.startDate));

  const users = req.user.role === "admin"
    ? Object.fromEntries((await User.aggregate([{ $group: { _id: "$role", n: { $sum: 1 } } }])).map((r) => [r._id, r.n]))
    : undefined;

  res.json({
    generatedAt: new Date(),
    totals: {
      expos: expos.length,
      published: expos.filter((e) => e.status === "published").length,
      attendees: regs,
      checkedIn,
      checkInRate: regs ? Math.round((checkedIn / regs) * 100) : 0,
      sessions,
      sessionSeats: sessionSeats[0]?.seats || 0,
      avgSessionsPerAttendee: regs ? +((sessionSeats[0]?.seats || 0) / regs).toFixed(2) : 0,
      exhibitors: booths.occupied || 0,
      booths: boothTotal,
      boothsAvailable: booths.available || 0,
      boothsReserved: booths.reserved || 0,
      occupancy: boothTotal ? Math.round(((booths.occupied || 0) / boothTotal) * 100) : 0,
      pendingApplications: apps.pending || 0,
      boothVisits: visits,
      avgRating: ratings[0]?.avg ? +ratings[0].avg.toFixed(2) : null,
      ratings: ratings[0]?.n || 0,
      onlineNow: onlineUsers().length,
    },
    users,
    applications: apps,
    sessionTypes: sessionTypes.map((s) => ({ label: s._id, value: s.n })),
    registrationsByDay,
    visitsByDay,
    topSessions,
    boothTraffic: boothTrafficRaw,
    perExpo,
  });
});

/** GET /api/analytics/exhibitor — an exhibitor's own booth stats */
export const exhibitorStats = asyncHandler(async (req, res) => {
  const booths = await Booth.find({ exhibitor: req.user._id }).select("_id code expo").populate("expo", "title").lean();
  const boothIds = booths.map((b) => b._id);
  const [total, unique, byDay, bySource] = await Promise.all([
    BoothVisit.countDocuments({ booth: { $in: boothIds } }),
    BoothVisit.distinct("visitor", { booth: { $in: boothIds }, visitor: { $ne: null } }),
    perDay(BoothVisit, { booth: { $in: boothIds } }, 14),
    BoothVisit.aggregate([{ $match: { booth: { $in: boothIds } } }, { $group: { _id: "$source", n: { $sum: 1 } } }]),
  ]);
  res.json({ booths, totalVisits: total, uniqueVisitors: unique.length, visitsByDay: byDay, bySource });
});
