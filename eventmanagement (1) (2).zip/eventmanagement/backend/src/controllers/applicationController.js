import { ExhibitorApplication, Expo, Booth } from "../models/index.js";
import { canManageExpo } from "../middleware/auth.js";
import { notify, logActivity } from "../services/notify.js";
import { emitToExpo, emitToStaff } from "../services/socket.js";
import { ApiError, asyncHandler, requireFields, assertId, toList, isId } from "../utils/helpers.js";

/** POST /api/applications  (multipart, field "documents" up to 5 files) */
export const apply = asyncHandler(async (req, res) => {
  requireFields(req.body, ["expo"]);
  assertId(req.body.expo, "expo id");
  const expo = await Expo.findById(req.body.expo);
  if (!expo || expo.status !== "published") throw new ApiError(404, "Expo is not accepting applications");
  if (expo.endDate < new Date()) throw new ApiError(400, "This expo has already ended");

  const existing = await ExhibitorApplication.findOne({ expo: expo._id, exhibitor: req.user._id });
  if (existing && ["pending", "approved"].includes(existing.status)) {
    throw new ApiError(409, `You already have a ${existing.status} application for this expo`);
  }

  const company = req.user.company || {};
  const data = {
    expo: expo._id,
    exhibitor: req.user._id,
    companyName: req.body.companyName || company.name,
    category: req.body.category || company.category,
    description: req.body.description || company.description,
    products: req.body.products !== undefined ? toList(req.body.products) : company.products || [],
    website: req.body.website || company.website,
    contactPerson: req.body.contactPerson || req.user.name,
    documents: (req.files || []).map((f) => ({ name: f.originalname, url: `/uploads/documents/${f.filename}` })),
    status: "pending",
    reviewNote: undefined,
    assignedBooth: null,
    preferredBooth: null,
  };
  if (!data.companyName) throw new ApiError(400, "Company name is required");

  // reserve the preferred booth (held until the organizer decides)
  if (req.body.preferredBooth && isId(req.body.preferredBooth)) {
    const booth = await Booth.findOneAndUpdate(
      { _id: req.body.preferredBooth, expo: expo._id, status: "available" },
      { $set: { status: "reserved" } },
      { new: true }
    );
    if (!booth) throw new ApiError(409, "That booth is no longer available — please pick another");
    data.preferredBooth = booth._id;
  }

  let app;
  if (existing) {
    Object.assign(existing, data);
    app = await existing.save();
  } else {
    app = await ExhibitorApplication.create(data);
  }

  await notify(expo.organizer, {
    type: "application",
    title: "New exhibitor application",
    body: `${data.companyName} applied to exhibit at ${expo.title}.`,
    link: "/dashboard/applications",
  });
  emitToExpo(expo._id, "booths:updated", { expoId: expo._id });
  emitToStaff("applications:updated", { expoId: expo._id });
  logActivity(req, "application.create", "ExhibitorApplication", app._id);
  res.status(201).json({ application: app });
});

/** GET /api/applications/mine */
export const myApplications = asyncHandler(async (req, res) => {
  const items = await ExhibitorApplication.find({ exhibitor: req.user._id })
    .populate("expo", "title startDate endDate location status")
    .populate("preferredBooth assignedBooth", "code hall status")
    .sort({ createdAt: -1 })
    .lean();
  res.json({ items });
});

/** GET /api/applications?expo=&status=  (staff) */
export const listApplications = asyncHandler(async (req, res) => {
  const filter = {};
  if (req.query.status) filter.status = req.query.status;
  if (req.query.expo) {
    assertId(req.query.expo, "expo id");
    filter.expo = req.query.expo;
  }
  if (req.user.role === "organizer") {
    const mine = await Expo.find({ organizer: req.user._id }).distinct("_id");
    filter.expo = filter.expo ? (mine.some((m) => String(m) === String(filter.expo)) ? filter.expo : null) : { $in: mine };
  }
  const items = await ExhibitorApplication.find(filter)
    .populate("expo", "title startDate")
    .populate("exhibitor", "name email company.logo company.website")
    .populate("preferredBooth assignedBooth", "code hall status")
    .sort({ createdAt: -1 })
    .lean();
  res.json({ items });
});

/** PATCH /api/applications/:id/status  { status: approved|rejected, boothId?, note? } (staff) */
export const reviewApplication = asyncHandler(async (req, res) => {
  assertId(req.params.id, "application id");
  const { status, note } = req.body;
  if (!["approved", "rejected"].includes(status)) throw new ApiError(400, "Status must be approved or rejected");

  const app = await ExhibitorApplication.findById(req.params.id).populate("expo");
  if (!app) throw new ApiError(404, "Application not found");
  if (!canManageExpo(req.user, app.expo)) throw new ApiError(403, "Not your expo");

  app.status = status;
  app.reviewNote = note;
  app.reviewedBy = req.user._id;
  app.reviewedAt = new Date();

  let boothMsg = "";
  if (status === "approved") {
    const boothId = req.body.boothId || app.preferredBooth;
    if (boothId) {
      assertId(boothId, "booth id");
      const booth = await Booth.findOne({ _id: boothId, expo: app.expo._id });
      if (!booth) throw new ApiError(404, "Booth not found in this expo");
      if (booth.exhibitor && String(booth.exhibitor) !== String(app.exhibitor)) {
        throw new ApiError(409, `Booth ${booth.code} is already allocated to another exhibitor`);
      }
      // moving an already-approved exhibitor to another booth → release the old one
      if (app.assignedBooth && String(app.assignedBooth) !== String(booth._id)) {
        await Booth.updateOne(
          { _id: app.assignedBooth, exhibitor: app.exhibitor },
          { $set: { exhibitor: null, application: null, status: "available", products: [], staff: [], displayName: "", description: "" } }
        );
      }
      // free the preferred booth if a different one is being assigned
      if (app.preferredBooth && String(app.preferredBooth) !== String(booth._id)) {
        await Booth.updateOne({ _id: app.preferredBooth, status: "reserved", exhibitor: null }, { $set: { status: "available" } });
      }
      Object.assign(booth, {
        exhibitor: app.exhibitor,
        application: app._id,
        status: "occupied",
        displayName: app.companyName,
        products: app.products,
      });
      await booth.save();
      app.assignedBooth = booth._id;
      boothMsg = ` Your booth is ${booth.code} (${booth.hall}).`;
    }
  } else if (app.preferredBooth) {
    await Booth.updateOne({ _id: app.preferredBooth, status: "reserved", exhibitor: null }, { $set: { status: "available" } });
    if (app.assignedBooth) {
      await Booth.updateOne(
        { _id: app.assignedBooth },
        { $set: { exhibitor: null, application: null, status: "available", products: [], staff: [] } }
      );
      app.assignedBooth = null;
    }
  }
  await app.save();

  await notify(app.exhibitor, {
    type: "application",
    title: `Application ${status}: ${app.expo.title}`,
    body: status === "approved" ? `Congratulations!${boothMsg}` : `Unfortunately your application was not accepted.${note ? ` Note: ${note}` : ""}`,
    link: "/dashboard/applications",
  });
  emitToExpo(app.expo._id, "booths:updated", { expoId: app.expo._id });
  logActivity(req, `application.${status}`, "ExhibitorApplication", app._id);
  res.json({ application: app });
});

/** DELETE /api/applications/:id — exhibitor withdraws a pending application */
export const withdrawApplication = asyncHandler(async (req, res) => {
  assertId(req.params.id, "application id");
  const app = await ExhibitorApplication.findOne({ _id: req.params.id, exhibitor: req.user._id });
  if (!app) throw new ApiError(404, "Application not found");
  if (app.status !== "pending") throw new ApiError(400, "Only pending applications can be withdrawn");
  if (app.preferredBooth) {
    await Booth.updateOne({ _id: app.preferredBooth, status: "reserved", exhibitor: null }, { $set: { status: "available" } });
  }
  app.status = "withdrawn";
  app.preferredBooth = null;
  await app.save();
  emitToExpo(app.expo, "booths:updated", { expoId: app.expo });
  res.json({ application: app });
});
