import crypto from "node:crypto";
import env from "../config/env.js";
import {
  User, Registration, ExhibitorApplication, Message, Notification, Feedback, Session, Booth, BoothVisit,
} from "../models/index.js";
import { signToken } from "../middleware/auth.js";
import { sendMail } from "../services/mailer.js";
import { notifyRole, logActivity } from "../services/notify.js";
import {
  ApiError, asyncHandler, pick, requireFields, validatePassword, EMAIL_RE, sha256, toList, fileUrl, parseJSON,
} from "../utils/helpers.js";

const SELF_REGISTER_ROLES = ["attendee", "exhibitor", "organizer"];

function authResponse(res, user, status = 200) {
  res.status(status).json({ token: signToken(user), user });
}

/** POST /api/auth/register */
export const register = asyncHandler(async (req, res) => {
  requireFields(req.body, ["name", "email", "password"]);
  const { name, email, password, phone, companyName } = req.body;
  const role = SELF_REGISTER_ROLES.includes(req.body.role) ? req.body.role : "attendee";

  if (!EMAIL_RE.test(email)) throw new ApiError(400, "Please enter a valid email address");
  validatePassword(password);
  if (!(req.body.consent === true || req.body.consent === "true")) {
    throw new ApiError(400, "You must accept the privacy policy to create an account");
  }
  if (role === "exhibitor" && !companyName) throw new ApiError(400, "Company name is required for exhibitors");

  const exists = await User.exists({ email: email.toLowerCase() });
  if (exists) throw new ApiError(409, "An account with this email already exists");

  const user = await User.create({
    name,
    email,
    password,
    role,
    phone,
    // organizers need admin approval before they can manage expos
    status: role === "organizer" ? "pending" : "active",
    company: role === "exhibitor" ? { name: companyName, contactEmail: email } : {},
    privacy: { consentAt: new Date(), marketingEmails: !!req.body.marketingEmails },
  });

  logActivity(Object.assign(req, { user }), "register", "User", user._id, { role });

  if (user.status === "pending") {
    await notifyRole("admin", {
      type: "info",
      title: "New organizer awaiting approval",
      body: `${user.name} (${user.email}) registered as an organizer.`,
      link: "/dashboard/users",
    });
    return res.status(201).json({
      pending: true,
      message: "Organizer account created. An administrator will approve it shortly.",
    });
  }

  await sendMail({
    to: user.email,
    subject: "Welcome to EventSphere",
    text: `Hi ${user.name}, your ${user.role} account is ready. Explore upcoming expos at ${env.clientUrl}/expos`,
  });
  authResponse(res, user, 201);
});

/** POST /api/auth/login */
export const login = asyncHandler(async (req, res) => {
  requireFields(req.body, ["email", "password"]);
  const user = await User.findOne({ email: String(req.body.email).toLowerCase() }).select("+password");
  if (!user || !(await user.comparePassword(req.body.password))) {
    throw new ApiError(401, "Invalid email or password");
  }
  if (user.status === "pending") throw new ApiError(403, "Your organizer account is awaiting admin approval");
  if (user.status === "suspended") throw new ApiError(403, "Your account has been suspended");

  user.lastLoginAt = new Date();
  await user.save({ validateBeforeSave: false });
  logActivity(Object.assign(req, { user }), "login", "User", user._id);
  authResponse(res, user);
});

/** GET /api/auth/me */
export const me = asyncHandler(async (req, res) => {
  res.json({ user: req.user });
});

/** PUT /api/auth/me  (multipart: avatar, logo) */
export const updateMe = asyncHandler(async (req, res) => {
  const user = req.user;
  Object.assign(user, pick(req.body, ["name", "phone", "bio"]));

  const avatar = req.files?.avatar?.[0];
  if (avatar) user.avatar = fileUrl(avatar, "avatars");

  if (user.role === "exhibitor") {
    const c = parseJSON(req.body.company, {}) || {};
    const next = { ...(user.company?.toObject?.() || user.company || {}) };
    for (const k of ["name", "description", "website", "category", "contactEmail", "contactPhone", "address"]) {
      if (c[k] !== undefined) next[k] = c[k];
    }
    if (c.products !== undefined) next.products = toList(c.products);
    const logo = req.files?.logo?.[0];
    if (logo) next.logo = fileUrl(logo, "avatars");
    user.company = next;
  }
  await user.save();
  logActivity(req, "profile.update", "User", user._id);
  res.json({ user });
});

/** PUT /api/auth/privacy */
export const updatePrivacy = asyncHandler(async (req, res) => {
  const p = pick(req.body, ["profilePublic", "allowMessages", "marketingEmails"]);
  for (const [k, v] of Object.entries(p)) req.user.privacy[k] = v === true || v === "true";
  await req.user.save();
  res.json({ user: req.user });
});

/** PUT /api/auth/password */
export const changePassword = asyncHandler(async (req, res) => {
  requireFields(req.body, ["currentPassword", "newPassword"]);
  const user = await User.findById(req.user._id).select("+password");
  if (!(await user.comparePassword(req.body.currentPassword))) throw new ApiError(400, "Current password is incorrect");
  validatePassword(req.body.newPassword);
  user.password = req.body.newPassword;
  await user.save();
  logActivity(req, "password.change", "User", user._id);
  authResponse(res, user);
});

/** POST /api/auth/forgot-password */
export const forgotPassword = asyncHandler(async (req, res) => {
  requireFields(req.body, ["email"]);
  const user = await User.findOne({ email: String(req.body.email).toLowerCase() });
  const generic = { message: "If that email is registered, a reset link has been sent." };
  if (!user) return res.json(generic);

  const raw = crypto.randomBytes(32).toString("hex");
  user.resetPasswordToken = sha256(raw);
  user.resetPasswordExpires = new Date(Date.now() + 30 * 60 * 1000); // 30 minutes
  await user.save({ validateBeforeSave: false });

  const resetUrl = `${env.clientUrl}/reset-password/${raw}`;
  await sendMail({
    to: user.email,
    subject: "Reset your EventSphere password",
    text: `Hi ${user.name},\n\nReset your password using this link (valid 30 minutes):\n${resetUrl}\n\nIf you didn't request this, ignore this email.`,
  });
  logActivity(Object.assign(req, { user }), "password.forgot", "User", user._id);
  // In development the link is returned so the flow can be tested without SMTP
  res.json(env.isProd || env.smtp.host ? generic : { ...generic, devResetUrl: resetUrl });
});

/** POST /api/auth/reset-password/:token */
export const resetPassword = asyncHandler(async (req, res) => {
  requireFields(req.body, ["password"]);
  validatePassword(req.body.password);
  const user = await User.findOne({
    resetPasswordToken: sha256(req.params.token),
    resetPasswordExpires: { $gt: new Date() },
  }).select("+resetPasswordToken +resetPasswordExpires");
  if (!user) throw new ApiError(400, "Reset link is invalid or has expired");

  user.password = req.body.password;
  user.resetPasswordToken = undefined;
  user.resetPasswordExpires = undefined;
  await user.save();
  logActivity(Object.assign(req, { user }), "password.reset", "User", user._id);
  authResponse(res, user);
});

/** GET /api/auth/me/export — GDPR data portability */
export const exportMyData = asyncHandler(async (req, res) => {
  const id = req.user._id;
  const [registrations, applications, messages, notifications, feedback, sessions] = await Promise.all([
    Registration.find({ attendee: id }).populate("expo", "title startDate").lean(),
    ExhibitorApplication.find({ exhibitor: id }).populate("expo", "title").lean(),
    Message.find({ $or: [{ from: id }, { to: id }] }).lean(),
    Notification.find({ user: id }).lean(),
    Feedback.find({ user: id }).lean(),
    Session.find({ $or: [{ attendees: id }, { bookmarkedBy: id }] }).select("title startTime").lean(),
  ]);
  res.setHeader("Content-Disposition", `attachment; filename="eventsphere-data-${id}.json"`);
  res.json({
    exportedAt: new Date(),
    profile: req.user.toJSON(),
    registrations,
    applications,
    sessions,
    messages,
    notifications,
    feedback,
  });
});

/** DELETE /api/auth/me — GDPR right to erasure */
export const deleteMe = asyncHandler(async (req, res) => {
  requireFields(req.body, ["password"]);
  const user = await User.findById(req.user._id).select("+password");
  if (!(await user.comparePassword(req.body.password))) throw new ApiError(400, "Password is incorrect");
  if (user.role === "admin" && (await User.countDocuments({ role: "admin" })) <= 1) {
    throw new ApiError(400, "The last administrator cannot delete their account");
  }
  await purgeUser(user._id);
  logActivity(req, "account.delete", "User", user._id);
  res.json({ message: "Your account and personal data have been deleted" });
});

/** Remove a user and all personal data references */
export async function purgeUser(id) {
  const booths = await Booth.find({ exhibitor: id }).select("_id expo");
  await Booth.updateMany(
    { exhibitor: id },
    { $set: { exhibitor: null, application: null, status: "available", products: [], staff: [], description: "", displayName: "" } }
  );
  await Booth.updateMany({ status: "reserved", _id: { $in: (await ExhibitorApplication.find({ exhibitor: id }).distinct("preferredBooth")).filter(Boolean) } }, { $set: { status: "available" } });
  await Promise.all([
    Registration.deleteMany({ attendee: id }),
    ExhibitorApplication.deleteMany({ exhibitor: id }),
    Message.deleteMany({ $or: [{ from: id }, { to: id }] }),
    Notification.deleteMany({ user: id }),
    Feedback.updateMany({ user: id }, { $set: { user: null, email: null, name: "Deleted user" } }),
    Session.updateMany({}, { $pull: { attendees: id, bookmarkedBy: id } }),
    BoothVisit.updateMany({ visitor: id }, { $set: { visitor: null } }),
  ]);
  await User.deleteOne({ _id: id });
  return booths.length;
}
