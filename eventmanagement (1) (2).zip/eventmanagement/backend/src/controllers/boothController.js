import { Booth, Expo, ExhibitorApplication, BoothVisit } from "../models/index.js";
import { canManageExpo } from "../middleware/auth.js";
import { notify, logActivity } from "../services/notify.js";
import { emitToExpo } from "../services/socket.js";
import { getManageableExpo, generateGrid } from "./expoController.js";
import { ApiError, asyncHandler, pick, requireFields, assertId, toList } from "../utils/helpers.js";

const PUBLIC_EXHIBITOR = "name avatar company.name company.logo company.category";

async function loadBooth(id) {
  assertId(id, "booth id");
  const booth = await Booth.findById(id);
  if (!booth) throw new ApiError(404, "Booth not found");
  return booth;
}

async function assertManage(req, booth) {
  const expo = await Expo.findById(booth.expo);
  if (!canManageExpo(req.user, expo)) throw new ApiError(403, "You can only manage booths of your own expos");
  return expo;
}

const changed = (expoId, boothId) => emitToExpo(expoId, "booths:updated", { expoId, boothId });

/** GET /api/expos/:id/booths — floor plan */
export const listBooths = asyncHandler(async (req, res) => {
  assertId(req.params.id, "expo id");
  const expo = await Expo.findById(req.params.id).select("floorPlan title status organizer").lean();
  if (!expo) throw new ApiError(404, "Expo not found");
  const booths = await Booth.find({ expo: expo._id }).populate("exhibitor", PUBLIC_EXHIBITOR).sort({ row: 1, col: 1 }).lean();
  res.json({ floorPlan: expo.floorPlan, booths });
});

/** POST /api/expos/:id/booths — add one booth, or { generate: true, price } to fill the grid */
export const createBooth = asyncHandler(async (req, res) => {
  const expo = await getManageableExpo(req, req.params.id);

  if (req.body.generate) {
    if (req.body.rows || req.body.cols) {
      expo.floorPlan.rows = Number(req.body.rows) || expo.floorPlan.rows;
      expo.floorPlan.cols = Number(req.body.cols) || expo.floorPlan.cols;
      await expo.save();
    }
    const created = await generateGrid(expo, {
      price: Number(req.body.price) || 0,
      size: req.body.size || "medium",
      hall: req.body.hall || "Main Hall",
    });
    changed(expo._id);
    logActivity(req, "booth.generate", "Expo", expo._id, { created });
    return res.status(201).json({ created });
  }

  requireFields(req.body, ["code", "row", "col"]);
  const row = Number(req.body.row);
  const col = Number(req.body.col);
  if (row >= expo.floorPlan.rows || col >= expo.floorPlan.cols) {
    throw new ApiError(400, `Position outside floor plan (${expo.floorPlan.rows}×${expo.floorPlan.cols})`);
  }
  const booth = await Booth.create({
    ...pick(req.body, ["code", "hall", "size", "price", "status"]),
    row,
    col,
    expo: expo._id,
  });
  changed(expo._id, booth._id);
  logActivity(req, "booth.create", "Booth", booth._id);
  res.status(201).json({ booth });
});

/** PUT /api/booths/:id (staff) */
export const updateBooth = asyncHandler(async (req, res) => {
  const booth = await loadBooth(req.params.id);
  await assertManage(req, booth);
  const data = pick(req.body, ["code", "hall", "size", "price", "row", "col"]);
  if (req.body.status && ["available", "blocked"].includes(req.body.status) && !booth.exhibitor) {
    data.status = req.body.status;
  }
  Object.assign(booth, data);
  await booth.save();
  changed(booth.expo, booth._id);
  res.json({ booth });
});

/** DELETE /api/booths/:id (staff) */
export const deleteBooth = asyncHandler(async (req, res) => {
  const booth = await loadBooth(req.params.id);
  await assertManage(req, booth);
  if (booth.exhibitor) throw new ApiError(400, "Unassign the exhibitor before deleting this booth");
  await ExhibitorApplication.updateMany({ preferredBooth: booth._id }, { $set: { preferredBooth: null } });
  await booth.deleteOne();
  changed(booth.expo, booth._id);
  res.json({ message: "Booth deleted" });
});

/** PATCH /api/booths/:id/assign  { exhibitorId | null } (staff) */
export const assignBooth = asyncHandler(async (req, res) => {
  const booth = await loadBooth(req.params.id);
  const expo = await assertManage(req, booth);
  const { exhibitorId } = req.body;

  // unassign
  if (!exhibitorId) {
    const prev = booth.exhibitor;
    if (booth.application) await ExhibitorApplication.updateOne({ _id: booth.application }, { $set: { assignedBooth: null } });
    Object.assign(booth, { exhibitor: null, application: null, status: "available", products: [], staff: [], displayName: "", description: "" });
    await booth.save();
    if (prev) {
      await notify(prev, { type: "booth", title: `Booth ${booth.code} unassigned`, body: `Your booth at ${expo.title} was released by the organizer.`, link: "/dashboard/booths" });
    }
    changed(expo._id, booth._id);
    return res.json({ booth });
  }

  assertId(exhibitorId, "exhibitor id");
  if (booth.exhibitor && String(booth.exhibitor) !== String(exhibitorId)) {
    throw new ApiError(409, `Booth ${booth.code} is already allocated`);
  }
  const app = await ExhibitorApplication.findOne({ expo: expo._id, exhibitor: exhibitorId, status: "approved" });
  if (!app) throw new ApiError(400, "Exhibitor must have an approved application for this expo");

  // release a previously assigned booth for this exhibitor in this expo
  if (app.assignedBooth && String(app.assignedBooth) !== String(booth._id)) {
    await Booth.updateOne(
      { _id: app.assignedBooth },
      { $set: { exhibitor: null, application: null, status: "available", products: [], staff: [] } }
    );
  }
  Object.assign(booth, {
    exhibitor: exhibitorId,
    application: app._id,
    status: "occupied",
    displayName: app.companyName,
    products: booth.products?.length ? booth.products : app.products,
  });
  await booth.save();
  app.assignedBooth = booth._id;
  await app.save();

  await notify(exhibitorId, {
    type: "booth",
    title: `Booth ${booth.code} assigned`,
    body: `You've been allocated booth ${booth.code} (${booth.hall}) at ${expo.title}.`,
    link: "/dashboard/booths",
  });
  changed(expo._id, booth._id);
  logActivity(req, "booth.assign", "Booth", booth._id, { exhibitorId });
  res.json({ booth });
});

/** PUT /api/booths/:id/details — exhibitor manages their own booth */
export const updateBoothDetails = asyncHandler(async (req, res) => {
  const booth = await loadBooth(req.params.id);
  const isOwner = String(booth.exhibitor) === String(req.user._id);
  if (!isOwner) await assertManage(req, booth);

  if (req.body.displayName !== undefined) booth.displayName = String(req.body.displayName).slice(0, 120);
  if (req.body.description !== undefined) booth.description = String(req.body.description).slice(0, 1000);
  if (req.body.products !== undefined) booth.products = toList(req.body.products).slice(0, 50);
  if (Array.isArray(req.body.staff)) {
    booth.staff = req.body.staff
      .filter((s) => s && s.name)
      .slice(0, 20)
      .map((s) => pick(s, ["name", "role", "email"]));
  }
  await booth.save();
  changed(booth.expo, booth._id);
  res.json({ booth });
});

/** GET /api/booths/mine — exhibitor's booths */
export const myBooths = asyncHandler(async (req, res) => {
  const items = await Booth.find({ exhibitor: req.user._id })
    .populate("expo", "title startDate endDate location status floorPlan")
    .lean();
  const visits = await BoothVisit.aggregate([
    { $match: { booth: { $in: items.map((b) => b._id) } } },
    { $group: { _id: "$booth", n: { $sum: 1 } } },
  ]);
  for (const b of items) b.visits = visits.find((v) => String(v._id) === String(b._id))?.n || 0;
  res.json({ items: items.filter((b) => b.expo) });
});

/** GET /api/booths/:id/neighbors — adjacent exhibitors for collaboration */
export const neighbors = asyncHandler(async (req, res) => {
  const booth = await loadBooth(req.params.id);
  const items = await Booth.find({
    expo: booth.expo,
    _id: { $ne: booth._id },
    exhibitor: { $ne: null },
    row: { $gte: booth.row - 1, $lte: booth.row + 1 },
    col: { $gte: booth.col - 1, $lte: booth.col + 1 },
  })
    .populate("exhibitor", "name avatar company.name company.logo company.category company.contactEmail privacy.allowMessages")
    .lean();
  res.json({ items });
});

/** POST /api/booths/:id/visit — booth traffic tracking (public) */
export const recordVisit = asyncHandler(async (req, res) => {
  const booth = await loadBooth(req.params.id);
  if (!booth.exhibitor) return res.json({ ok: true });
  if (req.user && String(req.user._id) === String(booth.exhibitor)) return res.json({ ok: true }); // don't count own visits

  // de-duplicate: one visit per user per booth per hour
  if (req.user) {
    const recent = await BoothVisit.exists({
      booth: booth._id,
      visitor: req.user._id,
      createdAt: { $gt: new Date(Date.now() - 60 * 60 * 1000) },
    });
    if (recent) return res.json({ ok: true, deduped: true });
  }
  const source = ["profile", "floorplan", "checkin"].includes(req.body?.source) ? req.body.source : "profile";
  await BoothVisit.create({ booth: booth._id, expo: booth.expo, exhibitor: booth.exhibitor, visitor: req.user?._id || null, source });
  emitToExpo(booth.expo, "analytics:update", { expoId: booth.expo, kind: "visit" });
  res.status(201).json({ ok: true });
});

/** GET /api/booths/exhibitor-options/:expoId — approved exhibitors for assignment dropdown (staff) */
export const assignableExhibitors = asyncHandler(async (req, res) => {
  const expo = await getManageableExpo(req, req.params.expoId);
  const apps = await ExhibitorApplication.find({ expo: expo._id, status: "approved" })
    .populate("exhibitor", "name email company.name")
    .populate("assignedBooth", "code")
    .lean();
  res.json({
    items: apps.filter((a) => a.exhibitor).map((a) => ({
      _id: a.exhibitor._id,
      name: a.exhibitor.name,
      company: a.companyName || a.exhibitor.company?.name,
      assignedBooth: a.assignedBooth?.code || null,
    })),
  });
});

