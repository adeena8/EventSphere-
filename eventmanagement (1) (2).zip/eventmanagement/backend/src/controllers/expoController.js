import QRCode from "qrcode";
import {
  Expo, Booth, Session, Registration, ExhibitorApplication, BoothVisit, Feedback, GalleryItem, User,
} from "../models/index.js";
import { canManageExpo, isStaff } from "../middleware/auth.js";
import { notify, logActivity } from "../services/notify.js";
import { emitToExpo, emitAll } from "../services/socket.js";
import {
  ApiError, asyncHandler, pick, requireFields, assertId, escapeRegex, toList, parseJSON, fileUrl, ticketCode,
} from "../utils/helpers.js";

const EXPO_FIELDS = ["title", "description", "theme", "category", "startDate", "endDate", "status", "capacity", "tags"];

function buildExpoData(body, file) {
  const data = pick(body, EXPO_FIELDS);
  if (data.tags !== undefined) data.tags = toList(data.tags);
  const location = parseJSON(body.location, undefined);
  if (location) data.location = pick(location, ["venue", "city", "address"]);
  const floorPlan = parseJSON(body.floorPlan, undefined);
  if (floorPlan) data.floorPlan = pick(floorPlan, ["rows", "cols", "halls", "notes"]);
  if (file) data.banner = fileUrl(file, "banners");
  else if (body.bannerUrl) data.banner = body.bannerUrl;
  return data;
}

export async function getManageableExpo(req, id) {
  assertId(id, "expo id");
  const expo = await Expo.findById(id);
  if (!expo) throw new ApiError(404, "Expo not found");
  if (!canManageExpo(req.user, expo)) throw new ApiError(403, "You can only manage your own expos");
  return expo;
}

/* ------------------------------------------------------------------ */
/* Expos                                                               */
/* ------------------------------------------------------------------ */

/** GET /api/expos?q=&category=&status=&when=upcoming|past&mine=1&page=&limit= */
export const listExpos = asyncHandler(async (req, res) => {
  const { q, category, when, mine, status } = req.query;
  const page = Math.max(1, Number(req.query.page) || 1);
  const limit = Math.min(50, Math.max(1, Number(req.query.limit) || 12));
  const filter = {};

  if (mine && isStaff(req.user)) {
    if (req.user.role === "organizer") filter.organizer = req.user._id;
    if (status) filter.status = status;
  } else if (isStaff(req.user) && status) {
    filter.status = status;
  } else {
    filter.status = { $in: ["published", "completed"] };
  }
  if (category) filter.category = category;
  if (when === "upcoming") filter.endDate = { $gte: new Date() };
  if (when === "past") filter.endDate = { $lt: new Date() };
  if (q) {
    const rx = new RegExp(escapeRegex(q), "i");
    filter.$or = [{ title: rx }, { theme: rx }, { description: rx }, { "location.city": rx }, { category: rx }];
  }

  const [items, total] = await Promise.all([
    Expo.find(filter)
      .sort({ startDate: when === "past" ? -1 : 1 })
      .skip((page - 1) * limit)
      .limit(limit)
      .populate("organizer", "name")
      .lean(),
    Expo.countDocuments(filter),
  ]);

  // attach quick counts
  const ids = items.map((e) => e._id);
  const [booths, regs] = await Promise.all([
    Booth.aggregate([{ $match: { expo: { $in: ids } } }, { $group: { _id: { expo: "$expo", status: "$status" }, n: { $sum: 1 } } }]),
    Registration.aggregate([{ $match: { expo: { $in: ids }, status: "confirmed" } }, { $group: { _id: "$expo", n: { $sum: 1 } } }]),
  ]);
  for (const e of items) {
    const b = booths.filter((x) => String(x._id.expo) === String(e._id));
    e.stats = {
      booths: b.reduce((s, x) => s + x.n, 0),
      boothsAvailable: b.find((x) => x._id.status === "available")?.n || 0,
      exhibitors: b.find((x) => x._id.status === "occupied")?.n || 0,
      attendees: regs.find((x) => String(x._id) === String(e._id))?.n || 0,
    };
  }

  const categories = await Expo.distinct("category", { status: { $in: ["published", "completed"] } });
  res.json({ items, total, page, pages: Math.ceil(total / limit) || 1, categories });
});

/** GET /api/expos/:id */
export const getExpo = asyncHandler(async (req, res) => {
  assertId(req.params.id, "expo id");
  const expo = await Expo.findById(req.params.id).populate("organizer", "name email avatar").lean();
  if (!expo) throw new ApiError(404, "Expo not found");
  const manage = canManageExpo(req.user, expo);
  if (!["published", "completed"].includes(expo.status) && !manage) throw new ApiError(404, "Expo not found");

  const [boothCounts, attendees, sessions, registration, application] = await Promise.all([
    Booth.aggregate([{ $match: { expo: expo._id } }, { $group: { _id: "$status", n: { $sum: 1 } } }]),
    Registration.countDocuments({ expo: expo._id, status: "confirmed" }),
    Session.countDocuments({ expo: expo._id }),
    req.user ? Registration.findOne({ expo: expo._id, attendee: req.user._id }).lean() : null,
    req.user?.role === "exhibitor"
      ? ExhibitorApplication.findOne({ expo: expo._id, exhibitor: req.user._id }).populate("assignedBooth preferredBooth", "code status").lean()
      : null,
  ]);
  const by = Object.fromEntries(boothCounts.map((b) => [b._id, b.n]));
  expo.stats = {
    booths: boothCounts.reduce((s, b) => s + b.n, 0),
    boothsAvailable: by.available || 0,
    exhibitors: by.occupied || 0,
    attendees,
    sessions,
    seatsLeft: expo.capacity ? Math.max(0, expo.capacity - attendees) : null,
  };
  expo.canManage = manage;
  expo.myRegistration = registration && registration.status === "confirmed" ? registration : null;
  expo.myApplication = application;
  res.json({ expo });
});

/** POST /api/expos */
export const createExpo = asyncHandler(async (req, res) => {
  requireFields(req.body, ["title", "startDate", "endDate"]);
  const data = buildExpoData(req.body, req.file);
  const expo = await Expo.create({ ...data, organizer: req.user._id });

  // optional automatic booth grid
  if (req.body.generateBooths === "true" || req.body.generateBooths === true) {
    await generateGrid(expo, { price: Number(req.body.boothPrice) || 0 });
  }
  logActivity(req, "expo.create", "Expo", expo._id);
  if (expo.status === "published") emitAll("expo:updated", { expoId: expo._id, action: "created" });
  res.status(201).json({ expo });
});

/** PUT /api/expos/:id */
export const updateExpo = asyncHandler(async (req, res) => {
  const expo = await getManageableExpo(req, req.params.id);
  const wasPublished = expo.status === "published";
  const before = { start: +expo.startDate, end: +expo.endDate, venue: expo.location?.venue };
  Object.assign(expo, buildExpoData(req.body, req.file));
  await expo.save();

  const changed =
    before.start !== +expo.startDate || before.end !== +expo.endDate || before.venue !== expo.location?.venue;
  if (changed || (wasPublished && expo.status === "cancelled")) {
    const regs = await Registration.find({ expo: expo._id, status: "confirmed" }).distinct("attendee");
    const exh = await ExhibitorApplication.find({ expo: expo._id, status: "approved" }).distinct("exhibitor");
    await notify([...regs, ...exh], {
      type: "schedule",
      title: expo.status === "cancelled" ? `${expo.title} has been cancelled` : `${expo.title}: event details updated`,
      body: expo.status === "cancelled" ? "We're sorry — this expo will not take place." : "Dates or venue changed. Please review the latest details.",
      link: `/expos/${expo._id}`,
    });
  }
  emitToExpo(expo._id, "expo:updated", { expoId: expo._id, action: "updated" });
  emitAll("expo:updated", { expoId: expo._id, action: "updated" });
  logActivity(req, "expo.update", "Expo", expo._id);
  res.json({ expo });
});

/** DELETE /api/expos/:id */
export const deleteExpo = asyncHandler(async (req, res) => {
  const expo = await getManageableExpo(req, req.params.id);
  const regs = await Registration.find({ expo: expo._id, status: "confirmed" }).distinct("attendee");
  await Promise.all([
    Booth.deleteMany({ expo: expo._id }),
    Session.deleteMany({ expo: expo._id }),
    Registration.deleteMany({ expo: expo._id }),
    ExhibitorApplication.deleteMany({ expo: expo._id }),
    BoothVisit.deleteMany({ expo: expo._id }),
    GalleryItem.updateMany({ expo: expo._id }, { $set: { expo: null } }),
    Feedback.updateMany({ expo: expo._id }, { $set: { expo: null } }),
  ]);
  await expo.deleteOne();
  if (regs.length) {
    await notify(regs, { type: "schedule", title: `${expo.title} was removed`, body: "This expo is no longer available." });
  }
  emitAll("expo:updated", { expoId: expo._id, action: "deleted" });
  logActivity(req, "expo.delete", "Expo", expo._id, { title: expo.title });
  res.json({ message: "Expo deleted" });
});

/* ------------------------------------------------------------------ */
/* Booth grid helpers                                                  */
/* ------------------------------------------------------------------ */
/** 0→A, 25→Z, 26→AA, 27→AB … (never collides with numeric column suffixes) */
const rowLetter = (r) => (r < 26 ? "" : String.fromCharCode(64 + Math.floor(r / 26))) + String.fromCharCode(65 + (r % 26));

export async function generateGrid(expo, { price = 0, size = "medium", hall = "Main Hall" } = {}) {
  const { rows, cols } = expo.floorPlan;
  const existing = await Booth.find({ expo: expo._id }).select("row col").lean();
  const taken = new Set(existing.map((b) => `${b.row}:${b.col}`));
  const docs = [];
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if (taken.has(`${r}:${c}`)) continue;
      docs.push({ expo: expo._id, code: `${rowLetter(r)}${c + 1}`, row: r, col: c, price, size, hall });
    }
  }
  if (!docs.length) return 0;
  try {
    await Booth.insertMany(docs, { ordered: false });
    return docs.length;
  } catch (err) {
    // a custom booth code may already exist — keep every booth that could be created
    if (err.code === 11000 || err.writeErrors) return err.insertedDocs?.length ?? docs.length - (err.writeErrors?.length || 0);
    throw err;
  }
}

/* ------------------------------------------------------------------ */
/* Exhibitor directory for an expo                                    */
/* ------------------------------------------------------------------ */

/** GET /api/expos/:id/exhibitors?q=&category= */
export const expoExhibitors = asyncHandler(async (req, res) => {
  assertId(req.params.id, "expo id");
  const booths = await Booth.find({ expo: req.params.id, status: "occupied", exhibitor: { $ne: null } })
    .populate("exhibitor", "name avatar company privacy role")
    .lean();

  const { q, category } = req.query;
  const rx = q ? new RegExp(escapeRegex(q), "i") : null;
  const items = booths
    .filter((b) => b.exhibitor && b.exhibitor.privacy?.profilePublic !== false)
    .map((b) => ({
      booth: { _id: b._id, code: b.code, hall: b.hall, row: b.row, col: b.col, products: b.products, description: b.description },
      exhibitor: {
        _id: b.exhibitor._id,
        name: b.exhibitor.name,
        avatar: b.exhibitor.avatar,
        company: pick(b.exhibitor.company || {}, ["name", "logo", "description", "website", "category", "products", "contactEmail"]),
      },
    }))
    .filter((x) => !category || x.exhibitor.company.category === category)
    .filter((x) => {
      if (!rx) return true;
      const c = x.exhibitor.company;
      return [c.name, c.description, c.category, ...(c.products || []), ...(x.booth.products || []), x.booth.code].some((v) => rx.test(v || ""));
    })
    .sort((a, b) => (a.exhibitor.company.name || "").localeCompare(b.exhibitor.company.name || ""));

  const categories = [...new Set(booths.map((b) => b.exhibitor?.company?.category).filter(Boolean))].sort();
  res.json({ items, categories });
});

/* ------------------------------------------------------------------ */
/* Attendee registration                                               */
/* ------------------------------------------------------------------ */

/** POST /api/expos/:id/register */
export const registerForExpo = asyncHandler(async (req, res) => {
  assertId(req.params.id, "expo id");
  const expo = await Expo.findById(req.params.id);
  if (!expo || expo.status !== "published") throw new ApiError(404, "Expo is not open for registration");
  if (expo.endDate < new Date()) throw new ApiError(400, "This expo has already ended");

  let reg = await Registration.findOne({ expo: expo._id, attendee: req.user._id });
  if (reg?.status === "confirmed") throw new ApiError(409, "You're already registered for this expo");

  if (expo.capacity) {
    const count = await Registration.countDocuments({ expo: expo._id, status: "confirmed" });
    if (count >= expo.capacity) throw new ApiError(400, "Sorry — this expo is fully booked");
  }

  if (reg) {
    reg.status = "confirmed";
    await reg.save();
  } else {
    reg = await Registration.create({ expo: expo._id, attendee: req.user._id, ticketCode: ticketCode() });
  }

  await notify(req.user._id, {
    type: "info",
    title: `You're registered: ${expo.title}`,
    body: `Your ticket code is ${reg.ticketCode}. Show the QR at the entrance.`,
    link: "/dashboard/tickets",
  });
  emitToExpo(expo._id, "analytics:update", { expoId: expo._id, kind: "registration" });
  logActivity(req, "expo.register", "Expo", expo._id);
  res.status(201).json({ registration: reg });
});

/** DELETE /api/expos/:id/register */
export const cancelRegistration = asyncHandler(async (req, res) => {
  assertId(req.params.id, "expo id");
  const reg = await Registration.findOne({ expo: req.params.id, attendee: req.user._id, status: "confirmed" });
  if (!reg) throw new ApiError(404, "No active registration found");
  reg.status = "cancelled";
  await reg.save();
  // also leave the expo's sessions
  await Session.updateMany({ expo: req.params.id }, { $pull: { attendees: req.user._id } });
  emitToExpo(req.params.id, "analytics:update", { expoId: req.params.id, kind: "registration" });
  logActivity(req, "expo.unregister", "Expo", req.params.id);
  res.json({ message: "Registration cancelled" });
});

/** GET /api/expos/:id/registrations (staff) */
export const expoRegistrations = asyncHandler(async (req, res) => {
  const expo = await getManageableExpo(req, req.params.id);
  const items = await Registration.find({ expo: expo._id })
    .populate("attendee", "name email")
    .sort({ createdAt: -1 })
    .lean();
  res.json({ items });
});

/** GET /api/registrations/mine */
export const myRegistrations = asyncHandler(async (req, res) => {
  const regs = await Registration.find({ attendee: req.user._id, status: "confirmed" })
    .populate("expo", "title startDate endDate location banner status")
    .sort({ createdAt: -1 })
    .lean();
  const items = await Promise.all(
    regs
      .filter((r) => r.expo)
      .map(async (r) => ({ ...r, qr: await QRCode.toDataURL(r.ticketCode, { margin: 1, width: 240 }) }))
  );
  res.json({ items });
});

/** POST /api/registrations/check-in  { ticketCode } (staff) */
export const checkIn = asyncHandler(async (req, res) => {
  requireFields(req.body, ["ticketCode"]);
  const reg = await Registration.findOne({ ticketCode: String(req.body.ticketCode).trim().toUpperCase() })
    .populate("attendee", "name email")
    .populate("expo", "title organizer");
  if (!reg || reg.status !== "confirmed") throw new ApiError(404, "Ticket not found or cancelled");
  if (!canManageExpo(req.user, reg.expo)) throw new ApiError(403, "This ticket belongs to another organizer's expo");
  if (reg.checkedIn) return res.json({ registration: reg, already: true, message: `${reg.attendee.name} already checked in` });
  reg.checkedIn = true;
  reg.checkedInAt = new Date();
  await reg.save();
  emitToExpo(reg.expo._id, "analytics:update", { expoId: reg.expo._id, kind: "checkin" });
  res.json({ registration: reg, message: `Welcome, ${reg.attendee.name}!` });
});

/* ------------------------------------------------------------------ */
/* Public exhibitor directory across expos                             */
/* ------------------------------------------------------------------ */

/** GET /api/exhibitors?q=&category= */
export const listExhibitors = asyncHandler(async (req, res) => {
  const { q, category } = req.query;
  const filter = { role: "exhibitor", status: "active", "privacy.profilePublic": { $ne: false } };
  if (category) filter["company.category"] = category;
  if (q) {
    const rx = new RegExp(escapeRegex(q), "i");
    filter.$or = [{ name: rx }, { "company.name": rx }, { "company.description": rx }, { "company.products": rx }, { "company.category": rx }];
  }
  const users = await User.find(filter).sort({ "company.name": 1 }).limit(100);
  const booths = await Booth.find({ exhibitor: { $in: users.map((u) => u._id) } })
    .populate("expo", "title startDate status")
    .select("code expo exhibitor hall")
    .lean();
  const items = users.map((u) => ({
    ...u.toPublic(),
    booths: booths.filter((b) => String(b.exhibitor) === String(u._id) && b.expo),
  }));
  const categories = await User.distinct("company.category", { role: "exhibitor" });
  res.json({ items, categories: categories.filter(Boolean).sort() });
});

/** GET /api/exhibitors/:id */
export const getExhibitor = asyncHandler(async (req, res) => {
  assertId(req.params.id, "exhibitor id");
  const user = await User.findOne({ _id: req.params.id, role: "exhibitor" });
  if (!user || (user.privacy?.profilePublic === false && !isStaff(req.user) && String(req.user?._id) !== String(user._id))) {
    throw new ApiError(404, "Exhibitor not found");
  }
  const booths = await Booth.find({ exhibitor: user._id })
    .populate("expo", "title startDate endDate location status floorPlan")
    .lean();
  res.json({ exhibitor: { ...user.toPublic(), allowMessages: user.privacy?.allowMessages !== false }, booths: booths.filter((b) => b.expo) });
});

