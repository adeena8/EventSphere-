import mongoose from "mongoose";
import { Message, User, Booth, ExhibitorApplication, Expo, Registration } from "../models/index.js";
import { notify } from "../services/notify.js";
import { emitToUser, isOnline } from "../services/socket.js";
import { ApiError, asyncHandler, requireFields, assertId, escapeRegex } from "../utils/helpers.js";

const PARTNER_FIELDS = "name avatar role company.name company.logo";

/** Who is allowed to start a conversation with whom */
function canMessage(from, to) {
  if (!to || to.status !== "active") return false;
  if (String(from._id) === String(to._id)) return false;
  if (["admin", "organizer"].includes(from.role)) return true;
  if (["admin", "organizer"].includes(to.role)) return true; // anyone can contact organizers/support
  if (to.privacy?.allowMessages === false) return false;
  if (from.role === "attendee") return to.role === "exhibitor";
  if (from.role === "exhibitor") return ["exhibitor", "attendee"].includes(to.role);
  return false;
}

/** GET /api/messages/conversations */
export const conversations = asyncHandler(async (req, res) => {
  const me = new mongoose.Types.ObjectId(String(req.user._id));
  const rows = await Message.aggregate([
    { $match: { $or: [{ from: me }, { to: me }] } },
    { $sort: { createdAt: -1 } },
    {
      $group: {
        _id: { $cond: [{ $eq: ["$from", me] }, "$to", "$from"] },
        last: { $first: "$$ROOT" },
        unread: { $sum: { $cond: [{ $and: [{ $eq: ["$to", me] }, { $eq: ["$read", false] }] }, 1, 0] } },
      },
    },
    { $sort: { "last.createdAt": -1 } },
    { $limit: 100 },
  ]);
  const partners = await User.find({ _id: { $in: rows.map((r) => r._id) } }).select(PARTNER_FIELDS).lean();
  const items = rows
    .map((r) => ({
      partner: partners.find((p) => String(p._id) === String(r._id)),
      lastMessage: { body: r.last.body, createdAt: r.last.createdAt, fromMe: String(r.last.from) === String(me) },
      unread: r.unread,
      online: isOnline(r._id),
    }))
    .filter((x) => x.partner);
  res.json({ items });
});

/** GET /api/messages/with/:userId */
export const thread = asyncHandler(async (req, res) => {
  assertId(req.params.userId, "user id");
  const other = await User.findById(req.params.userId).select(PARTNER_FIELDS + " privacy status");
  if (!other) throw new ApiError(404, "User not found");
  const me = req.user._id;
  const items = await Message.find({
    $or: [
      { from: me, to: other._id },
      { from: other._id, to: me },
    ],
  })
    .sort({ createdAt: 1 })
    .limit(500)
    .lean();
  const { modifiedCount } = await Message.updateMany({ from: other._id, to: me, read: false }, { $set: { read: true } });
  if (modifiedCount) emitToUser(other._id, "message:read", { by: String(me) });
  res.json({
    partner: { _id: other._id, name: other.name, avatar: other.avatar, role: other.role, company: other.company?.name ? { name: other.company.name, logo: other.company.logo } : undefined },
    online: isOnline(other._id),
    canReply: canMessage(req.user, other) || items.length > 0,
    items,
  });
});

/** POST /api/messages { to, body, expo? } */
export const send = asyncHandler(async (req, res) => {
  requireFields(req.body, ["to", "body"]);
  assertId(req.body.to, "recipient");
  const to = await User.findById(req.body.to);
  if (!to) throw new ApiError(404, "Recipient not found");

  const hasThread = await Message.exists({ from: to._id, to: req.user._id });
  if (!canMessage(req.user, to) && !hasThread) throw new ApiError(403, "You can't message this user");

  const msg = await Message.create({
    from: req.user._id,
    to: to._id,
    body: String(req.body.body).slice(0, 4000),
    expo: req.body.expo && mongoose.isValidObjectId(req.body.expo) ? req.body.expo : undefined,
  });
  const payload = { ...msg.toObject(), fromUser: { _id: req.user._id, name: req.user.name, avatar: req.user.avatar } };
  emitToUser(to._id, "message:new", payload);
  emitToUser(req.user._id, "message:new", payload);

  // only create a notification when the recipient is offline (avoids noise)
  if (!isOnline(to._id)) {
    await notify(to._id, {
      type: "message",
      title: `New message from ${req.user.company?.name || req.user.name}`,
      body: msg.body.slice(0, 140),
      link: `/dashboard/messages/${req.user._id}`,
    });
  }
  res.status(201).json({ message: msg });
});

/** GET /api/messages/unread-count */
export const unreadCount = asyncHandler(async (req, res) => {
  const count = await Message.countDocuments({ to: req.user._id, read: false });
  res.json({ count });
});

/**
 * GET /api/messages/contacts?q=
 * Suggested people to message, depending on role:
 *  - organizers of my expos (exhibitor/attendee)
 *  - neighbouring exhibitors (exhibitor)
 *  - exhibitors of expos I registered for (attendee)
 *  - search by name/company
 */
export const contacts = asyncHandler(async (req, res) => {
  const me = req.user;
  const groups = [];

  if (me.role === "exhibitor") {
    const myBooths = await Booth.find({ exhibitor: me._id }).lean();
    const expoIds = (await ExhibitorApplication.find({ exhibitor: me._id }).distinct("expo"));
    const orgIds = await Expo.find({ _id: { $in: expoIds } }).distinct("organizer");
    groups.push({ label: "Organizers", ids: orgIds });
    const nb = [];
    for (const b of myBooths) {
      const near = await Booth.find({
        expo: b.expo,
        exhibitor: { $nin: [null, me._id] },
        row: { $gte: b.row - 1, $lte: b.row + 1 },
        col: { $gte: b.col - 1, $lte: b.col + 1 },
      }).distinct("exhibitor");
      nb.push(...near);
    }
    groups.push({ label: "Neighbouring exhibitors", ids: nb });
  }
  if (me.role === "attendee") {
    const expoIds = await Registration.find({ attendee: me._id, status: "confirmed" }).distinct("expo");
    const exIds = await Booth.find({ expo: { $in: expoIds }, exhibitor: { $ne: null } }).distinct("exhibitor");
    groups.push({ label: "Exhibitors at your expos", ids: exIds });
    const orgIds = await Expo.find({ _id: { $in: expoIds } }).distinct("organizer");
    groups.push({ label: "Organizers", ids: orgIds });
  }

  const result = [];
  const seen = new Set([String(me._id)]);
  for (const g of groups) {
    const ids = g.ids.filter((id) => id && !seen.has(String(id)));
    ids.forEach((id) => seen.add(String(id)));
    if (!ids.length) continue;
    const users = await User.find({ _id: { $in: ids }, status: "active" }).select(PARTNER_FIELDS).limit(50).lean();
    if (users.length) result.push({ label: g.label, users });
  }

  if (req.query.q) {
    const rx = new RegExp(escapeRegex(req.query.q), "i");
    const roleFilter =
      me.role === "attendee" ? { role: { $in: ["exhibitor", "organizer", "admin"] } }
      : me.role === "exhibitor" ? { role: { $in: ["exhibitor", "organizer", "admin", "attendee"] } }
      : {};
    const users = await User.find({
      ...roleFilter,
      status: "active",
      _id: { $ne: me._id },
      $or: ["admin", "organizer"].includes(me.role)
        ? [{ name: rx }, { "company.name": rx }, { email: rx }]
        : [{ name: rx }, { "company.name": rx }],
    })
      .select(PARTNER_FIELDS)
      .limit(20)
      .lean();
    result.unshift({ label: "Search results", users });
  } else if (["admin", "organizer"].includes(me.role)) {
    const users = await User.find({ _id: { $ne: me._id }, status: "active", role: { $in: ["exhibitor", "organizer", "admin"] } })
      .select(PARTNER_FIELDS)
      .limit(40)
      .lean();
    result.push({ label: "Exhibitors & staff", users });
  } else {
    const staff = await User.find({ role: "admin", status: "active" }).select(PARTNER_FIELDS).limit(3).lean();
    result.push({ label: "Support", users: staff.filter((u) => !seen.has(String(u._id))) });
  }
  res.json({ groups: result.filter((g) => g.users.length) });
});
