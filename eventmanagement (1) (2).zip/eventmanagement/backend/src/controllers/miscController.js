/**
 * Notifications, feedback/support, gallery, admin user management,
 * activity logs, backups.
 */
import { Notification, Feedback, GalleryItem, User, Activity, Expo, Registration, ExhibitorApplication } from "../models/index.js";
import { notify, notifyRole, logActivity } from "../services/notify.js";
import { emitToStaff, onlineUsers } from "../services/socket.js";
import { runBackup, listBackups } from "../services/backup.js";
import { sendMail } from "../services/mailer.js";
import { purgeUser } from "./authController.js";
import {
  ApiError, asyncHandler, pick, requireFields, assertId, escapeRegex, EMAIL_RE, fileUrl, isId,
} from "../utils/helpers.js";

/* ============================ Notifications ============================ */

export const listNotifications = asyncHandler(async (req, res) => {
  const limit = Math.min(100, Number(req.query.limit) || 50);
  const filter = { user: req.user._id };
  if (req.query.unread === "1") filter.read = false;
  const [items, unread] = await Promise.all([
    Notification.find(filter).sort({ createdAt: -1 }).limit(limit).lean(),
    Notification.countDocuments({ user: req.user._id, read: false }),
  ]);
  res.json({ items, unread });
});

export const markRead = asyncHandler(async (req, res) => {
  assertId(req.params.id);
  await Notification.updateOne({ _id: req.params.id, user: req.user._id }, { $set: { read: true } });
  res.json({ ok: true });
});

export const markAllRead = asyncHandler(async (req, res) => {
  await Notification.updateMany({ user: req.user._id, read: false }, { $set: { read: true } });
  res.json({ ok: true });
});

export const deleteNotification = asyncHandler(async (req, res) => {
  assertId(req.params.id);
  await Notification.deleteOne({ _id: req.params.id, user: req.user._id });
  res.json({ ok: true });
});

/** POST /api/notifications/broadcast { title, body, audience: all|attendee|exhibitor|organizer|expo, expo? } (staff) */
export const broadcast = asyncHandler(async (req, res) => {
  requireFields(req.body, ["title", "body"]);
  const { title, body, audience = "all", expo } = req.body;
  let sent;
  if (audience === "expo") {
    assertId(expo, "expo id");
    const ex = await Expo.findById(expo);
    if (!ex) throw new ApiError(404, "Expo not found");
    if (req.user.role !== "admin" && String(ex.organizer) !== String(req.user._id)) throw new ApiError(403, "Not your expo");
    const a = await Registration.find({ expo, status: "confirmed" }).distinct("attendee");
    const e = await ExhibitorApplication.find({ expo, status: "approved" }).distinct("exhibitor");
    sent = await notify([...a, ...e], { type: "announcement", title, body, link: `/expos/${expo}` });
  } else {
    if (req.user.role !== "admin" && audience !== "exhibitor" && audience !== "attendee") {
      throw new ApiError(403, "Organizers can broadcast to attendees, exhibitors or their expo only");
    }
    sent = await notifyRole(audience, { type: "announcement", title, body });
  }
  logActivity(req, "broadcast", "Notification", null, { audience, count: sent.length });
  res.json({ sent: sent.length });
});

/* ============================ Feedback & support ============================ */

/** POST /api/feedback (public, optional auth) — also used by the Contact page */
export const createFeedback = asyncHandler(async (req, res) => {
  requireFields(req.body, ["subject", "message"]);
  const data = pick(req.body, ["type", "subject", "message", "rating"]);
  if (req.body.expo && isId(req.body.expo)) data.expo = req.body.expo;
  if (req.user) {
    data.user = req.user._id;
    data.name = req.user.name;
    data.email = req.user.email;
  } else {
    requireFields(req.body, ["name", "email"]);
    if (!EMAIL_RE.test(req.body.email)) throw new ApiError(400, "Please enter a valid email");
    data.name = String(req.body.name).slice(0, 80);
    data.email = req.body.email;
  }
  if (data.rating !== undefined && data.rating !== "") data.rating = Math.min(5, Math.max(1, Number(data.rating)));
  else delete data.rating;

  const fb = await Feedback.create(data);
  await notifyRole("admin", {
    type: "feedback",
    title: `New ${fb.type}: ${fb.subject}`,
    body: `${fb.name || "Someone"} wrote: ${fb.message.slice(0, 120)}`,
    link: "/dashboard/feedback",
  });
  emitToStaff("feedback:new", { id: fb._id });
  res.status(201).json({ feedback: fb, message: "Thank you! Your message has been received." });
});

export const myFeedback = asyncHandler(async (req, res) => {
  const items = await Feedback.find({ user: req.user._id }).populate("expo", "title").sort({ createdAt: -1 }).lean();
  res.json({ items });
});

/** GET /api/feedback?status=&type= (staff) */
export const listFeedback = asyncHandler(async (req, res) => {
  const filter = pick(req.query, ["status", "type"]);
  if (req.user.role === "organizer") {
    const mine = await Expo.find({ organizer: req.user._id }).distinct("_id");
    filter.$or = [{ expo: { $in: mine } }, { expo: null }];
  }
  const items = await Feedback.find(filter).populate("expo", "title").sort({ createdAt: -1 }).limit(300).lean();
  const avg = await Feedback.aggregate([{ $match: { rating: { $ne: null } } }, { $group: { _id: null, avg: { $avg: "$rating" }, n: { $sum: 1 } } }]);
  res.json({ items, avgRating: avg[0]?.avg || null, ratings: avg[0]?.n || 0 });
});

/** PATCH /api/feedback/:id { status, response } (staff) */
export const respondFeedback = asyncHandler(async (req, res) => {
  assertId(req.params.id);
  const fb = await Feedback.findById(req.params.id);
  if (!fb) throw new ApiError(404, "Feedback not found");
  if (req.body.status) fb.status = req.body.status;
  if (req.body.response !== undefined) {
    fb.response = req.body.response;
    fb.respondedBy = req.user._id;
  }
  await fb.save();
  if (req.body.response) {
    if (fb.user) {
      await notify(fb.user, { type: "feedback", title: `Reply to "${fb.subject}"`, body: fb.response.slice(0, 200), link: "/dashboard/support" });
    } else if (fb.email) {
      await sendMail({ to: fb.email, subject: `Re: ${fb.subject}`, text: fb.response });
    }
  }
  res.json({ feedback: fb });
});

/* ============================ Gallery ============================ */

export const listGallery = asyncHandler(async (req, res) => {
  const filter = req.query.expo && isId(req.query.expo) ? { expo: req.query.expo } : {};
  const items = await GalleryItem.find(filter).populate("expo", "title").sort({ createdAt: -1 }).limit(200).lean();
  res.json({ items });
});

export const addGallery = asyncHandler(async (req, res) => {
  const url = req.file ? fileUrl(req.file, "gallery") : req.body.url;
  if (!url) throw new ApiError(400, "Upload an image or provide an image URL");
  const item = await GalleryItem.create({
    url,
    caption: req.body.caption,
    expo: req.body.expo && isId(req.body.expo) ? req.body.expo : null,
    uploadedBy: req.user._id,
  });
  res.status(201).json({ item });
});

export const deleteGallery = asyncHandler(async (req, res) => {
  assertId(req.params.id);
  await GalleryItem.deleteOne({ _id: req.params.id });
  res.json({ ok: true });
});

/* ============================ Admin: users ============================ */

export const listUsers = asyncHandler(async (req, res) => {
  const filter = {};
  if (req.query.role) filter.role = req.query.role;
  if (req.query.status) filter.status = req.query.status;
  if (req.query.q) {
    const rx = new RegExp(escapeRegex(req.query.q), "i");
    filter.$or = [{ name: rx }, { email: rx }, { "company.name": rx }];
  }
  const items = await User.find(filter).sort({ createdAt: -1 }).limit(500);
  const online = new Set(onlineUsers());
  res.json({ items: items.map((u) => ({ ...u.toJSON(), online: online.has(String(u._id)) })) });
});

export const updateUser = asyncHandler(async (req, res) => {
  assertId(req.params.id);
  const user = await User.findById(req.params.id);
  if (!user) throw new ApiError(404, "User not found");
  if (String(user._id) === String(req.user._id) && (req.body.role || req.body.status)) {
    throw new ApiError(400, "You cannot change your own role or status");
  }
  const prevStatus = user.status;
  const data = pick(req.body, ["role", "status", "name"]);
  if (data.role && !["admin", "organizer", "exhibitor", "attendee"].includes(data.role)) throw new ApiError(400, "Invalid role");
  if (data.status && !["active", "pending", "suspended"].includes(data.status)) throw new ApiError(400, "Invalid status");
  Object.assign(user, data);
  await user.save();
  if (prevStatus === "pending" && user.status === "active") {
    await sendMail({ to: user.email, subject: "Your EventSphere organizer account is approved", text: `Hi ${user.name}, you can now log in and create expos.` });
  }
  logActivity(req, "user.update", "User", user._id, data);
  res.json({ user });
});

export const deleteUser = asyncHandler(async (req, res) => {
  assertId(req.params.id);
  if (String(req.params.id) === String(req.user._id)) throw new ApiError(400, "Use account settings to delete your own account");
  const user = await User.findById(req.params.id);
  if (!user) throw new ApiError(404, "User not found");
  if (user.role === "organizer" && (await Expo.exists({ organizer: user._id }))) {
    throw new ApiError(400, "This organizer still owns expos — reassign or delete them first");
  }
  await purgeUser(user._id);
  logActivity(req, "user.delete", "User", user._id, { email: user.email });
  res.json({ message: "User deleted" });
});

/* ============================ Admin: monitoring ============================ */

export const activityLog = asyncHandler(async (req, res) => {
  const filter = {};
  if (req.query.action) filter.action = new RegExp("^" + escapeRegex(req.query.action));
  const items = await Activity.find(filter).populate("user", "name email role").sort({ createdAt: -1 }).limit(Math.min(500, Number(req.query.limit) || 200)).lean();
  res.json({ items });
});

export const backups = asyncHandler(async (_req, res) => {
  res.json({ items: listBackups() });
});

export const backupNow = asyncHandler(async (req, res) => {
  const result = await runBackup();
  logActivity(req, "backup.run", null, null, result);
  res.json(result);
});

export const systemHealth = asyncHandler(async (_req, res) => {
  const mem = process.memoryUsage();
  res.json({
    uptimeSeconds: Math.round(process.uptime()),
    memoryMB: Math.round(mem.rss / 1048576),
    node: process.version,
    onlineUsers: onlineUsers().length,
  });
});
