import { Session, Expo, Registration } from "../models/index.js";
import { canManageExpo } from "../middleware/auth.js";
import { notify, logActivity } from "../services/notify.js";
import { emitToExpo } from "../services/socket.js";
import { getManageableExpo } from "./expoController.js";
import { ApiError, asyncHandler, pick, requireFields, assertId, parseJSON } from "../utils/helpers.js";

const FIELDS = ["title", "topic", "description", "type", "location", "startTime", "endTime", "capacity"];

function shape(s, userId) {
  const o = typeof s.toJSON === "function" ? s.toJSON() : s;
  const uid = userId ? String(userId) : null;
  const attendees = (o.attendees || []).map(String);
  const bookmarks = (o.bookmarkedBy || []).map(String);
  return {
    ...o,
    attendees: undefined,
    bookmarkedBy: undefined,
    remindedUsers: undefined,
    registeredCount: attendees.length,
    bookmarkCount: bookmarks.length,
    isRegistered: uid ? attendees.includes(uid) : false,
    isBookmarked: uid ? bookmarks.includes(uid) : false,
    seatsLeft: o.capacity ? Math.max(0, o.capacity - attendees.length) : null,
  };
}

async function loadManageable(req) {
  assertId(req.params.id, "session id");
  const session = await Session.findById(req.params.id);
  if (!session) throw new ApiError(404, "Session not found");
  const expo = await Expo.findById(session.expo);
  if (!canManageExpo(req.user, expo)) throw new ApiError(403, "Not your expo");
  return { session, expo };
}

async function checkConflict(expoId, location, start, end, excludeId) {
  if (!location) return;
  const clash = await Session.findOne({
    expo: expoId,
    location,
    _id: { $ne: excludeId },
    startTime: { $lt: end },
    endTime: { $gt: start },
  }).lean();
  if (clash) throw new ApiError(409, `"${location}" is already booked for "${clash.title}" at that time`);
}

/** GET /api/expos/:id/sessions?day=YYYY-MM-DD&type= */
export const listSessions = asyncHandler(async (req, res) => {
  assertId(req.params.id, "expo id");
  const filter = { expo: req.params.id };
  if (req.query.type) filter.type = req.query.type;
  if (req.query.day) {
    const d = new Date(req.query.day);
    if (!Number.isNaN(+d)) filter.startTime = { $gte: d, $lt: new Date(+d + 86400000) };
  }
  const items = await Session.find(filter).sort({ startTime: 1 });
  res.json({ items: items.map((s) => shape(s, req.user?._id)) });
});

/** POST /api/sessions (staff) */
export const createSession = asyncHandler(async (req, res) => {
  requireFields(req.body, ["expo", "title", "startTime", "endTime"]);
  const expo = await getManageableExpo(req, req.body.expo);
  const data = pick(req.body, FIELDS);
  const speaker = parseJSON(req.body.speaker, undefined);
  if (speaker) data.speaker = pick(speaker, ["name", "title", "bio", "photo"]);

  const start = new Date(data.startTime);
  const end = new Date(data.endTime);
  if (start < new Date(expo.startDate).setHours(0, 0, 0, 0) || start > new Date(expo.endDate).setHours(23, 59, 59, 999)) {
    throw new ApiError(400, "Session must take place during the expo dates");
  }
  await checkConflict(expo._id, data.location, start, end);

  const session = await Session.create({ ...data, expo: expo._id });
  emitToExpo(expo._id, "schedule:updated", { expoId: expo._id, sessionId: session._id, action: "created" });
  logActivity(req, "session.create", "Session", session._id);
  res.status(201).json({ session: shape(session) });
});

/** PUT /api/sessions/:id (staff) */
export const updateSession = asyncHandler(async (req, res) => {
  const { session, expo } = await loadManageable(req);
  const before = { start: +session.startTime, end: +session.endTime, location: session.location };
  Object.assign(session, pick(req.body, FIELDS));
  const speaker = parseJSON(req.body.speaker, undefined);
  if (speaker) session.speaker = pick(speaker, ["name", "title", "bio", "photo"]);
  await checkConflict(expo._id, session.location, session.startTime, session.endTime, session._id);
  await session.save();

  const timeChanged = before.start !== +session.startTime || before.end !== +session.endTime || before.location !== session.location;
  if (timeChanged) {
    // re-arm reminders and let interested people know
    await Session.updateOne({ _id: session._id }, { $set: { remindedUsers: [] } });
    const when = new Date(session.startTime).toLocaleString("en-GB", { dateStyle: "medium", timeStyle: "short" });
    await notify([...session.attendees, ...session.bookmarkedBy], {
      type: "schedule",
      title: `Schedule change: ${session.title}`,
      body: `Now ${when}${session.location ? ` · ${session.location}` : ""}.`,
      link: `/expos/${expo._id}?tab=schedule`,
    });
  }
  emitToExpo(expo._id, "schedule:updated", { expoId: expo._id, sessionId: session._id, action: "updated" });
  logActivity(req, "session.update", "Session", session._id);
  res.json({ session: shape(session) });
});

/** DELETE /api/sessions/:id (staff) */
export const deleteSession = asyncHandler(async (req, res) => {
  const { session, expo } = await loadManageable(req);
  await notify([...session.attendees, ...session.bookmarkedBy], {
    type: "schedule",
    title: `Session cancelled: ${session.title}`,
    body: `This session at ${expo.title} has been removed from the schedule.`,
    link: `/expos/${expo._id}?tab=schedule`,
  });
  await session.deleteOne();
  emitToExpo(expo._id, "schedule:updated", { expoId: expo._id, sessionId: session._id, action: "deleted" });
  res.json({ message: "Session deleted" });
});

/** POST /api/sessions/:id/register */
export const registerSession = asyncHandler(async (req, res) => {
  assertId(req.params.id, "session id");
  const session = await Session.findById(req.params.id);
  if (!session) throw new ApiError(404, "Session not found");
  if (session.endTime < new Date()) throw new ApiError(400, "This session has already finished");

  // attendees must hold an expo ticket; exhibitors/staff may join freely
  if (req.user.role === "attendee") {
    const hasTicket = await Registration.exists({ expo: session.expo, attendee: req.user._id, status: "confirmed" });
    if (!hasTicket) throw new ApiError(400, "Register for the expo first, then reserve sessions");
  }

  // atomic seat check
  const filter = { _id: session._id, attendees: { $ne: req.user._id } };
  if (session.capacity) filter[`attendees.${session.capacity - 1}`] = { $exists: false };
  const updated = await Session.findOneAndUpdate(filter, { $addToSet: { attendees: req.user._id } }, { new: true });
  if (!updated) {
    if (session.attendees.some((a) => String(a) === String(req.user._id))) throw new ApiError(409, "Already registered");
    throw new ApiError(400, "This session is full");
  }
  emitToExpo(session.expo, "schedule:updated", { expoId: session.expo, sessionId: session._id, action: "seats" });
  emitToExpo(session.expo, "analytics:update", { expoId: session.expo, kind: "session" });
  res.json({ session: shape(updated, req.user._id) });
});

/** DELETE /api/sessions/:id/register */
export const unregisterSession = asyncHandler(async (req, res) => {
  assertId(req.params.id, "session id");
  const s = await Session.findByIdAndUpdate(req.params.id, { $pull: { attendees: req.user._id } }, { new: true });
  if (!s) throw new ApiError(404, "Session not found");
  emitToExpo(s.expo, "schedule:updated", { expoId: s.expo, sessionId: s._id, action: "seats" });
  res.json({ session: shape(s, req.user._id) });
});

/** POST /api/sessions/:id/bookmark — toggle */
export const toggleBookmark = asyncHandler(async (req, res) => {
  assertId(req.params.id, "session id");
  const session = await Session.findById(req.params.id);
  if (!session) throw new ApiError(404, "Session not found");
  const has = session.bookmarkedBy.some((u) => String(u) === String(req.user._id));
  const updated = await Session.findByIdAndUpdate(
    session._id,
    has ? { $pull: { bookmarkedBy: req.user._id } } : { $addToSet: { bookmarkedBy: req.user._id } },
    { new: true }
  );
  res.json({ session: shape(updated, req.user._id), bookmarked: !has });
});

/** GET /api/sessions/mine — registered + bookmarked */
export const mySessions = asyncHandler(async (req, res) => {
  const items = await Session.find({ $or: [{ attendees: req.user._id }, { bookmarkedBy: req.user._id }] })
    .populate("expo", "title location")
    .sort({ startTime: 1 });
  res.json({ items: items.map((s) => shape(s, req.user._id)) });
});
