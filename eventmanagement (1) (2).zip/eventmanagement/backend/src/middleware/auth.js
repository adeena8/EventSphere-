import jwt from "jsonwebtoken";
import env from "../config/env.js";
import { User } from "../models/index.js";
import { ApiError, asyncHandler } from "../utils/helpers.js";

export function signToken(user) {
  return jwt.sign({ id: String(user._id), role: user.role }, env.jwtSecret, { expiresIn: env.jwtExpiresIn });
}

function readToken(req) {
  const h = req.headers.authorization || "";
  if (h.startsWith("Bearer ")) return h.slice(7);
  return null;
}

async function loadUser(token) {
  const payload = jwt.verify(token, env.jwtSecret);
  const user = await User.findById(payload.id);
  if (!user) throw new ApiError(401, "Account no longer exists");
  if (user.status === "suspended") throw new ApiError(403, "Account suspended — contact support");
  return user;
}

/** Requires a valid JWT */
export const protect = asyncHandler(async (req, _res, next) => {
  const token = readToken(req);
  if (!token) throw new ApiError(401, "Please log in to continue");
  try {
    req.user = await loadUser(token);
  } catch (err) {
    if (err instanceof ApiError) throw err;
    throw new ApiError(401, "Session expired — please log in again");
  }
  next();
});

/** Attaches req.user when a valid token is present, otherwise continues anonymously */
export const optionalAuth = asyncHandler(async (req, _res, next) => {
  const token = readToken(req);
  if (token) {
    try {
      req.user = await loadUser(token);
    } catch {
      req.user = undefined;
    }
  }
  next();
});

/** Role-based access control */
export const authorize =
  (...roles) =>
  (req, _res, next) => {
    if (!req.user) return next(new ApiError(401, "Please log in to continue"));
    if (!roles.includes(req.user.role)) return next(new ApiError(403, "You do not have permission for this action"));
    next();
  };

export const STAFF = ["admin", "organizer"];
export const isStaff = (user) => !!user && STAFF.includes(user.role);

/** Organizer owns the expo, or user is admin */
export function canManageExpo(user, expo) {
  if (!user || !expo) return false;
  if (user.role === "admin") return true;
  const owner = expo.organizer?._id || expo.organizer;
  return user.role === "organizer" && String(owner) === String(user._id);
}
