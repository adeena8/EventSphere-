import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import multer from "multer";
import rateLimit from "express-rate-limit";
import env from "../config/env.js";
import logger from "../services/logger.js";
import { ApiError } from "../utils/helpers.js";

/* ------------------------------------------------------------------ */
/* NoSQL-injection protection: strip keys beginning with "$" or with "." */
/* ------------------------------------------------------------------ */
function clean(obj) {
  if (!obj || typeof obj !== "object") return obj;
  for (const key of Object.keys(obj)) {
    if (key.startsWith("$") || key.includes(".")) delete obj[key];
    else clean(obj[key]);
  }
  return obj;
}
export function sanitize(req, _res, next) {
  clean(req.body);
  clean(req.params);
  clean(req.query);
  next();
}

/* ------------------------------------------------------------------ */
/* Rate limiters                                                       */
/* ------------------------------------------------------------------ */
export const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 600,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  skip: () => env.isTest,
});

export const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 30,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { message: "Too many attempts — please try again in a few minutes" },
  skip: () => env.isTest,
});

/* ------------------------------------------------------------------ */
/* File uploads                                                        */
/* ------------------------------------------------------------------ */
const IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp", "image/gif", "image/svg+xml"];
const DOC_TYPES = [...IMAGE_TYPES, "application/pdf", "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document"];

export function upload(folder, { docs = false, maxMB = 5 } = {}) {
  const dir = path.join(env.uploadsDir, folder);
  fs.mkdirSync(dir, { recursive: true });
  const storage = multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, dir),
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname).toLowerCase().replace(/[^.a-z0-9]/g, "");
      cb(null, `${Date.now()}-${crypto.randomBytes(6).toString("hex")}${ext}`);
    },
  });
  const allowed = docs ? DOC_TYPES : IMAGE_TYPES;
  return multer({
    storage,
    limits: { fileSize: maxMB * 1024 * 1024 },
    fileFilter: (_req, file, cb) =>
      allowed.includes(file.mimetype) ? cb(null, true) : cb(new ApiError(400, `File type not allowed: ${file.mimetype}`)),
  });
}

/* ------------------------------------------------------------------ */
/* 404 + error handler                                                 */
/* ------------------------------------------------------------------ */
export function notFound(req, _res, next) {
  next(new ApiError(404, `Route not found: ${req.method} ${req.originalUrl}`));
}

// eslint-disable-next-line no-unused-vars
export function errorHandler(err, req, res, _next) {
  let status = err.status || err.statusCode || 500;
  let message = err.message || "Something went wrong";
  let details = err.details;

  if (err.name === "ValidationError") {
    status = 400;
    details = Object.fromEntries(Object.entries(err.errors).map(([k, v]) => [k, v.message]));
    message = Object.values(details)[0] || "Validation failed";
  } else if (err.name === "CastError") {
    status = 400;
    message = `Invalid value for ${err.path}`;
  } else if (err.code === 11000) {
    status = 409;
    const field = Object.keys(err.keyValue || {})[0] || "value";
    message = field === "email" ? "An account with this email already exists" : `Duplicate ${field}`;
  } else if (err instanceof multer.MulterError) {
    status = 400;
    message = err.code === "LIMIT_FILE_SIZE" ? "File is too large" : err.message;
  } else if (err.type === "entity.parse.failed") {
    status = 400;
    message = "Malformed JSON body";
  }

  if (status >= 500) logger.error(`${req.method} ${req.originalUrl} → ${err.stack || err.message}`);

  res.status(status).json({
    message: status >= 500 && env.isProd ? "Internal server error" : message,
    ...(details ? { details } : {}),
  });
}
