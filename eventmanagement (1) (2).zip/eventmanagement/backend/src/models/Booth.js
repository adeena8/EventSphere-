import mongoose from "mongoose";

const staffSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    role: { type: String, trim: true },
    email: { type: String, trim: true, lowercase: true },
  },
  { _id: false }
);

const boothSchema = new mongoose.Schema(
  {
    expo: { type: mongoose.Schema.Types.ObjectId, ref: "Expo", required: true, index: true },
    code: { type: String, required: true, trim: true, uppercase: true }, // e.g. A1
    hall: { type: String, default: "Main Hall" },
    row: { type: Number, required: true, min: 0 },
    col: { type: Number, required: true, min: 0 },
    size: { type: String, enum: ["small", "medium", "large"], default: "medium" },
    price: { type: Number, min: 0, default: 0 },
    status: {
      type: String,
      enum: ["available", "reserved", "occupied", "blocked"],
      default: "available",
      index: true,
    },
    exhibitor: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null },
    application: { type: mongoose.Schema.Types.ObjectId, ref: "ExhibitorApplication", default: null },
    // details managed by the exhibitor once allocated
    displayName: String,
    description: { type: String, maxlength: 1000 },
    products: [{ type: String, trim: true }],
    staff: [staffSchema],
  },
  { timestamps: true }
);

boothSchema.index({ expo: 1, code: 1 }, { unique: true });
boothSchema.index({ expo: 1, row: 1, col: 1 }, { unique: true });

export default mongoose.model("Booth", boothSchema);
