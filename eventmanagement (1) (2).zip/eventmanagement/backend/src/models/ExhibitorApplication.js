import mongoose from "mongoose";

const applicationSchema = new mongoose.Schema(
  {
    expo: { type: mongoose.Schema.Types.ObjectId, ref: "Expo", required: true, index: true },
    exhibitor: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
    companyName: { type: String, required: true, trim: true },
    category: { type: String, trim: true },
    description: { type: String, maxlength: 2000 },
    products: [{ type: String, trim: true }],
    website: String,
    contactPerson: String,
    documents: [{ name: String, url: String }],
    preferredBooth: { type: mongoose.Schema.Types.ObjectId, ref: "Booth", default: null },
    assignedBooth: { type: mongoose.Schema.Types.ObjectId, ref: "Booth", default: null },
    status: { type: String, enum: ["pending", "approved", "rejected", "withdrawn"], default: "pending", index: true },
    reviewNote: String,
    reviewedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    reviewedAt: Date,
  },
  { timestamps: true }
);

applicationSchema.index({ expo: 1, exhibitor: 1 }, { unique: true });

export default mongoose.model("ExhibitorApplication", applicationSchema);
