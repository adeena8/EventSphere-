import mongoose from "mongoose";

const expoSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true, maxlength: 140 },
    description: { type: String, maxlength: 5000 },
    theme: { type: String, trim: true, maxlength: 120 },
    category: { type: String, trim: true, default: "Technology" },
    location: {
      venue: { type: String, trim: true },
      city: { type: String, trim: true },
      address: { type: String, trim: true },
    },
    startDate: { type: Date, required: true },
    endDate: { type: Date, required: true },
    banner: String,
    organizer: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    status: { type: String, enum: ["draft", "published", "cancelled", "completed"], default: "draft", index: true },
    capacity: { type: Number, min: 0, default: 0 }, // 0 = unlimited attendees
    floorPlan: {
      rows: { type: Number, min: 1, max: 30, default: 5 },
      cols: { type: Number, min: 1, max: 30, default: 8 },
      halls: [{ type: String }],
      notes: String,
    },
    tags: [{ type: String, trim: true }],
  },
  { timestamps: true, toJSON: { virtuals: true } }
);

expoSchema.index({ title: "text", description: "text", theme: "text", category: "text" });
expoSchema.index({ startDate: 1 });

expoSchema.pre("validate", function checkDates(next) {
  if (this.startDate && this.endDate && this.endDate < this.startDate) {
    this.invalidate("endDate", "End date must be after start date");
  }
  next();
});

export default mongoose.model("Expo", expoSchema);
