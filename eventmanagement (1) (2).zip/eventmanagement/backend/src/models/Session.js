import mongoose from "mongoose";

const sessionSchema = new mongoose.Schema(
  {
    expo: { type: mongoose.Schema.Types.ObjectId, ref: "Expo", required: true, index: true },
    title: { type: String, required: true, trim: true, maxlength: 160 },
    topic: { type: String, trim: true, maxlength: 120 },
    description: { type: String, maxlength: 3000 },
    type: { type: String, enum: ["keynote", "talk", "workshop", "panel", "networking"], default: "talk" },
    speaker: {
      name: { type: String, trim: true },
      title: { type: String, trim: true },
      bio: { type: String, maxlength: 1000 },
      photo: String,
    },
    location: { type: String, trim: true }, // hall / room
    startTime: { type: Date, required: true },
    endTime: { type: Date, required: true },
    capacity: { type: Number, min: 0, default: 0 }, // 0 = unlimited
    attendees: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
    bookmarkedBy: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
    remindedUsers: [{ type: mongoose.Schema.Types.ObjectId, ref: "User", select: false }],
  },
  { timestamps: true, toJSON: { virtuals: true } }
);

sessionSchema.index({ expo: 1, startTime: 1 });

sessionSchema.virtual("registeredCount").get(function count() {
  return this.attendees ? this.attendees.length : 0;
});

sessionSchema.pre("validate", function checkTimes(next) {
  if (this.startTime && this.endTime && this.endTime <= this.startTime) {
    this.invalidate("endTime", "End time must be after start time");
  }
  next();
});

export default mongoose.model("Session", sessionSchema);
