import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import { encrypt, decrypt } from "../utils/helpers.js";

export const ROLES = ["admin", "organizer", "exhibitor", "attendee"];

const companySchema = new mongoose.Schema(
  {
    name: { type: String, trim: true, maxlength: 120 },
    logo: String,
    description: { type: String, maxlength: 2000 },
    website: { type: String, trim: true },
    category: { type: String, trim: true, maxlength: 60 },
    products: [{ type: String, trim: true, maxlength: 80 }],
    contactEmail: { type: String, trim: true, lowercase: true },
    contactPhone: { type: String, set: encrypt, get: decrypt },
    address: { type: String, maxlength: 300 },
  },
  { _id: false, toJSON: { getters: true }, toObject: { getters: true } }
);

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 80 },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true, minlength: 8, select: false },
    role: { type: String, enum: ROLES, default: "attendee", index: true },
    status: { type: String, enum: ["active", "pending", "suspended"], default: "active" },
    phone: { type: String, set: encrypt, get: decrypt }, // encrypted at rest
    avatar: String,
    bio: { type: String, maxlength: 500 },
    company: { type: companySchema, default: () => ({}) },
    privacy: {
      consentAt: Date, // GDPR: when the user accepted the privacy policy
      profilePublic: { type: Boolean, default: true },
      allowMessages: { type: Boolean, default: true },
      marketingEmails: { type: Boolean, default: false },
    },
    resetPasswordToken: { type: String, select: false },
    resetPasswordExpires: { type: Date, select: false },
    lastLoginAt: Date,
  },
  {
    timestamps: true,
    toJSON: {
      getters: true,
      virtuals: true,
      transform: (_doc, ret) => {
        delete ret.password;
        delete ret.resetPasswordToken;
        delete ret.resetPasswordExpires;
        delete ret.__v;
        delete ret.id;
        return ret;
      },
    },
    toObject: { getters: true },
  }
);

userSchema.index({ name: "text", "company.name": "text", "company.description": "text", "company.products": "text" });

userSchema.pre("save", async function hashPassword() {
  if (!this.isModified("password")) return;
  this.password = await bcrypt.hash(this.password, 12);
});

userSchema.methods.comparePassword = function comparePassword(plain) {
  return bcrypt.compare(plain, this.password);
};

/** Public-safe representation (for exhibitor directory, chat partners…) */
userSchema.methods.toPublic = function toPublic() {
  const c = this.company || {};
  return {
    _id: this._id,
    name: this.name,
    role: this.role,
    avatar: this.avatar,
    bio: this.bio,
    company:
      this.role === "exhibitor"
        ? {
            name: c.name,
            logo: c.logo,
            description: c.description,
            website: c.website,
            category: c.category,
            products: c.products,
            contactEmail: c.contactEmail,
          }
        : undefined,
  };
};

export default mongoose.model("User", userSchema);
