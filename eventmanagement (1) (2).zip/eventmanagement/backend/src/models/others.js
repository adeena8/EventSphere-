/**
 * Smaller collections grouped in one file.
 */
import mongoose from "mongoose";

const { ObjectId } = mongoose.Schema.Types;

/* ---------------- Attendee expo registration (ticket) ---------------- */
const registrationSchema = new mongoose.Schema(
  {
    expo: { type: ObjectId, ref: "Expo", required: true, index: true },
    attendee: { type: ObjectId, ref: "User", required: true, index: true },
    ticketCode: { type: String, required: true, unique: true },
    status: { type: String, enum: ["confirmed", "cancelled"], default: "confirmed" },
    checkedIn: { type: Boolean, default: false },
    checkedInAt: Date,
  },
  { timestamps: true }
);
registrationSchema.index({ expo: 1, attendee: 1 }, { unique: true });
export const Registration = mongoose.model("Registration", registrationSchema);

/* ---------------- Direct messages ---------------- */
const messageSchema = new mongoose.Schema(
  {
    from: { type: ObjectId, ref: "User", required: true, index: true },
    to: { type: ObjectId, ref: "User", required: true, index: true },
    expo: { type: ObjectId, ref: "Expo" },
    body: { type: String, required: true, trim: true, maxlength: 4000 },
    read: { type: Boolean, default: false },
  },
  { timestamps: true }
);
messageSchema.index({ from: 1, to: 1, createdAt: -1 });
export const Message = mongoose.model("Message", messageSchema);

/* ---------------- Notifications ---------------- */
const notificationSchema = new mongoose.Schema(
  {
    user: { type: ObjectId, ref: "User", required: true, index: true },
    type: {
      type: String,
      enum: ["info", "schedule", "booth", "application", "message", "reminder", "announcement", "feedback"],
      default: "info",
    },
    title: { type: String, required: true },
    body: String,
    link: String,
    read: { type: Boolean, default: false },
  },
  { timestamps: true }
);
notificationSchema.index({ user: 1, createdAt: -1 });
export const Notification = mongoose.model("Notification", notificationSchema);

/* ---------------- Feedback & support tickets ---------------- */
const feedbackSchema = new mongoose.Schema(
  {
    user: { type: ObjectId, ref: "User", default: null },
    name: String,
    email: { type: String, lowercase: true, trim: true },
    expo: { type: ObjectId, ref: "Expo", default: null },
    type: { type: String, enum: ["suggestion", "issue", "feedback", "inquiry"], default: "feedback" },
    subject: { type: String, required: true, trim: true, maxlength: 160 },
    message: { type: String, required: true, maxlength: 4000 },
    rating: { type: Number, min: 1, max: 5 },
    status: { type: String, enum: ["open", "in_progress", "resolved"], default: "open", index: true },
    response: String,
    respondedBy: { type: ObjectId, ref: "User" },
  },
  { timestamps: true }
);
export const Feedback = mongoose.model("Feedback", feedbackSchema);

/* ---------------- Booth traffic (analytics) ---------------- */
const boothVisitSchema = new mongoose.Schema(
  {
    booth: { type: ObjectId, ref: "Booth", required: true, index: true },
    expo: { type: ObjectId, ref: "Expo", required: true, index: true },
    exhibitor: { type: ObjectId, ref: "User" },
    visitor: { type: ObjectId, ref: "User", default: null },
    source: { type: String, enum: ["profile", "floorplan", "checkin"], default: "profile" },
  },
  { timestamps: true }
);
export const BoothVisit = mongoose.model("BoothVisit", boothVisitSchema);

/* ---------------- Gallery ---------------- */
const galleryItemSchema = new mongoose.Schema(
  {
    url: { type: String, required: true },
    caption: { type: String, maxlength: 200 },
    expo: { type: ObjectId, ref: "Expo", default: null },
    uploadedBy: { type: ObjectId, ref: "User" },
  },
  { timestamps: true }
);
export const GalleryItem = mongoose.model("GalleryItem", galleryItemSchema);

/* ---------------- Activity log (monitoring) ---------------- */
const activitySchema = new mongoose.Schema(
  {
    user: { type: ObjectId, ref: "User", default: null },
    action: { type: String, required: true },
    entity: String,
    entityId: String,
    meta: mongoose.Schema.Types.Mixed,
    ip: String,
  },
  { timestamps: { createdAt: true, updatedAt: false } }
);
activitySchema.index({ createdAt: -1 });
// keep 90 days of activity
activitySchema.index({ createdAt: 1 }, { expireAfterSeconds: 60 * 60 * 24 * 90 });
export const Activity = mongoose.model("Activity", activitySchema);
