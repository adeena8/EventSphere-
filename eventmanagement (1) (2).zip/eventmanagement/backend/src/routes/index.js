import { Router } from "express";
import { protect, optionalAuth, authorize, STAFF } from "../middleware/auth.js";
import { upload, authLimiter } from "../middleware/common.js";
import * as auth from "../controllers/authController.js";
import * as expo from "../controllers/expoController.js";
import * as booth from "../controllers/boothController.js";
import * as appl from "../controllers/applicationController.js";
import * as session from "../controllers/sessionController.js";
import * as msg from "../controllers/messageController.js";
import * as misc from "../controllers/miscController.js";
import * as analytics from "../controllers/analyticsController.js";

const r = Router();
const staff = [protect, authorize(...STAFF)];
const admin = [protect, authorize("admin")];

/* ---------- Auth & account ---------- */
r.post("/auth/register", authLimiter, auth.register);
r.post("/auth/login", authLimiter, auth.login);
r.post("/auth/forgot-password", authLimiter, auth.forgotPassword);
r.post("/auth/reset-password/:token", authLimiter, auth.resetPassword);
r.get("/auth/me", protect, auth.me);
r.put(
  "/auth/me",
  protect,
  upload("avatars").fields([{ name: "avatar", maxCount: 1 }, { name: "logo", maxCount: 1 }]),
  auth.updateMe
);
r.put("/auth/privacy", protect, auth.updatePrivacy);
r.put("/auth/password", protect, auth.changePassword);
r.get("/auth/me/export", protect, auth.exportMyData);
r.delete("/auth/me", protect, auth.deleteMe);

/* ---------- Expos ---------- */
r.get("/expos", optionalAuth, expo.listExpos);
r.post("/expos", ...staff, upload("banners").single("banner"), expo.createExpo);
r.get("/expos/:id", optionalAuth, expo.getExpo);
r.put("/expos/:id", ...staff, upload("banners").single("banner"), expo.updateExpo);
r.delete("/expos/:id", ...staff, expo.deleteExpo);
r.get("/expos/:id/exhibitors", optionalAuth, expo.expoExhibitors);
r.get("/expos/:id/sessions", optionalAuth, session.listSessions);
r.get("/expos/:id/booths", optionalAuth, booth.listBooths);
r.post("/expos/:id/booths", ...staff, booth.createBooth);
r.post("/expos/:id/register", protect, authorize("attendee"), expo.registerForExpo);
r.delete("/expos/:id/register", protect, authorize("attendee"), expo.cancelRegistration);
r.get("/expos/:id/registrations", ...staff, expo.expoRegistrations);

/* ---------- Registrations / tickets ---------- */
r.get("/registrations/mine", protect, expo.myRegistrations);
r.post("/registrations/check-in", ...staff, expo.checkIn);

/* ---------- Booths ---------- */
r.get("/booths/mine", protect, authorize("exhibitor"), booth.myBooths);
r.get("/booths/exhibitor-options/:expoId", ...staff, booth.assignableExhibitors);
r.put("/booths/:id", ...staff, booth.updateBooth);
r.delete("/booths/:id", ...staff, booth.deleteBooth);
r.patch("/booths/:id/assign", ...staff, booth.assignBooth);
r.put("/booths/:id/details", protect, authorize("exhibitor", ...STAFF), booth.updateBoothDetails);
r.get("/booths/:id/neighbors", optionalAuth, booth.neighbors);
r.post("/booths/:id/visit", optionalAuth, booth.recordVisit);

/* ---------- Exhibitor directory ---------- */
r.get("/exhibitors", optionalAuth, expo.listExhibitors);
r.get("/exhibitors/:id", optionalAuth, expo.getExhibitor);

/* ---------- Exhibitor applications ---------- */
r.post("/applications", protect, authorize("exhibitor"), upload("documents", { docs: true, maxMB: 10 }).array("documents", 5), appl.apply);
r.get("/applications/mine", protect, authorize("exhibitor"), appl.myApplications);
r.get("/applications", ...staff, appl.listApplications);
r.patch("/applications/:id/status", ...staff, appl.reviewApplication);
r.delete("/applications/:id", protect, authorize("exhibitor"), appl.withdrawApplication);

/* ---------- Sessions / schedule ---------- */
r.get("/sessions/mine", protect, session.mySessions);
r.post("/sessions", ...staff, session.createSession);
r.put("/sessions/:id", ...staff, session.updateSession);
r.delete("/sessions/:id", ...staff, session.deleteSession);
r.post("/sessions/:id/register", protect, session.registerSession);
r.delete("/sessions/:id/register", protect, session.unregisterSession);
r.post("/sessions/:id/bookmark", protect, session.toggleBookmark);

/* ---------- Messaging ---------- */
r.get("/messages/conversations", protect, msg.conversations);
r.get("/messages/contacts", protect, msg.contacts);
r.get("/messages/unread-count", protect, msg.unreadCount);
r.get("/messages/with/:userId", protect, msg.thread);
r.post("/messages", protect, msg.send);

/* ---------- Notifications ---------- */
r.get("/notifications", protect, misc.listNotifications);
r.patch("/notifications/read-all", protect, misc.markAllRead);
r.patch("/notifications/:id/read", protect, misc.markRead);
r.delete("/notifications/:id", protect, misc.deleteNotification);
r.post("/notifications/broadcast", ...staff, misc.broadcast);

/* ---------- Feedback & support ---------- */
r.post("/feedback", optionalAuth, misc.createFeedback);
r.get("/feedback/mine", protect, misc.myFeedback);
r.get("/feedback", ...staff, misc.listFeedback);
r.patch("/feedback/:id", ...staff, misc.respondFeedback);

/* ---------- Gallery ---------- */
r.get("/gallery", misc.listGallery);
r.post("/gallery", ...staff, upload("gallery").single("image"), misc.addGallery);
r.delete("/gallery/:id", ...staff, misc.deleteGallery);

/* ---------- Analytics ---------- */
r.get("/analytics/overview", ...staff, analytics.overview);
r.get("/analytics/exhibitor", protect, authorize("exhibitor"), analytics.exhibitorStats);

/* ---------- Admin ---------- */
r.get("/admin/users", ...admin, misc.listUsers);
r.patch("/admin/users/:id", ...admin, misc.updateUser);
r.delete("/admin/users/:id", ...admin, misc.deleteUser);
r.get("/admin/activity", ...admin, misc.activityLog);
r.get("/admin/backups", ...admin, misc.backups);
r.post("/admin/backups", ...admin, misc.backupNow);
r.get("/admin/system", ...admin, misc.systemHealth);

export default r;
