/**
 * Seeds MongoDB with demo data.  Usage:  npm run seed
 * WARNING: clears all EventSphere collections first.
 */
import mongoose from "mongoose";
import { connectDB } from "../config/db.js";
import {
  User, Expo, Booth, ExhibitorApplication, Session, Registration, Message, Notification, Feedback, BoothVisit, GalleryItem, Activity,
} from "../models/index.js";
import { ticketCode } from "../utils/helpers.js";

const DAY = 86400000;
const img = (id, w = 1600) => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=${w}&q=75`;
const at = (base, dayOffset, h, m = 0) => {
  const d = new Date(+base + dayOffset * DAY);
  d.setHours(h, m, 0, 0);
  return d;
};
const rand = (arr) => arr[Math.floor(Math.random() * arr.length)];

export async function seed({ quiet = false } = {}) {
  const log = (...a) => !quiet && console.log(...a);

  await Promise.all(
    [User, Expo, Booth, ExhibitorApplication, Session, Registration, Message, Notification, Feedback, BoothVisit, GalleryItem, Activity].map((M) =>
      M.deleteMany({})
    )
  );
  await Promise.all([User, Expo, Booth, ExhibitorApplication, Registration].map((M) => M.syncIndexes()));

  /* ------------------------------ users ------------------------------ */
  const mk = (d) => User.create({ privacy: { consentAt: new Date() }, ...d });
  const admin = await mk({ name: "Ayesha Admin", email: "admin@eventsphere.com", password: "Admin@123", role: "admin", phone: "+92 300 1111111" });
  const organizer = await mk({ name: "Omar Organizer", email: "organizer@eventsphere.com", password: "Organizer@123", role: "organizer", phone: "+92 300 2222222", bio: "Head of expo operations at EventSphere." });
  const organizer2 = await mk({ name: "Hina Planner", email: "organizer2@eventsphere.com", password: "Organizer@123", role: "organizer" });
  await mk({ name: "Pending Organizer", email: "pending@eventsphere.com", password: "Organizer@123", role: "organizer", status: "pending" });

  const companies = [
    { name: "TechVision Labs", email: "techvision@eventsphere.com", category: "Technology", products: ["AI Vision Kits", "Smart Cameras", "Edge Computing"], logo: img("photo-1551434678-e076c223a692", 300), description: "Computer-vision hardware and AI software for retail and manufacturing." },
    { name: "CloudNest", email: "cloudnest@eventsphere.com", category: "Technology", products: ["Cloud Hosting", "DevOps Platform", "Managed Kubernetes"], logo: img("photo-1544197150-b99a580bb7a8", 300), description: "Cloud infrastructure that scales from startups to enterprises." },
    { name: "Nova Robotics", email: "nova@eventsphere.com", category: "Robotics", products: ["Warehouse Robots", "Cobots", "Drone Delivery"], logo: img("photo-1485827404703-89b55fcc595e", 300), description: "Autonomous robots for logistics and manufacturing." },
    { name: "GreenLeaf Energy", email: "greenleaf@eventsphere.com", category: "Energy", products: ["Solar Panels", "Battery Storage", "Smart Meters"], logo: img("photo-1509391366360-2e959784a276", 300), description: "Clean-energy solutions for homes and industry." },
    { name: "Artisan Foods Co.", email: "artisan@eventsphere.com", category: "Food & Beverage", products: ["Organic Spices", "Gourmet Sauces", "Tea Blends"], logo: img("photo-1504674900247-0877df9cc836", 300), description: "Small-batch gourmet foods sourced from local farmers." },
    { name: "MediCore Health", email: "medicore@eventsphere.com", category: "Healthcare", products: ["Telehealth Platform", "Wearable Monitors"], logo: img("photo-1576091160399-112ba8d25d1d", 300), description: "Digital health tools that connect patients and doctors." },
    { name: "PixelCraft Studio", email: "pixelcraft@eventsphere.com", category: "Design", products: ["Brand Identity", "UI/UX Design", "3D Visuals"], logo: img("photo-1561070791-2526d30994b5", 300), description: "Creative studio crafting brands and digital products." },
  ];
  const exhibitors = [];
  for (const c of companies) {
    exhibitors.push(
      await mk({
        name: `${c.name.split(" ")[0]} Team`,
        email: c.email,
        password: "Exhibitor@123",
        role: "exhibitor",
        company: { name: c.name, category: c.category, products: c.products, logo: c.logo, description: c.description, website: `https://${c.name.toLowerCase().replace(/[^a-z]/g, "")}.example.com`, contactEmail: c.email, contactPhone: "+92 21 555 0100" },
      })
    );
  }

  const attendees = [];
  for (const [name, email] of [
    ["Ali Raza", "ali@eventsphere.com"],
    ["Sara Khan", "sara@eventsphere.com"],
    ["Ahmed Siddiqui", "ahmed@eventsphere.com"],
    ["Fatima Noor", "fatima@eventsphere.com"],
    ["Bilal Hussain", "bilal@eventsphere.com"],
  ]) {
    attendees.push(await mk({ name, email, password: "Attendee@123", role: "attendee" }));
  }
  log(`✓ users: ${await User.countDocuments()}`);

  /* ------------------------------ expos ------------------------------ */
  const now = new Date();
  const expoDefs = [
    {
      title: "Global Tech Expo 2026",
      theme: "Intelligence Everywhere",
      category: "Technology",
      description: "Three days of AI, cloud, robotics and the future of work. 40 exhibitors, keynotes from industry leaders, hands-on workshops and a startup pitch arena.",
      location: { venue: "Expo Centre Karachi", city: "Karachi", address: "University Road, Gulshan-e-Iqbal" },
      start: 10, days: 3, rows: 5, cols: 8, price: 1200, capacity: 2000,
      banner: img("photo-1540575467063-178a50c2df87"), organizer, status: "published",
      tags: ["AI", "Cloud", "Robotics"],
    },
    {
      title: "Green Future Summit",
      theme: "Powering a Sustainable Decade",
      category: "Energy",
      description: "Renewable energy, sustainable manufacturing and climate-tech investors under one roof.",
      location: { venue: "Expo Centre Lahore", city: "Lahore", address: "Johar Town" },
      start: 28, days: 2, rows: 4, cols: 6, price: 900, capacity: 1200,
      banner: img("photo-1466611653911-95081537e5b7"), organizer, status: "published",
      tags: ["Solar", "Climate"],
    },
    {
      title: "Food & Hospitality Fair",
      theme: "Taste the Future",
      category: "Food & Beverage",
      description: "Gourmet producers, hospitality technology and live culinary demos from top chefs.",
      location: { venue: "Pak-China Friendship Centre", city: "Islamabad", address: "Garden Avenue" },
      start: 45, days: 2, rows: 4, cols: 7, price: 700, capacity: 1500,
      banner: img("photo-1555939594-58d7cb561ad1"), organizer: organizer2, status: "published",
      tags: ["Food", "Hospitality"],
    },
    {
      title: "Health Innovation Expo 2026",
      theme: "Care, Connected",
      category: "Healthcare",
      description: "Digital health, medical devices and hospital innovation. (Completed — see the gallery!)",
      location: { venue: "Expo Centre Karachi", city: "Karachi" },
      start: -20, days: 2, rows: 4, cols: 6, price: 1000, capacity: 800,
      banner: img("photo-1576091160550-2173dba999ef"), organizer, status: "completed",
      tags: ["Health"],
    },
    {
      title: "Auto & Mobility Show 2027",
      theme: "Electric Roads",
      category: "Automotive",
      description: "Draft — EVs, mobility startups and smart infrastructure.",
      location: { venue: "Expo Centre Lahore", city: "Lahore" },
      start: 120, days: 3, rows: 6, cols: 8, price: 1500, capacity: 3000,
      banner: img("photo-1492144534655-ae79c964c9d7"), organizer, status: "draft",
      tags: ["EV"],
    },
  ];

  const expos = [];
  for (const d of expoDefs) {
    const startDate = at(now, d.start, 9);
    const endDate = at(now, d.start + d.days - 1, 18);
    const expo = await Expo.create({
      title: d.title, theme: d.theme, category: d.category, description: d.description, location: d.location,
      startDate, endDate, banner: d.banner, organizer: d.organizer._id, status: d.status, capacity: d.capacity,
      floorPlan: { rows: d.rows, cols: d.cols, halls: ["Hall A", "Hall B"] }, tags: d.tags,
    });
    const booths = [];
    for (let r = 0; r < d.rows; r++) {
      for (let c = 0; c < d.cols; c++) {
        booths.push({
          expo: expo._id, code: `${String.fromCharCode(65 + r)}${c + 1}`, row: r, col: c,
          hall: c < d.cols / 2 ? "Hall A" : "Hall B",
          size: r === 0 ? "large" : c % 3 === 0 ? "small" : "medium",
          price: r === 0 ? d.price * 1.5 : d.price,
          status: (r === d.rows - 1 && c === d.cols - 1) ? "blocked" : "available",
        });
      }
    }
    await Booth.insertMany(booths);
    expos.push(expo);
  }
  const [tech, green, food, health] = expos;
  log(`✓ expos: ${expos.length}, booths: ${await Booth.countDocuments()}`);

  /* ---------------------- applications + allocations ---------------------- */
  async function approve(expo, ex, code) {
    const booth = await Booth.findOne({ expo: expo._id, code });
    const app = await ExhibitorApplication.create({
      expo: expo._id, exhibitor: ex._id, companyName: ex.company.name, category: ex.company.category,
      description: ex.company.description, products: ex.company.products, website: ex.company.website,
      contactPerson: ex.name, status: "approved", assignedBooth: booth._id, preferredBooth: booth._id,
      reviewedBy: expo.organizer, reviewedAt: new Date(),
    });
    Object.assign(booth, {
      exhibitor: ex._id, application: app._id, status: "occupied", displayName: ex.company.name,
      products: ex.company.products, description: `Visit ${ex.company.name} for live demos.`,
      staff: [{ name: ex.name, role: "Booth lead", email: ex.email }],
    });
    await booth.save();
    return booth;
  }
  const [tv, cn, nova, gl, art, med, pix] = exhibitors;
  const techBooths = [await approve(tech, tv, "A1"), await approve(tech, cn, "A2"), await approve(tech, nova, "B3"), await approve(tech, pix, "B4"), await approve(tech, med, "C6")];
  await approve(green, gl, "A1");
  await approve(green, nova, "B2");
  await approve(food, art, "A3");
  const healthBooths = [await approve(health, med, "A1"), await approve(health, tv, "A2")];

  // a pending application holding a reserved booth
  const reserved = await Booth.findOneAndUpdate({ expo: tech._id, code: "C2" }, { $set: { status: "reserved" } }, { new: true });
  await ExhibitorApplication.create({
    expo: tech._id, exhibitor: gl._id, companyName: gl.company.name, category: gl.company.category,
    description: "We'd like to show our new smart-meter range to the tech audience.", products: ["Smart Meters"],
    preferredBooth: reserved._id, status: "pending", contactPerson: gl.name,
  });
  await ExhibitorApplication.create({
    expo: green._id, exhibitor: art._id, companyName: art.company.name, category: art.company.category,
    products: ["Organic Spices"], status: "pending", contactPerson: art.name,
  });
  log(`✓ applications: ${await ExhibitorApplication.countDocuments()}`);

  /* ------------------------------ sessions ------------------------------ */
  const speakers = [
    ["Dr. Zara Ahmed", "Chief AI Scientist, TechVision", img("photo-1573496359142-b8d87734a5a2", 300)],
    ["Hamza Sheikh", "CTO, CloudNest", img("photo-1560250097-0b93528c311a", 300)],
    ["Maria Lopez", "Head of Robotics, Nova", img("photo-1580489944761-15a19d654956", 300)],
    ["Usman Tariq", "Founder, GreenLeaf", img("photo-1500648767791-00dcc994a43e", 300)],
    ["Chef Nadia Rehman", "Executive Chef", img("photo-1595273670150-bd0c3c392e46", 300)],
    ["Dr. Kamran Malik", "Director, MediCore", img("photo-1612349317150-e413f6a5b16d", 300)],
  ];
  const sp = (i) => ({ name: speakers[i][0], title: speakers[i][1], photo: speakers[i][2], bio: `${speakers[i][0]} has spent over a decade building products at the frontier of their industry.` });

  const sessionDefs = [
    [tech, 0, 10, 60, "keynote", "Opening Keynote: AI in Everyday Business", "Artificial Intelligence", 0, "Main Stage", 500],
    [tech, 0, 12, 45, "talk", "Scaling on the Cloud without Burning Cash", "Cloud", 1, "Hall A · Room 1", 120],
    [tech, 0, 14, 90, "workshop", "Hands-on: Build a Vision Model in 90 Minutes", "Computer Vision", 0, "Workshop Lab", 30],
    [tech, 1, 10, 60, "panel", "Robots in the Warehouse — Panel", "Robotics", 2, "Main Stage", 400],
    [tech, 1, 13, 45, "talk", "Design Systems for Fast-moving Teams", "Design", 2, "Hall B · Room 2", 100],
    [tech, 2, 11, 60, "networking", "Founders & Investors Mixer", "Networking", 1, "Lounge", 80],
    [green, 0, 10, 60, "keynote", "The Solar Decade", "Renewables", 3, "Main Stage", 400],
    [green, 0, 13, 90, "workshop", "Energy Audits for Factories", "Efficiency", 3, "Room 1", 40],
    [green, 1, 11, 60, "panel", "Financing Climate Tech", "Investment", 3, "Main Stage", 300],
    [food, 0, 11, 60, "workshop", "Live Demo: Modern Desi Fusion", "Culinary", 4, "Demo Kitchen", 60],
    [food, 1, 14, 45, "talk", "Hospitality Tech That Guests Love", "Hospitality", 4, "Room 2", 100],
    [health, 0, 10, 60, "keynote", "Connected Care", "Digital Health", 5, "Main Stage", 300],
    [health, 1, 12, 45, "talk", "Wearables in Clinical Practice", "Devices", 5, "Room 1", 80],
  ];
  const sessions = [];
  for (const [expo, day, h, mins, type, title, topic, spk, location, capacity] of sessionDefs) {
    const startTime = at(expo.startDate, day, h);
    sessions.push(
      await Session.create({
        expo: expo._id, title, topic, type, location, capacity, speaker: sp(spk),
        startTime, endTime: new Date(+startTime + mins * 60000),
        description: `${title} — an in-depth ${type} on ${topic.toLowerCase()} with practical takeaways for every attendee.`,
      })
    );
  }
  log(`✓ sessions: ${sessions.length}`);

  /* -------------------- registrations, sessions, visits -------------------- */
  for (const [i, a] of attendees.entries()) {
    for (const expo of [tech, green, health].slice(0, i % 2 === 0 ? 3 : 2)) {
      await Registration.create({
        expo: expo._id, attendee: a._id, ticketCode: ticketCode(),
        checkedIn: expo === health, checkedInAt: expo === health ? health.startDate : undefined,
        createdAt: new Date(Date.now() - Math.floor(Math.random() * 25) * DAY),
      });
    }
    const techSessions = sessions.filter((s) => String(s.expo) === String(tech._id));
    for (const s of techSessions.slice(0, 2 + (i % 3))) {
      await Session.updateOne({ _id: s._id }, { $addToSet: { attendees: a._id } });
    }
    await Session.updateOne({ _id: techSessions[(i + 3) % techSessions.length]._id }, { $addToSet: { bookmarkedBy: a._id } });
    const healthSessions = sessions.filter((s) => String(s.expo) === String(health._id));
    for (const s of healthSessions) await Session.updateOne({ _id: s._id }, { $addToSet: { attendees: a._id } });
  }
  // extra anonymous registrations for nicer charts
  const visits = [];
  for (let k = 0; k < 140; k++) {
    const b = rand([...techBooths, ...techBooths.slice(0, 2), ...healthBooths]);
    visits.push({
      booth: b._id, expo: b.expo, exhibitor: b.exhibitor, visitor: rand([...attendees.map((a) => a._id), null]),
      source: rand(["profile", "floorplan", "floorplan", "checkin"]),
      createdAt: new Date(Date.now() - Math.floor(Math.random() * 14) * DAY - Math.floor(Math.random() * DAY)),
    });
  }
  await BoothVisit.insertMany(visits);
  log(`✓ registrations: ${await Registration.countDocuments()}, booth visits: ${visits.length}`);

  /* ------------------------------ messages ------------------------------ */
  const [ali, sara] = attendees;
  await Message.insertMany([
    { from: ali._id, to: tv._id, body: "Hi! Will you have live demos of the AI Vision Kit at the expo?", createdAt: new Date(Date.now() - 3 * 3600e3) },
    { from: tv._id, to: ali._id, body: "Absolutely — every two hours at booth A1. Drop by anytime!", read: true, createdAt: new Date(Date.now() - 2.5 * 3600e3) },
    { from: tv._id, to: cn._id, body: "Hey neighbour! Fancy a joint demo — our cameras streaming to your cloud?", createdAt: new Date(Date.now() - 26 * 3600e3) },
    { from: cn._id, to: tv._id, body: "Love it. Let's sync on Tuesday.", createdAt: new Date(Date.now() - 25 * 3600e3) },
    { from: gl._id, to: organizer._id, body: "Could we get an extra power socket at our booth?", createdAt: new Date(Date.now() - 5 * 3600e3) },
    { from: sara._id, to: organizer._id, body: "Is parking available at Expo Centre Karachi?", createdAt: new Date(Date.now() - 1 * 3600e3) },
  ]);

  /* ------------------------------ feedback ------------------------------ */
  await Feedback.insertMany([
    { user: ali._id, name: ali.name, email: ali.email, expo: health._id, type: "feedback", subject: "Great keynote!", message: "Connected Care was inspiring. More workshops next time please.", rating: 5 },
    { user: sara._id, name: sara.name, email: sara.email, expo: health._id, type: "suggestion", subject: "Better signage", message: "Hall B was hard to find — bigger signs would help.", rating: 4 },
    { user: attendees[2]._id, name: attendees[2].name, email: attendees[2].email, type: "issue", subject: "QR not loading on Safari", message: "My ticket QR took a while to load on iPhone.", rating: 3, status: "in_progress" },
    { name: "Guest Visitor", email: "guest@example.com", type: "inquiry", subject: "Group tickets", message: "Do you offer group discounts for universities?" },
  ]);

  /* ------------------------------ gallery ------------------------------ */
  const gallery = [
    ["photo-1540575467063-178a50c2df87", "Main stage keynote", health],
    ["photo-1505373877841-8d25f7d46678", "Packed halls on day one", health],
    ["photo-1511578314322-379afb476865", "Exhibitor booths", health],
    ["photo-1515187029135-18ee286d815b", "Networking lounge", health],
    ["photo-1475721027785-f74eccf877e2", "Panel discussion", null],
    ["photo-1559223607-a43c990c692c", "Workshop lab", null],
    ["photo-1531058020387-3be344556be6", "Evening reception", null],
    ["photo-1492684223066-81342ee5ff7c", "Concert night", null],
    ["photo-1464366400600-7168b8af9bc3", "Gala dinner", null],
  ];
  await GalleryItem.insertMany(gallery.map(([id, caption, expo]) => ({ url: img(id, 1200), caption, expo: expo?._id || null, uploadedBy: admin._id })));

  /* ------------------------------ notifications ------------------------------ */
  const welcome = [...attendees, ...exhibitors, organizer, admin].map((u) => ({
    user: u._id, type: "announcement", title: "Welcome to EventSphere 2.0 ✨", body: "Real-time schedules, floor plans and messaging are now live.", link: "/expos",
  }));
  await Notification.insertMany(welcome);
  await Notification.create({ user: organizer._id, type: "application", title: "New exhibitor application", body: "GreenLeaf Energy applied to exhibit at Global Tech Expo 2026.", link: "/dashboard/applications" });

  log("\n✅ Seed complete. Demo logins:");
  log("   admin@eventsphere.com      / Admin@123");
  log("   organizer@eventsphere.com  / Organizer@123");
  log("   techvision@eventsphere.com / Exhibitor@123");
  log("   ali@eventsphere.com        / Attendee@123\n");
  return { admin, organizer, exhibitors, attendees, expos, sessions };
}

// run directly: node src/seed/seed.js
if (process.argv[1] && process.argv[1].replace(/\\/g, "/").endsWith("seed/seed.js")) {
  connectDB()
    .then(() => seed())
    .then(() => mongoose.disconnect())
    .catch((err) => {
      console.error("Seed failed:", err);
      process.exit(1);
    });
}
