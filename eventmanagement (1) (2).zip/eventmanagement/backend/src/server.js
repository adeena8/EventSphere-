import http from "node:http";
import env from "./config/env.js";
import { connectDB, disconnectDB } from "./config/db.js";
import { createApp } from "./app.js";
import { initSocket } from "./services/socket.js";
import { startReminderJob } from "./services/reminders.js";
import { startBackupJob } from "./services/backup.js";
import logger from "./services/logger.js";

async function start() {
  try {
    await connectDB();
  } catch (err) {
    logger.error(`Could not connect to MongoDB at ${env.mongoUri}\n→ ${err.message}\nIs MongoDB running? Check MONGO_URI in backend/.env`);
    process.exit(1);
  }

  const app = createApp();
  const server = http.createServer(app);
  initSocket(server);
  startReminderJob();
  startBackupJob();

  server.listen(env.port, () => {
    logger.info(`EventSphere API running → http://localhost:${env.port}/api (${env.nodeEnv})`);
  });

  const shutdown = async (signal) => {
    logger.info(`${signal} received — shutting down`);
    server.close(async () => {
      await disconnectDB();
      process.exit(0);
    });
    setTimeout(() => process.exit(1), 10000).unref();
  };
  process.on("SIGINT", () => shutdown("SIGINT"));
  process.on("SIGTERM", () => shutdown("SIGTERM"));
  process.on("unhandledRejection", (reason) => logger.error(`Unhandled rejection: ${reason?.stack || reason}`));
}

start();
