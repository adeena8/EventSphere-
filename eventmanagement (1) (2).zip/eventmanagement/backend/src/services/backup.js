/**
 * Automated JSON backups of every MongoDB collection.
 * backups/<timestamp>/<collection>.json  (Extended JSON so ObjectIds/Dates survive)
 */
import fs from "node:fs";
import path from "node:path";
import mongoose from "mongoose";
import cron from "node-cron";
import env from "../config/env.js";
import logger from "./logger.js";

const { EJSON } = mongoose.mongo.BSON;

export async function runBackup() {
  const db = mongoose.connection.db;
  if (!db) throw new Error("Database not connected");
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const dir = path.join(env.backupsDir, stamp);
  fs.mkdirSync(dir, { recursive: true });

  const collections = await db.listCollections().toArray();
  let total = 0;
  for (const { name } of collections) {
    if (name.startsWith("system.")) continue;
    const docs = await db.collection(name).find({}).toArray();
    fs.writeFileSync(path.join(dir, `${name}.json`), EJSON.stringify(docs, { relaxed: false }));
    total += docs.length;
  }
  pruneOld();
  logger.info(`Backup complete → ${dir} (${collections.length} collections, ${total} docs)`);
  return { dir: stamp, collections: collections.length, documents: total };
}

export async function restoreBackup(folder) {
  const db = mongoose.connection.db;
  const dir = path.isAbsolute(folder) ? folder : path.join(env.backupsDir, folder);
  if (!fs.existsSync(dir)) throw new Error(`Backup folder not found: ${dir}`);
  for (const file of fs.readdirSync(dir).filter((f) => f.endsWith(".json"))) {
    const name = file.replace(/\.json$/, "");
    const docs = EJSON.parse(fs.readFileSync(path.join(dir, file), "utf8"));
    await db.collection(name).deleteMany({});
    if (docs.length) await db.collection(name).insertMany(docs);
    logger.info(`restored ${name}: ${docs.length}`);
  }
}

export function listBackups() {
  if (!fs.existsSync(env.backupsDir)) return [];
  return fs
    .readdirSync(env.backupsDir, { withFileTypes: true })
    .filter((d) => d.isDirectory())
    .map((d) => d.name)
    .sort()
    .reverse();
}

function pruneOld() {
  const all = listBackups();
  for (const old of all.slice(env.backupKeep)) {
    fs.rmSync(path.join(env.backupsDir, old), { recursive: true, force: true });
  }
}

export function startBackupJob() {
  if (!cron.validate(env.backupCron)) {
    logger.warn(`Invalid BACKUP_CRON "${env.backupCron}" — automatic backups disabled`);
    return;
  }
  cron.schedule(env.backupCron, () => runBackup().catch((e) => logger.error(`backup failed: ${e.message}`)));
  logger.info(`Automatic backups scheduled (${env.backupCron}, keep ${env.backupKeep})`);
}
