/**
 * Tiny dependency-free logger.
 * Writes to console + logs/app-YYYY-MM-DD.log (errors also to logs/error-YYYY-MM-DD.log).
 */
import fs from "node:fs";
import path from "node:path";
import env from "../config/env.js";

fs.mkdirSync(env.logsDir, { recursive: true });

const COLORS = { info: "\x1b[36m", warn: "\x1b[33m", error: "\x1b[31m", http: "\x1b[90m" };
const RESET = "\x1b[0m";

function fileFor(kind) {
  const day = new Date().toISOString().slice(0, 10);
  return path.join(env.logsDir, `${kind}-${day}.log`);
}

function write(level, message, meta) {
  const ts = new Date().toISOString();
  const metaStr = meta ? ` ${JSON.stringify(meta)}` : "";
  const line = `${ts} [${level.toUpperCase()}] ${message}${metaStr}`;
  if (!env.isTest) {
    // eslint-disable-next-line no-console
    console.log(`${COLORS[level] || ""}${line}${RESET}`);
  }
  fs.appendFile(fileFor("app"), line + "\n", () => {});
  if (level === "error") fs.appendFile(fileFor("error"), line + "\n", () => {});
}

const logger = {
  info: (m, meta) => write("info", m, meta),
  warn: (m, meta) => write("warn", m, meta),
  error: (m, meta) => write("error", m, meta),
  http: (m) => write("http", m),
  /** stream for morgan */
  stream: { write: (m) => write("http", m.trim()) },
};

export default logger;
