import nodemailer from "nodemailer";
import env from "../config/env.js";
import logger from "./logger.js";

let transporter = null;
if (env.smtp.host) {
  transporter = nodemailer.createTransport({
    host: env.smtp.host,
    port: env.smtp.port,
    secure: env.smtp.port === 465,
    auth: env.smtp.user ? { user: env.smtp.user, pass: env.smtp.pass } : undefined,
  });
}

/**
 * Sends an email. Without SMTP configured, the mail is written to the log
 * so password-reset links etc. still work during development.
 */
export async function sendMail({ to, subject, text, html }) {
  if (!transporter) {
    logger.info(`[mail:dev] to=${to} subject="${subject}"\n${text}`);
    return { dev: true };
  }
  try {
    return await transporter.sendMail({ from: env.smtp.from, to, subject, text, html: html || `<p>${text}</p>` });
  } catch (err) {
    logger.error(`Mail failed: ${err.message}`);
    return { error: err.message };
  }
}
