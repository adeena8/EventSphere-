import { Notification, Activity, User } from "../models/index.js";
import { emitToUser } from "./socket.js";
import logger from "./logger.js";

/** Create a notification for one or many users and push it live */
export async function notify(userIds, { title, body, link, type = "info" }) {
  const ids = [...new Set((Array.isArray(userIds) ? userIds : [userIds]).filter(Boolean).map(String))];
  if (!ids.length) return [];
  const docs = await Notification.insertMany(ids.map((user) => ({ user, title, body, link, type })));
  for (const n of docs) emitToUser(n.user, "notification:new", n);
  return docs;
}

/** Notify everyone with a given role (or all users) */
export async function notifyRole(role, payload) {
  const filter = role && role !== "all" ? { role, status: "active" } : { status: "active" };
  const users = await User.find(filter).select("_id").lean();
  return notify(users.map((u) => u._id), payload);
}

/** Record user activity for monitoring / audit. Never throws. */
export function logActivity(req, action, entity, entityId, meta) {
  Activity.create({
    user: req?.user?._id || null,
    action,
    entity,
    entityId: entityId ? String(entityId) : undefined,
    meta,
    ip: req?.ip,
  }).catch((err) => logger.warn(`activity log failed: ${err.message}`));
}
