/**
 * Every minute: remind users about bookmarked / registered sessions
 * starting within the next 30 minutes (each user is reminded once).
 */
import cron from "node-cron";
import { Session } from "../models/index.js";
import { notify } from "./notify.js";
import logger from "./logger.js";

const WINDOW_MIN = 30;

export async function sendSessionReminders(now = new Date()) {
  const soon = new Date(now.getTime() + WINDOW_MIN * 60 * 1000);
  const sessions = await Session.find({ startTime: { $gt: now, $lte: soon } })
    .select("+remindedUsers title startTime location expo attendees bookmarkedBy")
    .lean();

  let sent = 0;
  for (const s of sessions) {
    const already = new Set((s.remindedUsers || []).map(String));
    const targets = [...new Set([...(s.attendees || []), ...(s.bookmarkedBy || [])].map(String))].filter(
      (id) => !already.has(id)
    );
    if (!targets.length) continue;
    const mins = Math.max(1, Math.round((new Date(s.startTime) - now) / 60000));
    await notify(targets, {
      type: "reminder",
      title: `Starting in ${mins} min: ${s.title}`,
      body: `${s.location ? `Location: ${s.location}. ` : ""}Don't miss it!`,
      link: `/expos/${s.expo}?tab=schedule`,
    });
    await Session.updateOne({ _id: s._id }, { $addToSet: { remindedUsers: { $each: targets } } });
    sent += targets.length;
  }
  if (sent) logger.info(`Session reminders sent: ${sent}`);
  return sent;
}

export function startReminderJob() {
  cron.schedule("* * * * *", () => {
    sendSessionReminders().catch((err) => logger.error(`reminder job: ${err.message}`));
  });
  logger.info("Session reminder job scheduled (every minute)");
}
