/**
 * Socket.IO real-time layer.
 *
 * Rooms:
 *   user:<id>    – private notifications & chat for one user
 *   role:<role>  – broadcast to a role
 *   expo:<id>    – live schedule / booth / analytics updates for an expo
 *   staff        – organizers + admins (analytics dashboards)
 */
import { Server } from "socket.io";
import jwt from "jsonwebtoken";
import env from "../config/env.js";
import logger from "./logger.js";
import { isId } from "../utils/helpers.js";

let io = null;
const online = new Map(); // userId -> number of open sockets

export function initSocket(httpServer) {
  io = new Server(httpServer, {
    cors: { origin: env.clientUrl.split(","), credentials: true },
  });

  io.use((socket, next) => {
    const token = socket.handshake.auth?.token;
    if (!token) return next(); // anonymous visitors still get public expo updates
    try {
      const payload = jwt.verify(token, env.jwtSecret);
      socket.data.user = { id: payload.id, role: payload.role };
    } catch {
      /* invalid token → treat as anonymous */
    }
    next();
  });

  io.on("connection", (socket) => {
    const user = socket.data.user;
    if (user) {
      socket.join(`user:${user.id}`);
      socket.join(`role:${user.role}`);
      if (user.role === "admin" || user.role === "organizer") socket.join("staff");
      online.set(user.id, (online.get(user.id) || 0) + 1);
      io.emit("presence", { userId: user.id, online: true });
    }

    socket.on("expo:join", (expoId) => isId(expoId) && socket.join(`expo:${expoId}`));
    socket.on("expo:leave", (expoId) => isId(expoId) && socket.leave(`expo:${expoId}`));

    socket.on("typing", ({ to }) => {
      if (user && isId(to)) io.to(`user:${to}`).emit("typing", { from: user.id });
    });

    socket.on("disconnect", () => {
      if (!user) return;
      const n = (online.get(user.id) || 1) - 1;
      if (n <= 0) {
        online.delete(user.id);
        io.emit("presence", { userId: user.id, online: false });
      } else online.set(user.id, n);
    });
  });

  logger.info("Socket.IO ready");
  return io;
}

export const isOnline = (userId) => online.has(String(userId));
export const onlineUsers = () => [...online.keys()];

/** Safe emit helpers — no-ops when sockets are not initialised (tests, scripts) */
export function emitToUser(userId, event, payload) {
  io?.to(`user:${userId}`).emit(event, payload);
}
export function emitToExpo(expoId, event, payload) {
  io?.to(`expo:${expoId}`).emit(event, payload);
  io?.to("staff").emit(event, payload);
}
export function emitToStaff(event, payload) {
  io?.to("staff").emit(event, payload);
}
export function emitAll(event, payload) {
  io?.emit(event, payload);
}
