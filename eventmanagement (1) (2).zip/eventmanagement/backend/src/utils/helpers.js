import crypto from "node:crypto";
import mongoose from "mongoose";
import env from "../config/env.js";

/** Error with HTTP status that the error middleware understands */
export class ApiError extends Error {
  constructor(status, message, details) {
    super(message);
    this.status = status;
    this.details = details;
  }
}

/** Wrap async route handlers so thrown errors reach the error middleware */
export const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

/** Pick allowed keys from an object (prevents mass-assignment) */
export function pick(obj = {}, keys = []) {
  const out = {};
  for (const k of keys) if (obj[k] !== undefined) out[k] = obj[k];
  return out;
}

export const isId = (v) => mongoose.Types.ObjectId.isValid(String(v || ""));

export function assertId(v, label = "id") {
  if (!isId(v)) throw new ApiError(400, `Invalid ${label}`);
}

/** Escape a user string so it can be used safely inside a RegExp */
export const escapeRegex = (s = "") => String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

/** "a, b ,c" | ["a","b"] → ["a","b","c"] */
export function toList(v) {
  if (Array.isArray(v)) return v.map((x) => String(x).trim()).filter(Boolean);
  if (typeof v === "string") {
    const t = v.trim();
    if (t.startsWith("[")) {
      try {
        return toList(JSON.parse(t));
      } catch {
        /* fall through */
      }
    }
    return t.split(",").map((x) => x.trim()).filter(Boolean);
  }
  return [];
}

/** Parse a JSON string field coming from multipart forms */
export function parseJSON(v, fallback) {
  if (v == null || v === "") return fallback;
  if (typeof v !== "string") return v;
  try {
    return JSON.parse(v);
  } catch {
    return fallback;
  }
}

export const sha256 = (s) => crypto.createHash("sha256").update(String(s)).digest("hex");

/* ---------- AES-256-GCM for personal data at rest ---------- */
const KEY = Buffer.from(env.encryptionKey.padEnd(64, "0").slice(0, 64), "hex");
const PREFIX = "enc:";

export function encrypt(plain) {
  if (plain == null || plain === "") return plain;
  const s = String(plain);
  if (s.startsWith(PREFIX)) return s;
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", KEY, iv);
  const enc = Buffer.concat([cipher.update(s, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return PREFIX + Buffer.concat([iv, tag, enc]).toString("base64");
}

export function decrypt(value) {
  if (value == null || value === "") return value;
  const s = String(value);
  if (!s.startsWith(PREFIX)) return s;
  try {
    const buf = Buffer.from(s.slice(PREFIX.length), "base64");
    const iv = buf.subarray(0, 12);
    const tag = buf.subarray(12, 28);
    const data = buf.subarray(28);
    const decipher = crypto.createDecipheriv("aes-256-gcm", KEY, iv);
    decipher.setAuthTag(tag);
    return Buffer.concat([decipher.update(data), decipher.final()]).toString("utf8");
  } catch {
    return "";
  }
}

/* ---------- light validation helpers ---------- */
export const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export function requireFields(body, fields) {
  const missing = fields.filter((f) => body[f] === undefined || body[f] === null || String(body[f]).trim() === "");
  if (missing.length) throw new ApiError(400, `Missing required field(s): ${missing.join(", ")}`, { missing });
}

export function validatePassword(pw) {
  if (typeof pw !== "string" || pw.length < 8) throw new ApiError(400, "Password must be at least 8 characters");
  if (!/[A-Za-z]/.test(pw) || !/\d/.test(pw)) throw new ApiError(400, "Password must contain letters and numbers");
}

export function fileUrl(file, folder) {
  return file ? `/uploads/${folder}/${file.filename}` : undefined;
}

export const ticketCode = () => "ES-" + crypto.randomBytes(5).toString("hex").toUpperCase();
