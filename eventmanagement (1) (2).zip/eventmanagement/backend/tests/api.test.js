/**
 * Integration tests — run with:  npm test
 * Uses an in-memory MongoDB (mongodb-memory-server), so no database setup is needed.
 */
import "./setup.js";
import { test, before, after, describe } from "node:test";
import assert from "node:assert/strict";
import request from "supertest";
import mongoose from "mongoose";
import { MongoMemoryServer } from "mongodb-memory-server";
import { createApp } from "../src/app.js";
import { seed } from "../src/seed/seed.js";
import { User } from "../src/models/index.js";
import { encrypt, decrypt } from "../src/utils/helpers.js";
import { sendSessionReminders } from "../src/services/reminders.js";

let mongo;
let app;
let data;
const tokens = {};

async function login(email, password) {
  const res = await request(app).post("/api/auth/login").send({ email, password });
  assert.equal(res.status, 200, res.body.message);
  return res.body.token;
}
const auth = (t) => ({ Authorization: `Bearer ${t}` });

before(async () => {
  mongo = await MongoMemoryServer.create();
  await mongoose.connect(mongo.getUri());
  app = createApp();
  data = await seed({ quiet: true });
  tokens.admin = await login("admin@eventsphere.com", "Admin@123");
  tokens.organizer = await login("organizer@eventsphere.com", "Organizer@123");
  tokens.exhibitor = await login("greenleaf@eventsphere.com", "Exhibitor@123");
  tokens.attendee = await login("ali@eventsphere.com", "Attendee@123");
});

after(async () => {
  await mongoose.disconnect();
  await mongo?.stop();
});

describe("unit: encryption", () => {
  test("encrypt/decrypt round-trips and hides plaintext", () => {
    const enc = encrypt("+92 300 1234567");
    assert.ok(enc.startsWith("enc:"));
    assert.ok(!enc.includes("1234567"));
    assert.equal(decrypt(enc), "+92 300 1234567");
  });
});

describe("auth", () => {
  test("health endpoint", async () => {
    const res = await request(app).get("/api/health");
    assert.equal(res.body.status, "ok");
  });

  test("register attendee → token; password is hashed; phone encrypted", async () => {
    const res = await request(app).post("/api/auth/register").send({
      name: "Test User", email: "test@example.com", password: "Secret123", role: "attendee", phone: "0300-9999999", consent: true,
    });
    assert.equal(res.status, 201, res.body.message);
    assert.ok(res.body.token);
    assert.equal(res.body.user.password, undefined);
    const raw = await User.collection.findOne({ email: "test@example.com" });
    assert.notEqual(raw.password, "Secret123");
    assert.ok(raw.phone.startsWith("enc:"));
    assert.equal(res.body.user.phone, "0300-9999999");
  });

  test("register requires consent and strong password", async () => {
    let res = await request(app).post("/api/auth/register").send({ name: "X", email: "x@example.com", password: "Secret123" });
    assert.equal(res.status, 400);
    res = await request(app).post("/api/auth/register").send({ name: "X", email: "x@example.com", password: "short", consent: true });
    assert.equal(res.status, 400);
  });

  test("cannot self-register as admin; organizer is pending", async () => {
    const res = await request(app).post("/api/auth/register").send({ name: "Sneaky", email: "sneaky@example.com", password: "Secret123", role: "admin", consent: true });
    assert.equal(res.body.user.role, "attendee");
    const org = await request(app).post("/api/auth/register").send({ name: "Org", email: "org@example.com", password: "Secret123", role: "organizer", consent: true });
    assert.equal(org.body.pending, true);
    const login = await request(app).post("/api/auth/login").send({ email: "org@example.com", password: "Secret123" });
    assert.equal(login.status, 403);
  });

  test("wrong password rejected", async () => {
    const res = await request(app).post("/api/auth/login").send({ email: "admin@eventsphere.com", password: "nope" });
    assert.equal(res.status, 401);
  });

  test("forgot + reset password flow", async () => {
    const f = await request(app).post("/api/auth/forgot-password").send({ email: "sara@eventsphere.com" });
    assert.ok(f.body.devResetUrl);
    const token = f.body.devResetUrl.split("/").pop();
    const r = await request(app).post(`/api/auth/reset-password/${token}`).send({ password: "NewPass123" });
    assert.equal(r.status, 200);
    await login("sara@eventsphere.com", "NewPass123");
    const again = await request(app).post(`/api/auth/reset-password/${token}`).send({ password: "Another123" });
    assert.equal(again.status, 400);
  });

  test("NoSQL injection in login is neutralised", async () => {
    const res = await request(app).post("/api/auth/login").send({ email: { $ne: null }, password: { $ne: null } });
    assert.ok([400, 401].includes(res.status));
  });
});

describe("expos & authorization", () => {
  let expoId;
  test("public list shows only published/completed", async () => {
    const res = await request(app).get("/api/expos");
    assert.equal(res.status, 200);
    assert.ok(res.body.items.length >= 3);
    assert.ok(res.body.items.every((e) => ["published", "completed"].includes(e.status)));
  });

  test("attendee cannot create expo", async () => {
    const res = await request(app).post("/api/expos").set(auth(tokens.attendee)).send({ title: "X", startDate: new Date(), endDate: new Date() });
    assert.equal(res.status, 403);
  });

  test("organizer creates expo with booth grid", async () => {
    const start = new Date(Date.now() + 5 * 86400000);
    const res = await request(app).post("/api/expos").set(auth(tokens.organizer)).send({
      title: "Test Expo", startDate: start, endDate: new Date(+start + 86400000), status: "published",
      floorPlan: JSON.stringify({ rows: 2, cols: 3 }), generateBooths: true, location: JSON.stringify({ venue: "Hall", city: "Karachi" }),
    });
    assert.equal(res.status, 201, res.body.message);
    expoId = res.body.expo._id;
    const booths = await request(app).get(`/api/expos/${expoId}/booths`);
    assert.equal(booths.body.booths.length, 6);
  });

  test("another organizer cannot edit it", async () => {
    const t = await login("organizer2@eventsphere.com", "Organizer@123");
    const res = await request(app).put(`/api/expos/${expoId}`).set(auth(t)).send({ title: "Hacked" });
    assert.equal(res.status, 403);
  });

  test("end date before start date is rejected", async () => {
    const res = await request(app).post("/api/expos").set(auth(tokens.organizer)).send({ title: "Bad", startDate: new Date(Date.now() + 86400000), endDate: new Date() });
    assert.equal(res.status, 400);
  });
});

describe("exhibitor flow", () => {
  let appId;
  let boothId;
  const tech = () => data.expos[0];

  test("exhibitor applies with a preferred booth → booth becomes reserved", async () => {
    // greenleaf already has a pending application for tech; apply to food expo
    const food = data.expos[2];
    const booths = await request(app).get(`/api/expos/${food._id}/booths`);
    const free = booths.body.booths.find((b) => b.status === "available");
    boothId = free._id;
    const res = await request(app).post("/api/applications").set(auth(tokens.exhibitor))
      .field("expo", String(food._id)).field("products", "Solar Panels, Batteries").field("preferredBooth", boothId);
    assert.equal(res.status, 201, res.body.message);
    appId = res.body.application._id;
    const after = await request(app).get(`/api/expos/${food._id}/booths`);
    assert.equal(after.body.booths.find((b) => b._id === boothId).status, "reserved");
  });

  test("duplicate application is blocked", async () => {
    const res = await request(app).post("/api/applications").set(auth(tokens.exhibitor)).send({ expo: String(data.expos[2]._id) });
    assert.equal(res.status, 409);
  });

  test("organizer of another expo cannot approve; owner organizer can", async () => {
    let res = await request(app).patch(`/api/applications/${appId}/status`).set(auth(tokens.organizer)).send({ status: "approved" });
    assert.equal(res.status, 403); // food expo belongs to organizer2
    const t2 = await login("organizer2@eventsphere.com", "Organizer@123");
    res = await request(app).patch(`/api/applications/${appId}/status`).set(auth(t2)).send({ status: "approved" });
    assert.equal(res.status, 200, res.body.message);
    const mine = await request(app).get("/api/booths/mine").set(auth(tokens.exhibitor));
    assert.ok(mine.body.items.some((b) => b._id === boothId && b.status === "occupied"));
  });

  test("exhibitor manages booth details", async () => {
    const res = await request(app).put(`/api/booths/${boothId}/details`).set(auth(tokens.exhibitor))
      .send({ products: "Panels, Inverters", staff: [{ name: "Usman", role: "Lead" }] });
    assert.equal(res.status, 200);
    assert.deepEqual(res.body.booth.products, ["Panels", "Inverters"]);
  });

  test("other exhibitor cannot edit someone else's booth", async () => {
    const t = await login("artisan@eventsphere.com", "Exhibitor@123");
    const res = await request(app).put(`/api/booths/${boothId}/details`).set(auth(t)).send({ products: "x" });
    assert.equal(res.status, 403);
  });

  test("exhibitor search & filter", async () => {
    const res = await request(app).get(`/api/expos/${tech()._id}/exhibitors?q=cloud`);
    assert.ok(res.body.items.some((x) => x.exhibitor.company.name === "CloudNest"));
    const cat = await request(app).get(`/api/exhibitors?category=Robotics`);
    assert.ok(cat.body.items.every((x) => x.company.category === "Robotics"));
  });

  test("booth visit is tracked for analytics", async () => {
    const booths = await request(app).get(`/api/expos/${tech()._id}/booths`);
    const occ = booths.body.booths.find((b) => b.status === "occupied");
    const res = await request(app).post(`/api/booths/${occ._id}/visit`).set(auth(tokens.attendee)).send({ source: "floorplan" });
    assert.ok([200, 201].includes(res.status));
  });
});

describe("attendee flow", () => {
  let sessionId;
  test("register for expo → ticket with QR", async () => {
    const food = data.expos[2];
    const res = await request(app).post(`/api/expos/${food._id}/register`).set(auth(tokens.attendee));
    assert.equal(res.status, 201, res.body.message);
    const mine = await request(app).get("/api/registrations/mine").set(auth(tokens.attendee));
    const t = mine.body.items.find((r) => String(r.expo._id) === String(food._id));
    assert.ok(t.qr.startsWith("data:image/png"));
    const dup = await request(app).post(`/api/expos/${food._id}/register`).set(auth(tokens.attendee));
    assert.equal(dup.status, 409);
  });

  test("bookmark and register for a session", async () => {
    const food = data.expos[2];
    const list = await request(app).get(`/api/expos/${food._id}/sessions`).set(auth(tokens.attendee));
    sessionId = list.body.items[0]._id;
    const b = await request(app).post(`/api/sessions/${sessionId}/bookmark`).set(auth(tokens.attendee));
    assert.equal(b.body.bookmarked, true);
    const r = await request(app).post(`/api/sessions/${sessionId}/register`).set(auth(tokens.attendee));
    assert.equal(r.status, 200, r.body.message);
    assert.equal(r.body.session.isRegistered, true);
    const mine = await request(app).get("/api/sessions/mine").set(auth(tokens.attendee));
    assert.ok(mine.body.items.some((s) => s._id === sessionId));
  });

  test("schedule change notifies interested attendees", async () => {
    const t2 = await login("organizer2@eventsphere.com", "Organizer@123");
    const s = await request(app).get(`/api/expos/${data.expos[2]._id}/sessions`);
    const sess = s.body.items.find((x) => x._id === sessionId);
    const newStart = new Date(new Date(sess.startTime).getTime() + 3600000);
    const res = await request(app).put(`/api/sessions/${sessionId}`).set(auth(t2))
      .send({ startTime: newStart, endTime: new Date(+newStart + 3600000) });
    assert.equal(res.status, 200, res.body.message);
    const n = await request(app).get("/api/notifications").set(auth(tokens.attendee));
    assert.ok(n.body.items.some((x) => x.type === "schedule"));
  });

  test("reminders are sent once for sessions starting soon", async () => {
    const food = data.expos[2];
    const list = await request(app).get(`/api/expos/${food._id}/sessions`);
    const s = list.body.items.find((x) => x._id === sessionId);
    const fakeNow = new Date(new Date(s.startTime).getTime() - 10 * 60000);
    const first = await sendSessionReminders(fakeNow);
    const second = await sendSessionReminders(fakeNow);
    assert.ok(first >= 1);
    assert.equal(second, 0);
  });

  test("organizer checks in the ticket", async () => {
    const mine = await request(app).get("/api/registrations/mine").set(auth(tokens.attendee));
    const ticket = mine.body.items.find((r) => String(r.expo._id) === String(data.expos[0]._id));
    const res = await request(app).post("/api/registrations/check-in").set(auth(tokens.organizer)).send({ ticketCode: ticket.ticketCode });
    assert.equal(res.status, 200, res.body.message);
    assert.equal(res.body.registration.checkedIn, true);
  });
});

describe("messaging, feedback, analytics, privacy", () => {
  test("attendee messages an exhibitor; conversation appears", async () => {
    const tv = data.exhibitors[0];
    const res = await request(app).post("/api/messages").set(auth(tokens.attendee)).send({ to: String(tv._id), body: "Hello!" });
    assert.equal(res.status, 201);
    const conv = await request(app).get("/api/messages/conversations").set(auth(tokens.attendee));
    assert.ok(conv.body.items.some((c) => String(c.partner._id) === String(tv._id)));
  });

  test("attendee cannot message another attendee", async () => {
    const other = data.attendees[1];
    const res = await request(app).post("/api/messages").set(auth(tokens.attendee)).send({ to: String(other._id), body: "Hi" });
    assert.equal(res.status, 403);
  });

  test("anonymous feedback + staff response", async () => {
    const res = await request(app).post("/api/feedback").send({ name: "Guest", email: "g@example.com", subject: "Hi", message: "Nice site", type: "suggestion", rating: 5 });
    assert.equal(res.status, 201);
    const r = await request(app).patch(`/api/feedback/${res.body.feedback._id}`).set(auth(tokens.admin)).send({ status: "resolved", response: "Thanks!" });
    assert.equal(r.body.feedback.status, "resolved");
  });

  test("analytics overview for staff only", async () => {
    const denied = await request(app).get("/api/analytics/overview").set(auth(tokens.attendee));
    assert.equal(denied.status, 403);
    const res = await request(app).get("/api/analytics/overview").set(auth(tokens.organizer));
    assert.equal(res.status, 200);
    assert.ok(res.body.totals.attendees > 0);
    assert.ok(Array.isArray(res.body.boothTraffic));
    assert.equal(res.body.registrationsByDay.length, 30);
  });

  test("GDPR export & account deletion", async () => {
    const t = await login("bilal@eventsphere.com", "Attendee@123");
    const exp = await request(app).get("/api/auth/me/export").set(auth(t));
    assert.equal(exp.body.profile.email, "bilal@eventsphere.com");
    const del = await request(app).delete("/api/auth/me").set(auth(t)).send({ password: "Attendee@123" });
    assert.equal(del.status, 200);
    const again = await request(app).post("/api/auth/login").send({ email: "bilal@eventsphere.com", password: "Attendee@123" });
    assert.equal(again.status, 401);
  });

  test("admin-only routes are protected", async () => {
    const res = await request(app).get("/api/admin/users").set(auth(tokens.organizer));
    assert.equal(res.status, 403);
    const ok = await request(app).get("/api/admin/users").set(auth(tokens.admin));
    assert.ok(ok.body.items.length > 5);
  });
});
