// Must be imported first in every test file
process.env.NODE_ENV = "test";
process.env.JWT_SECRET = "test-secret";
process.env.ENCRYPTION_KEY = "a".repeat(64);
