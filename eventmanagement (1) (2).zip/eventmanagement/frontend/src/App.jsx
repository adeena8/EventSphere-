import { lazy, Suspense } from "react";
import { Route, Routes } from "react-router-dom";
import { PublicLayout, DashboardLayout, RequireAuth, GuestOnly } from "./components/layout/Layout.jsx";
import { Spinner } from "./components/ui/UI.jsx";
import Home from "./pages/Home.jsx";

/* public */
const Expos = lazy(() => import("./pages/Expos.jsx"));
const ExpoDetail = lazy(() => import("./pages/ExpoDetail.jsx"));
const Exhibitors = lazy(() => import("./pages/Exhibitors.jsx"));
const ExhibitorProfile = lazy(() => import("./pages/ExhibitorProfile.jsx"));
const Gallery = lazy(() => import("./pages/Gallery.jsx"));
const About = lazy(() => import("./pages/About.jsx"));
const Faq = lazy(() => import("./pages/Faq.jsx"));
const Contact = lazy(() => import("./pages/Contact.jsx"));
const Privacy = lazy(() => import("./pages/Privacy.jsx"));
const NotFound = lazy(() => import("./pages/NotFound.jsx"));
/* auth */
const Login = lazy(() => import("./pages/auth/Login.jsx"));
const Register = lazy(() => import("./pages/auth/Register.jsx"));
const ForgotPassword = lazy(() => import("./pages/auth/ForgotPassword.jsx"));
const ResetPassword = lazy(() => import("./pages/auth/ResetPassword.jsx"));
/* dashboard */
const Overview = lazy(() => import("./pages/dashboard/Overview.jsx"));
const Analytics = lazy(() => import("./pages/dashboard/Analytics.jsx"));
const ManageExpos = lazy(() => import("./pages/dashboard/ManageExpos.jsx"));
const FloorPlanManager = lazy(() => import("./pages/dashboard/FloorPlanManager.jsx"));
const Applications = lazy(() => import("./pages/dashboard/Applications.jsx"));
const ScheduleManager = lazy(() => import("./pages/dashboard/ScheduleManager.jsx"));
const CheckIn = lazy(() => import("./pages/dashboard/CheckIn.jsx"));
const Users = lazy(() => import("./pages/dashboard/Users.jsx"));
const FeedbackInbox = lazy(() => import("./pages/dashboard/FeedbackInbox.jsx"));
const Announcements = lazy(() => import("./pages/dashboard/Announcements.jsx"));
const System = lazy(() => import("./pages/dashboard/System.jsx"));
const MyBooths = lazy(() => import("./pages/dashboard/MyBooths.jsx"));
const CompanyProfile = lazy(() => import("./pages/dashboard/CompanyProfile.jsx"));
const Tickets = lazy(() => import("./pages/dashboard/Tickets.jsx"));
const MySessions = lazy(() => import("./pages/dashboard/MySessions.jsx"));
const Messages = lazy(() => import("./pages/dashboard/Messages.jsx"));
const Notifications = lazy(() => import("./pages/dashboard/Notifications.jsx"));
const Support = lazy(() => import("./pages/dashboard/Support.jsx"));
const Profile = lazy(() => import("./pages/dashboard/Profile.jsx"));

const STAFF = ["admin", "organizer"];

export default function App() {
  return (
    <Suspense fallback={<Spinner full />}>
      <Routes>
          <Route element={<PublicLayout />}>
            <Route index element={<Home />} />
            <Route path="expos" element={<Expos />} />
            <Route path="expos/:id" element={<ExpoDetail />} />
            <Route path="exhibitors" element={<Exhibitors />} />
            <Route path="exhibitors/:id" element={<ExhibitorProfile />} />
            <Route path="gallery" element={<Gallery />} />
            <Route path="about" element={<About />} />
            <Route path="faq" element={<Faq />} />
            <Route path="contact" element={<Contact />} />
            <Route path="privacy" element={<Privacy />} />
            <Route path="login" element={<GuestOnly><Login /></GuestOnly>} />
            <Route path="register" element={<GuestOnly><Register /></GuestOnly>} />
            <Route path="forgot-password" element={<ForgotPassword />} />
            <Route path="reset-password/:token" element={<ResetPassword />} />
            <Route path="*" element={<NotFound />} />
          </Route>

          <Route
            path="dashboard"
            element={
              <RequireAuth>
                <DashboardLayout />
              </RequireAuth>
            }
          >
            <Route index element={<Overview />} />
            <Route path="analytics" element={<RequireAuth roles={STAFF}><Analytics /></RequireAuth>} />
            <Route path="expos" element={<RequireAuth roles={STAFF}><ManageExpos /></RequireAuth>} />
            <Route path="floorplan" element={<RequireAuth roles={STAFF}><FloorPlanManager /></RequireAuth>} />
            <Route path="applications" element={<RequireAuth roles={[...STAFF, "exhibitor"]}><Applications /></RequireAuth>} />
            <Route path="schedule" element={<RequireAuth roles={STAFF}><ScheduleManager /></RequireAuth>} />
            <Route path="checkin" element={<RequireAuth roles={STAFF}><CheckIn /></RequireAuth>} />
            <Route path="users" element={<RequireAuth roles={["admin"]}><Users /></RequireAuth>} />
            <Route path="feedback" element={<RequireAuth roles={STAFF}><FeedbackInbox /></RequireAuth>} />
            <Route path="announce" element={<RequireAuth roles={STAFF}><Announcements /></RequireAuth>} />
            <Route path="system" element={<RequireAuth roles={["admin"]}><System /></RequireAuth>} />
            <Route path="booths" element={<RequireAuth roles={["exhibitor"]}><MyBooths /></RequireAuth>} />
            <Route path="company" element={<RequireAuth roles={["exhibitor"]}><CompanyProfile /></RequireAuth>} />
            <Route path="tickets" element={<RequireAuth roles={["attendee"]}><Tickets /></RequireAuth>} />
            <Route path="sessions" element={<MySessions />} />
            <Route path="messages" element={<Messages />} />
            <Route path="messages/:userId" element={<Messages />} />
            <Route path="notifications" element={<Notifications />} />
            <Route path="support" element={<Support />} />
            <Route path="profile" element={<Profile />} />
          </Route>
      </Routes>
    </Suspense>
  );
}
