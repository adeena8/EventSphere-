import { useEffect, useState } from "react";
import { Modal, Field, Spinner, ErrorBox } from "./ui/UI.jsx";
import FloorPlan from "./FloorPlan.jsx";
import { api, toFormData } from "../lib/api.js";
import { useAuth } from "../context/AuthContext.jsx";
import { useToast } from "../context/ToastContext.jsx";
import { useSocketEvent, useExpoRoom } from "../context/SocketContext.jsx";

/** Exhibitor application: company details + documents + pick a booth on the floor plan */
export default function ApplyModal({ expo, open, onClose, onDone }) {
  const { user } = useAuth();
  const toast = useToast();
  const c = user?.company || {};
  const [form, setForm] = useState({});
  const [files, setFiles] = useState([]);
  const [plan, setPlan] = useState(null);
  const [booth, setBooth] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!open) return;
    setForm({
      companyName: c.name || "",
      category: c.category || "",
      website: c.website || "",
      products: (c.products || []).join(", "),
      description: c.description || "",
      contactPerson: user?.name || "",
    });
    setBooth(null);
    setFiles([]);
    setError(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const loadPlan = () => expo && api.get(`/expos/${expo._id}/booths`).then(setPlan).catch(setError);
  useEffect(() => {
    if (open) loadPlan();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, expo?._id]);

  useExpoRoom(open ? expo?._id : null);
  useSocketEvent("booths:updated", (p) => {
    if (open && String(p.expoId) === String(expo?._id)) loadPlan();
  });

  // if someone else grabs the selected booth, drop the selection
  useEffect(() => {
    if (booth && plan) {
      const fresh = plan.booths.find((b) => b._id === booth._id);
      if (!fresh || fresh.status !== "available") {
        setBooth(null);
        toast.info(`Booth ${booth.code} was just taken — please pick another.`);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [plan]);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api("/applications", {
        method: "POST",
        body: toFormData({ ...form, expo: expo._id, preferredBooth: booth?._id, documents: files }),
      });
      toast.success(booth ? `Application sent — booth ${booth.code} is reserved for you while it's reviewed.` : "Application sent!");
      onDone?.();
      onClose();
    } catch (err) {
      setError(err);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal open={open} onClose={onClose} title={`Exhibit at ${expo?.title || ""}`} wide>
      <form className="form-grid" onSubmit={submit}>
        <Field label="Company name">
          <input required value={form.companyName || ""} onChange={set("companyName")} />
        </Field>
        <Field label="Category">
          <input value={form.category || ""} onChange={set("category")} placeholder="e.g. Technology" />
        </Field>
        <Field label="Website">
          <input type="url" value={form.website || ""} onChange={set("website")} placeholder="https://" />
        </Field>
        <Field label="Contact person">
          <input value={form.contactPerson || ""} onChange={set("contactPerson")} />
        </Field>
        <Field label="Products / services" hint="Comma separated" full>
          <input value={form.products || ""} onChange={set("products")} />
        </Field>
        <Field label="What will you showcase?" full>
          <textarea rows={3} value={form.description || ""} onChange={set("description")} />
        </Field>
        <Field label="Supporting documents" hint="PDF, Word or images · up to 5 files, 10 MB each" full>
          <input type="file" multiple accept=".pdf,.doc,.docx,image/*" onChange={(e) => setFiles([...e.target.files].slice(0, 5))} />
        </Field>

        <div className="field field--full">
          <span className="field__label">
            Preferred booth {booth ? <strong className="gold">· {booth.code} ({booth.size}{booth.price ? `, $${booth.price}` : ""})</strong> : "(optional — click an available booth)"}
          </span>
          {!plan ? <Spinner /> : <FloorPlan floorPlan={plan.floorPlan} booths={plan.booths} mode="select" selectedId={booth?._id} onSelect={setBooth} compact />}
        </div>

        <ErrorBox error={error} />
        <div className="form-actions field--full">
          <button type="button" className="btn btn--ghost" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn btn--gold" disabled={busy}>
            {busy ? "Sending…" : "Submit application"}
          </button>
        </div>
      </form>
    </Modal>
  );
}
