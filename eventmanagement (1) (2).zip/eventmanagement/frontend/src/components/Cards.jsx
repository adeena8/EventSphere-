import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { assetUrl } from "../lib/api.js";
import { fmtRange, fmtTime, fmtDay, daysUntil } from "../lib/format.js";
import { Badge, Avatar } from "./ui/UI.jsx";
import { Tilt } from "./motion/Motion.jsx";

const FALLBACK = "https://images.unsplash.com/photo-1505373877841-8d25f7d46678?auto=format&fit=crop&w=1200&q=70";

export function ExpoCard({ expo, index = 0 }) {
  const d = daysUntil(expo.startDate);
  const live = new Date(expo.startDate) <= new Date() && new Date(expo.endDate) >= new Date();
  return (
    <motion.article
      className="expo-card"
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-5% 0px" }}
      transition={{ duration: 0.7, delay: (index % 3) * 0.08, ease: [0.22, 1, 0.36, 1] }}
    >
      <Tilt className="expo-card__tilt" max={5}>
        <Link to={`/expos/${expo._id}`} className="expo-card__link">
          <div className="expo-card__media">
            <img
              src={assetUrl(expo.banner) || FALLBACK}
              alt=""
              loading="lazy"
              onError={(e) => {
                e.currentTarget.src = FALLBACK;
              }}
            />
            <div className="expo-card__chips">
              <span className="chip">{expo.category}</span>
              {live ? (
                <span className="chip chip--live">● Live now</span>
              ) : d > 0 ? (
                <span className="chip chip--gold">In {d} day{d === 1 ? "" : "s"}</span>
              ) : expo.status === "completed" || d <= 0 ? (
                <span className="chip">Past</span>
              ) : null}
              {expo.status && !["published", "completed"].includes(expo.status) && <Badge>{expo.status}</Badge>}
            </div>
          </div>
          <div className="expo-card__body">
            <p className="expo-card__date">{fmtRange(expo.startDate, expo.endDate)}</p>
            <h3>{expo.title}</h3>
            {expo.theme && <p className="expo-card__theme">“{expo.theme}”</p>}
            <p className="expo-card__loc">
              ⌖ {[expo.location?.venue, expo.location?.city].filter(Boolean).join(", ") || "Venue TBA"}
            </p>
            {expo.stats && (
              <div className="expo-card__stats">
                <span>
                  <strong>{expo.stats.exhibitors}</strong> exhibitors
                </span>
                <span>
                  <strong>{expo.stats.boothsAvailable}</strong> booths free
                </span>
                <span>
                  <strong>{expo.stats.attendees}</strong> going
                </span>
              </div>
            )}
          </div>
        </Link>
      </Tilt>
    </motion.article>
  );
}

const TYPE_ICON = { keynote: "★", talk: "◆", workshop: "⚒", panel: "☰", networking: "☍" };

export function SessionCard({ session, onRegister, onBookmark, busy, showExpo = false, actions = true }) {
  const past = new Date(session.endTime) < new Date();
  const full = session.capacity && session.seatsLeft === 0 && !session.isRegistered;
  return (
    <motion.article
      layout
      className={`session-card ${session.isRegistered ? "is-registered" : ""} ${past ? "is-past" : ""}`}
      initial={{ opacity: 0, x: -20 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
    >
      <div className="session-card__time">
        <span className="session-card__day">{fmtDay(session.startTime)}</span>
        <strong>{fmtTime(session.startTime)}</strong>
        <span>– {fmtTime(session.endTime)}</span>
      </div>
      <div className="session-card__main">
        <div className="session-card__meta">
          <span className={`stype stype--${session.type}`}>
            {TYPE_ICON[session.type] || "◆"} {session.type}
          </span>
          {session.topic && <span className="muted">#{session.topic}</span>}
          {session.location && <span className="muted">⌖ {session.location}</span>}
          {showExpo && session.expo?.title && <span className="muted">· {session.expo.title}</span>}
        </div>
        <h3>{session.title}</h3>
        {session.description && <p className="session-card__desc">{session.description}</p>}
        {session.speaker?.name && (
          <div className="speaker">
            <Avatar src={session.speaker.photo} name={session.speaker.name} size={34} />
            <div>
              <strong>{session.speaker.name}</strong>
              {session.speaker.title && <span>{session.speaker.title}</span>}
            </div>
          </div>
        )}
      </div>
      {actions && (
        <div className="session-card__actions">
          <span className="session-card__seats">
            {session.capacity ? `${session.seatsLeft} / ${session.capacity} seats left` : `${session.registeredCount} going`}
          </span>
          {onBookmark && (
            <button
              type="button"
              className={`icon-btn bookmark ${session.isBookmarked ? "is-on" : ""}`}
              onClick={() => onBookmark(session)}
              disabled={busy}
              aria-pressed={session.isBookmarked}
              title={session.isBookmarked ? "Remove bookmark" : "Bookmark & get a reminder"}
            >
              {session.isBookmarked ? "★" : "☆"}
            </button>
          )}
          {onRegister && !past && (
            <button
              type="button"
              className={`btn btn--sm ${session.isRegistered ? "btn--ghost" : "btn--gold"}`}
              onClick={() => onRegister(session)}
              disabled={busy || full}
            >
              {session.isRegistered ? "Leave" : full ? "Full" : "Reserve seat"}
            </button>
          )}
          {past && <Badge tone="muted">Finished</Badge>}
        </div>
      )}
    </motion.article>
  );
}

export function ExhibitorCard({ exhibitor, booth, expoTitle, index = 0 }) {
  const c = exhibitor.company || {};
  return (
    <motion.article
      className="exhibitor-card"
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay: (index % 4) * 0.06 }}
      whileHover={{ y: -6 }}
    >
      <Link to={`/exhibitors/${exhibitor._id}`} className="exhibitor-card__link">
        <div className="exhibitor-card__head">
          {c.logo ? <img src={assetUrl(c.logo)} alt="" className="exhibitor-card__logo" onError={(e) => (e.currentTarget.style.visibility = "hidden")} /> : <Avatar name={c.name || exhibitor.name} size={56} />}
          <div>
            <h3>{c.name || exhibitor.name}</h3>
            {c.category && <span className="chip">{c.category}</span>}
          </div>
        </div>
        {c.description && <p className="exhibitor-card__desc">{c.description}</p>}
        {(c.products || []).length > 0 && (
          <ul className="tags">
            {c.products.slice(0, 4).map((p) => (
              <li key={p}>{p}</li>
            ))}
          </ul>
        )}
        <div className="exhibitor-card__foot">
          {booth ? (
            <span>
              Booth <strong>{booth.code}</strong>
              {booth.hall ? ` · ${booth.hall}` : ""}
              {expoTitle ? ` · ${expoTitle}` : ""}
            </span>
          ) : (
            <span className="muted">View profile</span>
          )}
          <span aria-hidden="true">→</span>
        </div>
      </Link>
    </motion.article>
  );
}
