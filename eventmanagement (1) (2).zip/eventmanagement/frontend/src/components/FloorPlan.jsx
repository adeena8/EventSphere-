/**
 * Interactive expo floor plan.
 *  mode="view"    – public: hover/click occupied booths to see exhibitor
 *  mode="select"  – exhibitor picks an available booth
 *  mode="manage"  – organizer clicks any booth to edit/assign
 */
import { motion } from "framer-motion";
import { assetUrl } from "../lib/api.js";

const LEGEND = [
  ["available", "Available"],
  ["reserved", "Reserved"],
  ["occupied", "Occupied"],
  ["blocked", "Unavailable"],
];

export default function FloorPlan({
  floorPlan = { rows: 5, cols: 8 },
  booths = [],
  mode = "view",
  selectedId,
  highlightIds = [],
  onSelect,
  compact = false,
}) {
  const rows = floorPlan.rows || 1;
  const cols = floorPlan.cols || 1;
  const byPos = new Map(booths.map((b) => [`${b.row}:${b.col}`, b]));
  const highlight = new Set(highlightIds.map(String));

  const clickable = (b) => {
    if (!b) return false;
    if (mode === "manage") return true;
    if (mode === "select") return b.status === "available";
    return b.status === "occupied";
  };

  return (
    <div className={`floorplan ${compact ? "floorplan--compact" : ""}`}>
      <div className="floorplan__stage" aria-hidden="true">
        STAGE · ENTRANCE
      </div>
      <div className="floorplan__scroll" data-lenis-prevent>
        <div className="floorplan__grid" style={{ gridTemplateColumns: `repeat(${cols}, minmax(${compact ? 44 : 62}px, 1fr))` }}>
          {Array.from({ length: rows * cols }, (_, i) => {
            const r = Math.floor(i / cols);
            const c = i % cols;
            const b = byPos.get(`${r}:${c}`);
            if (!b) return <div key={i} className="booth booth--empty" aria-hidden="true" />;
            const isSel = String(selectedId) === String(b._id);
            const isHi = highlight.has(String(b._id));
            const name = b.exhibitor?.company?.name || b.displayName || "";
            return (
              <motion.button
                type="button"
                key={b._id}
                className={`booth booth--${b.status} booth--${b.size} ${isSel ? "is-selected" : ""} ${isHi ? "is-highlight" : ""}`}
                disabled={!clickable(b)}
                onClick={() => clickable(b) && onSelect?.(b)}
                whileHover={clickable(b) ? { y: -3, scale: 1.04 } : undefined}
                whileTap={clickable(b) ? { scale: 0.97 } : undefined}
                initial={{ opacity: 0, scale: 0.85 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: Math.min(0.6, i * 0.008), type: "spring", stiffness: 260, damping: 22 }}
                title={`${b.code} · ${b.status}${name ? ` · ${name}` : ""}${b.price ? ` · $${b.price}` : ""}`}
                aria-label={`Booth ${b.code}, ${b.status}${name ? `, ${name}` : ""}`}
              >
                <span className="booth__code">{b.code}</span>
                {!compact && b.exhibitor?.company?.logo ? (
                  <img className="booth__logo" src={assetUrl(b.exhibitor.company.logo)} alt="" onError={(e) => (e.currentTarget.style.display = "none")} />
                ) : null}
                {!compact && name && <span className="booth__name">{name}</span>}
              </motion.button>
            );
          })}
        </div>
      </div>
      <ul className="floorplan__legend">
        {LEGEND.map(([k, label]) => (
          <li key={k}>
            <i className={`dot dot--${k}`} /> {label}
          </li>
        ))}
        {highlight.size > 0 && (
          <li>
            <i className="dot dot--highlight" /> Your booth
          </li>
        )}
      </ul>
    </div>
  );
}
