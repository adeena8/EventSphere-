import { useRef } from "react";
import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";

/** Interior page header with a parallax background image */
export default function PageHero({ eyebrow, title, children, image, small = false }) {
  const ref = useRef(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], ["0%", "35%"]);
  const scale = useTransform(scrollYProgress, [0, 1], [1.05, 1.2]);
  const textY = useTransform(scrollYProgress, [0, 1], ["0%", "-40%"]);
  const opacity = useTransform(scrollYProgress, [0, 0.8], [1, 0]);

  return (
    <section ref={ref} className={`page-hero ${small ? "page-hero--small" : ""}`}>
      {image && (
        <motion.div className="page-hero__bg" style={reduce ? undefined : { y, scale }} aria-hidden="true">
          <img src={image} alt="" />
        </motion.div>
      )}
      <div className="page-hero__veil" aria-hidden="true" />
      <motion.div className="page-hero__inner" style={reduce ? undefined : { y: textY, opacity }}>
        {eyebrow && (
          <motion.p className="eyebrow" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
            {eyebrow}
          </motion.p>
        )}
        <motion.h1 initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1], delay: 0.05 }}>
          {title}
        </motion.h1>
        {children && (
          <motion.div className="page-hero__sub" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.15 }}>
            {children}
          </motion.div>
        )}
      </motion.div>
    </section>
  );
}
