import { Suspense, useEffect, useState } from "react";
import { Link, NavLink, Navigate, useLocation, useNavigate, useOutlet } from "react-router-dom";
import { AnimatePresence, motion, useMotionValueEvent, useScroll } from "framer-motion";
import { useAuth } from "../../context/AuthContext.jsx";
import { useSocket } from "../../context/SocketContext.jsx";
import { Avatar, Spinner } from "../ui/UI.jsx";
import { ScrollProgress } from "../motion/Motion.jsx";
import { ROLE_LABEL } from "../../lib/format.js";

/* ============================== Public navbar ============================== */

const PUBLIC_LINKS = [
  ["/expos", "Expos"],
  ["/exhibitors", "Exhibitors"],
  ["/gallery", "Gallery"],
  ["/about", "About"],
  ["/faq", "Help"],
  ["/contact", "Contact"],
];

export function Navbar() {
  const { user } = useAuth();
  const { unreadNotifications } = useSocket() || {};
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [hidden, setHidden] = useState(false);
  const { scrollY } = useScroll();
  const { pathname } = useLocation();

  useMotionValueEvent(scrollY, "change", (y) => {
    const prev = scrollY.getPrevious() ?? 0;
    setScrolled(y > 30);
    setHidden(y > 420 && y > prev && !open);
  });

  useEffect(() => setOpen(false), [pathname]);
  useEffect(() => {
    document.body.classList.toggle("nav-open", open);
  }, [open]);

  return (
    <>
      <ScrollProgress />
      <motion.header
        className={`site-header ${scrolled ? "is-scrolled" : ""}`}
        animate={{ y: hidden ? "-110%" : "0%" }}
        transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
      >
        <Link to="/" className="logo" aria-label="EventSphere home">
          <span className="logo__mark" aria-hidden="true" />
          EVENTSPHERE
        </Link>
        <nav className="nav" aria-label="Primary">
          {PUBLIC_LINKS.map(([to, label]) => (
            <NavLink key={to} to={to} className={({ isActive }) => (isActive ? "is-active" : "")}>
              {label}
            </NavLink>
          ))}
        </nav>
        <div className="site-header__actions">
          {user ? (
            <>
              <Link to="/dashboard/notifications" className="bell" aria-label={`Notifications (${unreadNotifications || 0} unread)`}>
                🔔
                {unreadNotifications > 0 && <span className="bell__count">{unreadNotifications > 9 ? "9+" : unreadNotifications}</span>}
              </Link>
              <Link to="/dashboard" className="nav-user">
                <Avatar src={user.avatar} name={user.name} size={30} />
                <span>Dashboard</span>
              </Link>
            </>
          ) : (
            <>
              <Link to="/login" className="nav-link-plain">
                Log in
              </Link>
              <Link to="/register" className="btn btn--glow btn--sm">
                Get started
              </Link>
            </>
          )}
          <button
            type="button"
            className={`nav-toggle ${open ? "is-open" : ""}`}
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            onClick={() => setOpen((o) => !o)}
          >
            <span />
            <span />
          </button>
        </div>
      </motion.header>

      <AnimatePresence>
        {open && (
          <motion.div
            className="mobile-nav"
            initial={{ clipPath: "circle(0% at 95% 4%)" }}
            animate={{ clipPath: "circle(150% at 95% 4%)" }}
            exit={{ clipPath: "circle(0% at 95% 4%)" }}
            transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          >
            {[...PUBLIC_LINKS, ...(user ? [["/dashboard", "Dashboard"]] : [["/login", "Log in"], ["/register", "Create account"]])].map(
              ([to, label], i) => (
                <motion.div key={to} initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 + i * 0.05 }}>
                  <Link to={to}>{label}</Link>
                </motion.div>
              )
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

/* ============================== Footer ============================== */

export function Footer() {
  return (
    <footer className="footer">
      <div className="footer__inner">
        <div className="footer__brand">
          <Link to="/" className="logo">
            <span className="logo__mark" aria-hidden="true" />
            EVENTSPHERE
          </Link>
          <p>Expo &amp; trade-show management — floor plans, schedules and connections in real time.</p>
        </div>
        <nav className="footer__nav" aria-label="Footer">
          <strong>Explore</strong>
          <Link to="/expos">Upcoming expos</Link>
          <Link to="/exhibitors">Exhibitor directory</Link>
          <Link to="/gallery">Gallery</Link>
        </nav>
        <nav className="footer__nav" aria-label="Help">
          <strong>Help</strong>
          <Link to="/faq">User guide &amp; FAQ</Link>
          <Link to="/contact">Contact &amp; support</Link>
          <Link to="/privacy">Privacy policy</Link>
        </nav>
        <div className="footer__meta">
          <strong>Get in touch</strong>
          <a href="mailto:hello@eventsphere.com">hello@eventsphere.com</a>
          <p>+92 21 555 0199</p>
        </div>
      </div>
      <p className="footer__copy">© {new Date().getFullYear()} EventSphere Management. All rights reserved.</p>
    </footer>
  );
}

export function PublicLayout() {
  const outlet = useOutlet();
  const { pathname } = useLocation();
  return (
    <>
      <a className="skip-link" href="#main">
        Skip to content
      </a>
      <div className="grain" aria-hidden="true" />
      <Navbar />
      <main id="main">
        <AnimatePresence mode="wait">
          <motion.div
            key={pathname}
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
          >
            <Suspense fallback={<Spinner full />}>{outlet}</Suspense>
          </motion.div>
        </AnimatePresence>
      </main>
      <Footer />
    </>
  );
}

/* ============================== Route guards ============================== */

export function RequireAuth({ roles, children }) {
  const { user, loading } = useAuth();
  const location = useLocation();
  if (loading) return <Spinner full label="Checking your session…" />;
  if (!user) return <Navigate to="/login" replace state={{ from: location.pathname + location.search }} />;
  if (roles && !roles.includes(user.role)) return <Navigate to="/dashboard" replace />;
  return children;
}

export function GuestOnly({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <Spinner full />;
  if (user) return <Navigate to="/dashboard" replace />;
  return children;
}

/* ============================== Dashboard shell ============================== */

const NAV = {
  common_top: [["", "Overview", "◈"]],
  admin: [
    ["analytics", "Analytics", "▤"],
    ["expos", "Expos", "◉"],
    ["floorplan", "Floor plans", "▦"],
    ["applications", "Exhibitor applications", "✎"],
    ["schedule", "Schedules", "◷"],
    ["checkin", "Check-in & tickets", "⌁"],
    ["users", "Users", "☺"],
    ["feedback", "Feedback inbox", "✉"],
    ["announce", "Announcements", "📣"],
    ["system", "System & backups", "⚙"],
  ],
  organizer: [
    ["analytics", "Analytics", "▤"],
    ["expos", "My expos", "◉"],
    ["floorplan", "Floor plans", "▦"],
    ["applications", "Exhibitor applications", "✎"],
    ["schedule", "Schedules", "◷"],
    ["checkin", "Check-in & tickets", "⌁"],
    ["feedback", "Feedback inbox", "✉"],
    ["announce", "Announcements", "📣"],
  ],
  exhibitor: [
    ["applications", "Applications", "✎"],
    ["booths", "My booths", "▦"],
    ["company", "Company profile", "❖"],
    ["sessions", "My sessions", "◷"],
  ],
  attendee: [
    ["tickets", "My tickets", "⌁"],
    ["sessions", "My schedule", "◷"],
  ],
  common_bottom: [
    ["messages", "Messages", "✉"],
    ["notifications", "Notifications", "🔔"],
    ["support", "Support", "?"],
    ["profile", "Account & privacy", "☺"],
  ],
};

export function DashboardLayout() {
  const { user, logout } = useAuth();
  const { unreadMessages, unreadNotifications, connected } = useSocket() || {};
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const outlet = useOutlet();

  useEffect(() => setOpen(false), [pathname]);
  if (!user) return null;

  const items = [...NAV.common_top, ...(NAV[user.role] || []), ...NAV.common_bottom];
  const badge = (key) => (key === "messages" ? unreadMessages : key === "notifications" ? unreadNotifications : 0);

  return (
    <div className="dash">
      <div className="grain" aria-hidden="true" />
      <aside className={`dash__side ${open ? "is-open" : ""}`} data-lenis-prevent>
        <Link to="/" className="logo dash__logo">
          <span className="logo__mark" aria-hidden="true" />
          EVENTSPHERE
        </Link>
        <div className="dash__me">
          <Avatar src={user.avatar} name={user.name} size={44} />
          <div>
            <strong>{user.name}</strong>
            <span>
              {ROLE_LABEL[user.role]}
              <i className={`live-dot ${connected ? "is-on" : ""}`} title={connected ? "Live updates on" : "Reconnecting…"} />
            </span>
          </div>
        </div>
        <nav className="dash__nav" aria-label="Dashboard">
          {items.map(([to, label, icon]) => (
            <NavLink key={to} to={`/dashboard${to ? `/${to}` : ""}`} end={to === ""} className={({ isActive }) => (isActive ? "is-active" : "")}>
              <span className="dash__icon" aria-hidden="true">
                {icon}
              </span>
              <span>{label}</span>
              {badge(to) > 0 && <span className="pill">{badge(to)}</span>}
            </NavLink>
          ))}
        </nav>
        <div className="dash__side-foot">
          <Link to="/expos" className="btn btn--ghost btn--sm btn--block">
            Browse expos
          </Link>
          <button
            type="button"
            className="btn btn--sm btn--block btn--plain"
            onClick={() => {
              logout();
              navigate("/");
            }}
          >
            Log out
          </button>
        </div>
      </aside>
      {open && <div className="dash__scrim" onClick={() => setOpen(false)} aria-hidden="true" />}
      <div className="dash__main">
        <header className="dash__top">
          <button type="button" className="nav-toggle dash__toggle" aria-label="Open dashboard menu" onClick={() => setOpen((o) => !o)}>
            <span />
            <span />
          </button>
          <span className="dash__crumb">{pathname.replace("/dashboard", "Dashboard").split("/").filter(Boolean).join(" / ")}</span>
          <Link to="/dashboard/notifications" className="bell" aria-label="Notifications">
            🔔{unreadNotifications > 0 && <span className="bell__count">{unreadNotifications > 9 ? "9+" : unreadNotifications}</span>}
          </Link>
        </header>
        <AnimatePresence mode="wait">
          <motion.div
            key={pathname}
            className="dash__content"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
          >
            <Suspense fallback={<Spinner label="Loading…" />}>{outlet}</Suspense>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
