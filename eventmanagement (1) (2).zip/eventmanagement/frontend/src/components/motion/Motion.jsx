/**
 * Reusable motion + parallax primitives built on framer-motion.
 */
import { useEffect, useRef, useState } from "react";
import {
  motion, useScroll, useTransform, useSpring, useInView, useReducedMotion, animate, useMotionValue,
} from "framer-motion";

const EASE = [0.22, 1, 0.36, 1];

/** Fade/slide in when scrolled into view */
export function Reveal({ children, delay = 0, y = 36, x = 0, once = true, className, as = "div", ...rest }) {
  const reduce = useReducedMotion();
  const Comp = motion[as] || motion.div;
  return (
    <Comp
      className={className}
      initial={reduce ? { opacity: 0 } : { opacity: 0, y, x }}
      whileInView={{ opacity: 1, y: 0, x: 0 }}
      viewport={{ once, margin: "0px 0px -10% 0px" }}
      transition={{ duration: 0.85, ease: EASE, delay }}
      {...rest}
    >
      {children}
    </Comp>
  );
}

/** Stagger children that use <StaggerItem> */
export function Stagger({ children, className, gap = 0.08, as = "div", ...rest }) {
  const Comp = motion[as] || motion.div;
  return (
    <Comp
      className={className}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, margin: "0px 0px -8% 0px" }}
      variants={{ hidden: {}, show: { transition: { staggerChildren: gap } } }}
      {...rest}
    >
      {children}
    </Comp>
  );
}
export function StaggerItem({ children, className, as = "div", ...rest }) {
  const Comp = motion[as] || motion.div;
  return (
    <Comp
      className={className}
      variants={{
        hidden: { opacity: 0, y: 34, scale: 0.98 },
        show: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.7, ease: EASE } },
      }}
      {...rest}
    >
      {children}
    </Comp>
  );
}

/**
 * Parallax layer: moves `speed` × scroll distance while its section passes the viewport.
 * speed > 0 → moves slower than scroll (classic background parallax), < 0 → faster.
 */
export function Parallax({ children, speed = 0.2, className, style, rotate = 0, scale = false, ...rest }) {
  const ref = useRef(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const dist = 220 * speed;
  const yRaw = useTransform(scrollYProgress, [0, 1], [dist, -dist]);
  const y = useSpring(yRaw, { stiffness: 120, damping: 28, mass: 0.3 });
  const r = useTransform(scrollYProgress, [0, 1], [-rotate, rotate]);
  const s = useTransform(scrollYProgress, [0, 0.5, 1], scale ? [0.92, 1, 0.92] : [1, 1, 1]);
  return (
    <motion.div ref={ref} className={className} style={reduce ? style : { ...style, y, rotate: r, scale: s }} {...rest}>
      {children}
    </motion.div>
  );
}

/** Image that drifts inside its frame (the frame clips) */
export function ParallaxImage({ src, alt = "", className = "", strength = 0.18, overlay = true, children }) {
  const ref = useRef(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], [`-${strength * 100}%`, `${strength * 100}%`]);
  const scale = useTransform(scrollYProgress, [0, 0.5, 1], [1.18, 1.12, 1.18]);
  return (
    <div ref={ref} className={`pimg ${className}`}>
      <motion.img
        src={src}
        alt={alt}
        loading="lazy"
        style={reduce ? undefined : { y, scale }}
        onError={(e) => {
          e.currentTarget.style.visibility = "hidden";
        }}
      />
      {overlay && <div className="pimg__veil" aria-hidden="true" />}
      {children && <div className="pimg__content">{children}</div>}
    </div>
  );
}

/** Thin gold progress bar at the top of the page */
export function ScrollProgress() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 140, damping: 30, restDelta: 0.001 });
  return <motion.div className="scroll-progress" style={{ scaleX }} aria-hidden="true" />;
}

/** Animated number that counts up when visible */
export function CountUp({ to = 0, decimals = 0, suffix = "", prefix = "", duration = 1.8 }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-10% 0px" });
  const [val, setVal] = useState(0);
  useEffect(() => {
    if (!inView) return undefined;
    const controls = animate(0, Number(to) || 0, { duration, ease: EASE, onUpdate: (v) => setVal(v) });
    return () => controls.stop();
  }, [inView, to, duration]);
  return (
    <span ref={ref}>
      {prefix}
      {val.toLocaleString(undefined, { minimumFractionDigits: decimals, maximumFractionDigits: decimals })}
      {suffix}
    </span>
  );
}

/** Letters rise one-by-one */
export function SplitText({ text, className, delay = 0, stagger = 0.045 }) {
  const reduce = useReducedMotion();
  return (
    <span className={className} aria-label={text}>
      {text.split("").map((ch, i) => (
        <motion.span
          key={i}
          aria-hidden="true"
          style={{ display: "inline-block", whiteSpace: "pre" }}
          initial={reduce ? { opacity: 0 } : { opacity: 0, y: "0.6em", rotateX: -70 }}
          animate={{ opacity: 1, y: 0, rotateX: 0 }}
          transition={{ duration: 0.9, ease: EASE, delay: delay + i * stagger }}
        >
          {ch}
        </motion.span>
      ))}
    </span>
  );
}

/** Element that gently follows the cursor (for CTAs) */
export function Magnetic({ children, strength = 0.25, className }) {
  const ref = useRef(null);
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const sx = useSpring(x, { stiffness: 220, damping: 18 });
  const sy = useSpring(y, { stiffness: 220, damping: 18 });
  return (
    <motion.span
      ref={ref}
      className={className}
      style={{ display: "inline-block", x: sx, y: sy }}
      onPointerMove={(e) => {
        if (e.pointerType !== "mouse") return;
        const r = ref.current.getBoundingClientRect();
        x.set((e.clientX - r.left - r.width / 2) * strength);
        y.set((e.clientY - r.top - r.height / 2) * strength);
      }}
      onPointerLeave={() => {
        x.set(0);
        y.set(0);
      }}
    >
      {children}
    </motion.span>
  );
}

/** 3D tilt card following the pointer */
export function Tilt({ children, className, max = 8 }) {
  const ref = useRef(null);
  const rx = useMotionValue(0);
  const ry = useMotionValue(0);
  const srx = useSpring(rx, { stiffness: 180, damping: 20 });
  const sry = useSpring(ry, { stiffness: 180, damping: 20 });
  const reduce = useReducedMotion();
  return (
    <motion.div
      ref={ref}
      className={className}
      style={reduce ? undefined : { rotateX: srx, rotateY: sry, transformPerspective: 900 }}
      onPointerMove={(e) => {
        if (e.pointerType !== "mouse" || reduce) return;
        const r = ref.current.getBoundingClientRect();
        const px = (e.clientX - r.left) / r.width - 0.5;
        const py = (e.clientY - r.top) / r.height - 0.5;
        ry.set(px * max * 2);
        rx.set(-py * max * 2);
      }}
      onPointerLeave={() => {
        rx.set(0);
        ry.set(0);
      }}
    >
      {children}
    </motion.div>
  );
}

/** Route-level page transition wrapper */
export function Page({ children, className = "" }) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -12 }}
      transition={{ duration: 0.5, ease: EASE }}
    >
      {children}
    </motion.div>
  );
}

export { EASE };
