/**
 * Lightweight SVG charts (no chart library needed).
 */
import { useState } from "react";
import { motion } from "framer-motion";

const PALETTE = ["#c9a227", "#7a8f7a", "#b0566a", "#8fa7c4", "#d08b4c", "#a58fd1", "#e8d5a3"];

/** Vertical bars over time / categories */
export function BarChart({ data = [], height = 200, format = (v) => v, labelEvery = 1, color = "#c9a227" }) {
  const [hover, setHover] = useState(null);
  const max = Math.max(1, ...data.map((d) => d.value));
  const w = 100 / Math.max(1, data.length);
  return (
    <div className="chart">
      <svg viewBox={`0 0 100 ${height / 2}`} preserveAspectRatio="none" className="chart__svg" style={{ height }} role="img" aria-label="Bar chart">
        {[0.25, 0.5, 0.75].map((g) => (
          <line key={g} x1="0" x2="100" y1={(height / 2) * g} y2={(height / 2) * g} className="chart__grid" />
        ))}
        {data.map((d, i) => {
          const h = (d.value / max) * (height / 2 - 4);
          return (
            <motion.rect
              key={d.label ?? i}
              x={i * w + w * 0.18}
              width={w * 0.64}
              rx="0.6"
              initial={{ y: height / 2, height: 0 }}
              animate={{ y: height / 2 - h, height: h }}
              transition={{ duration: 0.8, delay: i * 0.02, ease: [0.22, 1, 0.36, 1] }}
              fill={hover === i ? "#e8d5a3" : color}
              opacity={hover === null || hover === i ? 1 : 0.55}
              onMouseEnter={() => setHover(i)}
              onMouseLeave={() => setHover(null)}
            />
          );
        })}
      </svg>
      <div className="chart__labels">
        {data.map((d, i) => (
          <span key={i} style={{ width: `${w}%` }}>
            {i % labelEvery === 0 ? d.short ?? d.label : ""}
          </span>
        ))}
      </div>
      <div className="chart__tip" aria-live="polite">
        {hover !== null && data[hover] ? `${data[hover].label}: ${format(data[hover].value)}` : " "}
      </div>
    </div>
  );
}

/** Horizontal ranked bars */
export function HBars({ data = [], format = (v) => v }) {
  const max = Math.max(1, ...data.map((d) => d.value));
  return (
    <ul className="hbars">
      {data.map((d, i) => (
        <li key={d.label + i}>
          <div className="hbars__row">
            <span className="hbars__label">{d.label}</span>
            <span className="hbars__value">{format(d.value)}</span>
          </div>
          <div className="hbars__track">
            <motion.span
              className="hbars__fill"
              style={{ background: PALETTE[i % PALETTE.length] }}
              initial={{ width: 0 }}
              whileInView={{ width: `${(d.value / max) * 100}%` }}
              viewport={{ once: true }}
              transition={{ duration: 0.9, delay: i * 0.05, ease: [0.22, 1, 0.36, 1] }}
            />
          </div>
          {d.sub && <span className="hbars__sub">{d.sub}</span>}
        </li>
      ))}
    </ul>
  );
}

/** Donut with legend */
export function Donut({ data = [], size = 160, center }) {
  const total = data.reduce((s, d) => s + d.value, 0) || 1;
  const r = 42;
  const c = 2 * Math.PI * r;
  let acc = 0;
  return (
    <div className="donut">
      <svg width={size} height={size} viewBox="0 0 100 100" role="img" aria-label="Donut chart">
        <circle cx="50" cy="50" r={r} fill="none" stroke="rgba(232,213,163,0.08)" strokeWidth="12" />
        {data.map((d, i) => {
          const len = (d.value / total) * c;
          const el = (
            <motion.circle
              key={d.label}
              cx="50"
              cy="50"
              r={r}
              fill="none"
              stroke={d.color || PALETTE[i % PALETTE.length]}
              strokeWidth="12"
              strokeDasharray={`${len} ${c - len}`}
              strokeDashoffset={-acc}
              transform="rotate(-90 50 50)"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: i * 0.1 }}
            />
          );
          acc += len;
          return el;
        })}
        {center && (
          <text x="50" y="54" textAnchor="middle" className="donut__center">
            {center}
          </text>
        )}
      </svg>
      <ul className="donut__legend">
        {data.map((d, i) => (
          <li key={d.label}>
            <i style={{ background: d.color || PALETTE[i % PALETTE.length] }} />
            <span>{d.label}</span>
            <strong>{d.value}</strong>
          </li>
        ))}
      </ul>
    </div>
  );
}

/** Small progress ring */
export function Ring({ value = 0, label, size = 96 }) {
  const r = 40;
  const c = 2 * Math.PI * r;
  return (
    <div className="ring" style={{ width: size }}>
      <svg viewBox="0 0 100 100" width={size} height={size}>
        <circle cx="50" cy="50" r={r} fill="none" stroke="rgba(232,213,163,0.1)" strokeWidth="9" />
        <motion.circle
          cx="50"
          cy="50"
          r={r}
          fill="none"
          stroke="#c9a227"
          strokeWidth="9"
          strokeLinecap="round"
          strokeDasharray={c}
          initial={{ strokeDashoffset: c }}
          animate={{ strokeDashoffset: c - (Math.min(100, value) / 100) * c }}
          transition={{ duration: 1.1, ease: [0.22, 1, 0.36, 1] }}
          transform="rotate(-90 50 50)"
        />
        <text x="50" y="56" textAnchor="middle" className="ring__value">
          {Math.round(value)}%
        </text>
      </svg>
      {label && <span className="ring__label">{label}</span>}
    </div>
  );
}
