import { useEffect, useId, useState } from "react";
import { createPortal } from "react-dom";
import { AnimatePresence, motion } from "framer-motion";
import { assetUrl } from "../../lib/api.js";
import { initials } from "../../lib/format.js";

export function Spinner({ label = "Loading…", full = false }) {
  return (
    <div className={`spinner ${full ? "spinner--full" : ""}`} role="status">
      <span className="spinner__ring" aria-hidden="true" />
      <span className="spinner__label">{label}</span>
    </div>
  );
}

export function Empty({ icon = "✦", title = "Nothing here yet", children, action }) {
  return (
    <div className="empty">
      <span className="empty__icon" aria-hidden="true">
        {icon}
      </span>
      <h3>{title}</h3>
      {children && <p>{children}</p>}
      {action}
    </div>
  );
}

export function ErrorBox({ error, onRetry }) {
  if (!error) return null;
  return (
    <div className="alert alert--error" role="alert">
      <span>{error.message || String(error)}</span>
      {onRetry && (
        <button type="button" className="btn btn--sm btn--ghost" onClick={onRetry}>
          Retry
        </button>
      )}
    </div>
  );
}

const BADGE_TONE = {
  published: "green", approved: "green", confirmed: "green", active: "green", occupied: "gold", resolved: "green",
  pending: "amber", reserved: "amber", draft: "muted", in_progress: "amber", open: "amber",
  rejected: "red", cancelled: "red", suspended: "red", blocked: "muted", withdrawn: "muted", completed: "blue", available: "teal",
};
export function Badge({ children, tone }) {
  const t = tone || BADGE_TONE[String(children).toLowerCase()] || "muted";
  return <span className={`badge badge--${t}`}>{String(children).replace(/_/g, " ")}</span>;
}

export function Avatar({ src, name = "", size = 40 }) {
  const [broken, setBroken] = useState(false);
  useEffect(() => setBroken(false), [src]);
  return src && !broken ? (
    <img className="avatar" src={assetUrl(src)} alt="" width={size} height={size} style={{ width: size, height: size }} onError={() => setBroken(true)} />
  ) : (
    <span className="avatar avatar--initials" style={{ width: size, height: size, fontSize: size * 0.38 }} aria-hidden="true">
      {initials(name) || "?"}
    </span>
  );
}

export function Modal({ open, onClose, title, children, wide = false, footer }) {
  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => e.key === "Escape" && onClose?.();
    document.addEventListener("keydown", onKey);
    document.body.classList.add("modal-open");
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.classList.remove("modal-open");
    };
  }, [open, onClose]);

  return createPortal(
    <AnimatePresence>
      {open && (
        <motion.div
          className="modal"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onMouseDown={(e) => e.target === e.currentTarget && onClose?.()}
          data-lenis-prevent
        >
          <motion.div
            className={`modal__panel ${wide ? "modal__panel--wide" : ""}`}
            role="dialog"
            aria-modal="true"
            aria-label={title}
            initial={{ opacity: 0, y: 40, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.98 }}
            transition={{ type: "spring", stiffness: 320, damping: 30 }}
          >
            <header className="modal__head">
              <h2>{title}</h2>
              <button type="button" className="icon-btn" onClick={onClose} aria-label="Close">
                ×
              </button>
            </header>
            <div className="modal__body">{children}</div>
            {footer && <footer className="modal__foot">{footer}</footer>}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body
  );
}

export function Field({ label, hint, error, children, full = false }) {
  const id = useId();
  const child = typeof children === "function" ? children(id) : children;
  return (
    <label className={`field ${full ? "field--full" : ""} ${error ? "field--error" : ""}`} htmlFor={typeof children === "function" ? id : undefined}>
      <span className="field__label">{label}</span>
      {child}
      {error ? <span className="field__error">{error}</span> : hint ? <span className="field__hint">{hint}</span> : null}
    </label>
  );
}

export function Tabs({ tabs, value, onChange }) {
  return (
    <div className="tabs" role="tablist">
      {tabs.map((t) => (
        <button
          key={t.value}
          type="button"
          role="tab"
          aria-selected={value === t.value}
          className={`tabs__tab ${value === t.value ? "is-active" : ""}`}
          onClick={() => onChange(t.value)}
        >
          {t.label}
          {t.count != null && <span className="tabs__count">{t.count}</span>}
          {value === t.value && <motion.span layoutId="tab-underline" className="tabs__ink" />}
        </button>
      ))}
    </div>
  );
}

export function StatCard({ label, value, hint, icon, tone = "gold" }) {
  return (
    <motion.div className={`stat-card stat-card--${tone}`} whileHover={{ y: -4 }} transition={{ type: "spring", stiffness: 300, damping: 20 }}>
      <div className="stat-card__top">
        <span className="stat-card__label">{label}</span>
        {icon && <span className="stat-card__icon" aria-hidden="true">{icon}</span>}
      </div>
      <strong className="stat-card__value">{value ?? "—"}</strong>
      {hint && <span className="stat-card__hint">{hint}</span>}
    </motion.div>
  );
}

export function PageHead({ eyebrow, title, children, actions }) {
  return (
    <header className="page-head">
      <div>
        {eyebrow && <p className="eyebrow">{eyebrow}</p>}
        <h1>{title}</h1>
        {children && <p className="lede">{children}</p>}
      </div>
      {actions && <div className="page-head__actions">{actions}</div>}
    </header>
  );
}

export function Select({ value, onChange, options, placeholder, ...rest }) {
  return (
    <select value={value} onChange={(e) => onChange(e.target.value)} {...rest}>
      {placeholder !== undefined && <option value="">{placeholder}</option>}
      {options.map((o) => (
        <option key={o.value ?? o} value={o.value ?? o}>
          {o.label ?? o}
        </option>
      ))}
    </select>
  );
}
