import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { api, tokenStore, setUnauthorizedHandler } from "../lib/api.js";

const AuthCtx = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(() => tokenStore.get());
  const [loading, setLoading] = useState(!!tokenStore.get());

  const logout = useCallback(() => {
    tokenStore.set(null);
    setToken(null);
    setUser(null);
  }, []);

  useEffect(() => {
    setUnauthorizedHandler(logout);
  }, [logout]);

  useEffect(() => {
    if (!token) {
      setLoading(false);
      return;
    }
    let alive = true;
    api
      .get("/auth/me")
      .then((d) => alive && setUser(d.user))
      .catch(() => alive && logout())
      .finally(() => alive && setLoading(false));
    return () => {
      alive = false;
    };
  }, [token, logout]);

  const applySession = useCallback((data) => {
    if (data.token) {
      tokenStore.set(data.token);
      setToken(data.token);
    }
    if (data.user) setUser(data.user);
    return data;
  }, []);

  const login = useCallback(async (email, password) => applySession(await api.post("/auth/login", { email, password })), [applySession]);
  const register = useCallback(async (payload) => applySession(await api.post("/auth/register", payload)), [applySession]);

  const value = useMemo(
    () => ({
      user,
      token,
      loading,
      isStaff: !!user && ["admin", "organizer"].includes(user.role),
      login,
      register,
      logout,
      setUser,
      applySession,
    }),
    [user, token, loading, login, register, logout, applySession]
  );

  return <AuthCtx.Provider value={value}>{children}</AuthCtx.Provider>;
}

export const useAuth = () => useContext(AuthCtx);
