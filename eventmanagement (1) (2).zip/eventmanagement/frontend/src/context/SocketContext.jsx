/**
 * Real-time connection (Socket.IO).
 * Keeps live unread counters for notifications + messages and
 * exposes the socket so pages can subscribe to expo/schedule/booth events.
 */
import { createContext, useCallback, useContext, useEffect, useRef, useState } from "react";
import { io } from "socket.io-client";
import { API_BASE, api } from "../lib/api.js";
import { useAuth } from "./AuthContext.jsx";
import { useToast } from "./ToastContext.jsx";

const SocketCtx = createContext(null);

export function SocketProvider({ children }) {
  const { token, user } = useAuth();
  const toast = useToast();
  const [socket, setSocket] = useState(null);
  const [connected, setConnected] = useState(false);
  const [unreadNotifications, setUnreadNotifications] = useState(0);
  const [unreadMessages, setUnreadMessages] = useState(0);
  const toastRef = useRef(toast);
  toastRef.current = toast;

  useEffect(() => {
    const s = io(API_BASE || undefined, {
      auth: token ? { token } : {},
      transports: ["websocket", "polling"],
      reconnectionDelayMax: 8000,
    });
    setSocket(s);
    s.on("connect", () => setConnected(true));
    s.on("disconnect", () => setConnected(false));
    return () => {
      s.disconnect();
      setSocket(null);
    };
  }, [token]);

  const refreshCounts = useCallback(() => {
    if (!user) {
      setUnreadNotifications(0);
      setUnreadMessages(0);
      return;
    }
    api.get("/notifications", { limit: 1 }).then((d) => setUnreadNotifications(d.unread)).catch(() => {});
    api.get("/messages/unread-count").then((d) => setUnreadMessages(d.count)).catch(() => {});
  }, [user]);

  useEffect(() => {
    refreshCounts();
  }, [refreshCounts]);

  useEffect(() => {
    if (!socket || !user) return undefined;
    const onNotif = (n) => {
      setUnreadNotifications((c) => c + 1);
      toastRef.current.show(n.body || "", { title: n.title, type: n.type === "reminder" ? "success" : "info" });
    };
    const onMsg = (m) => {
      if (String(m.to) === String(user._id)) {
        setUnreadMessages((c) => c + 1);
        if (!window.location.pathname.includes(`/messages/${m.from}`)) {
          toastRef.current.show(m.body.slice(0, 90), { title: `💬 ${m.fromUser?.name || "New message"}` });
        }
      }
    };
    socket.on("notification:new", onNotif);
    socket.on("message:new", onMsg);
    return () => {
      socket.off("notification:new", onNotif);
      socket.off("message:new", onMsg);
    };
  }, [socket, user]);

  return (
    <SocketCtx.Provider
      value={{ socket, connected, unreadNotifications, setUnreadNotifications, unreadMessages, setUnreadMessages, refreshCounts }}
    >
      {children}
    </SocketCtx.Provider>
  );
}

export const useSocket = () => useContext(SocketCtx);

/** Subscribe to a socket event for the lifetime of a component */
export function useSocketEvent(event, handler, deps = []) {
  const { socket } = useSocket() || {};
  const ref = useRef(handler);
  ref.current = handler;
  useEffect(() => {
    if (!socket) return undefined;
    const fn = (...args) => ref.current(...args);
    socket.on(event, fn);
    return () => socket.off(event, fn);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [socket, event, ...deps]);
}

/** Join an expo room to receive live schedule / booth updates */
export function useExpoRoom(expoId) {
  const { socket, connected } = useSocket() || {};
  useEffect(() => {
    if (!socket || !expoId) return undefined;
    socket.emit("expo:join", expoId);
    return () => socket.emit("expo:leave", expoId);
  }, [socket, connected, expoId]);
}
