import { useCallback, useEffect, useRef, useState } from "react";
import { api } from "../lib/api.js";

/**
 * const { data, loading, error, reload, setData } = useFetch("/expos", { q }, [q]);
 * Pass path = null to skip.
 */
export function useFetch(path, query, deps = []) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(!!path);
  const [error, setError] = useState(null);
  const reqId = useRef(0);
  const queryKey = JSON.stringify(query || {});

  const load = useCallback(
    async ({ silent = false } = {}) => {
      if (!path) {
        setLoading(false);
        return null;
      }
      const id = ++reqId.current;
      if (!silent) setLoading(true);
      setError(null);
      try {
        const d = await api.get(path, query);
        if (id === reqId.current) setData(d);
        return d;
      } catch (e) {
        if (id === reqId.current) setError(e);
        return null;
      } finally {
        if (id === reqId.current) setLoading(false);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [path, queryKey, ...deps]
  );

  useEffect(() => {
    load();
  }, [load]);

  const reload = useCallback((opts) => load({ silent: true, ...opts }), [load]);
  return { data, loading, error, reload, setData };
}

/** Debounce a changing value */
export function useDebounced(value, ms = 300) {
  const [v, setV] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setV(value), ms);
    return () => clearTimeout(t);
  }, [value, ms]);
  return v;
}
