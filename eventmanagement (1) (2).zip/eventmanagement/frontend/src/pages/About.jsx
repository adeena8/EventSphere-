import { Link } from "react-router-dom";
import PageHero from "../components/PageHero.jsx";
import { Reveal, ParallaxImage, Parallax, Stagger, StaggerItem } from "../components/motion/Motion.jsx";

const U = (id, w = 1400) => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=${w}&q=75`;

export default function About() {
  return (
    <>
      <PageHero eyebrow="About EventSphere" title="We fix the expo, not just the website" image={U("photo-1475721027785-f74eccf877e2", 2000)}>
        <p>Manual registration, scattered emails and outdated floor plans cost organizers, exhibitors and visitors time and money. We built one connected system instead.</p>
      </PageHero>

      <section className="section">
        <div className="section__inner split">
          <Reveal className="split__text">
            <p className="eyebrow">Our story</p>
            <h2>Born on the expo floor</h2>
            <p className="prose">
              EventSphere Management has organized large-scale expos and trade shows across industries for over a decade. We watched
              exhibitors queue for paper forms, attendees wander halls looking for a stand, and organizers juggle spreadsheets that were
              out of date the moment they were printed.
            </p>
            <p className="prose">
              So we built a platform where every booth, session and conversation lives in one place — and updates in real time for
              everybody who needs it.
            </p>
          </Reveal>
          <Parallax speed={0.15} className="split__media">
            <ParallaxImage src={U("photo-1540575467063-178a50c2df87")} strength={0.15} />
          </Parallax>
        </div>
      </section>

      <section className="section">
        <div className="section__inner">
          <Reveal className="section__head">
            <p className="eyebrow">What we value</p>
            <h2>Principles</h2>
          </Reveal>
          <Stagger className="features__grid">
            {[
              ["⚡", "Real-time by default", "Schedules, booth allocations and announcements reach everyone instantly."],
              ["⛨", "Privacy first", "Encrypted data, granular consent, and the right to export or erase your data at any time."],
              ["♿", "Accessible", "Keyboard friendly, screen-reader labels, reduced-motion support and high contrast."],
              ["📱", "Any device", "A responsive interface that works on phones in the hall and laptops in the office."],
            ].map(([i, t, d]) => (
              <StaggerItem key={t} className="feature">
                <span className="feature__icon" aria-hidden="true">{i}</span>
                <h3>{t}</h3>
                <p>{d}</p>
              </StaggerItem>
            ))}
          </Stagger>
        </div>
      </section>

      <section className="cta">
        <Reveal className="cta__inner">
          <h2>Let's build your next expo together</h2>
          <div className="hero__actions">
            <Link to="/contact" className="btn btn--glow">Contact us</Link>
            <Link to="/expos" className="btn btn--ghost">See expos</Link>
          </div>
        </Reveal>
      </section>
    </>
  );
}
