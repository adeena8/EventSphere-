import { useState } from "react";
import PageHero from "../components/PageHero.jsx";
import { Field, ErrorBox } from "../components/ui/UI.jsx";
import { Reveal } from "../components/motion/Motion.jsx";
import { useAuth } from "../context/AuthContext.jsx";
import { useToast } from "../context/ToastContext.jsx";
import { api } from "../lib/api.js";

export default function Contact() {
  const { user } = useAuth();
  const toast = useToast();
  const [form, setForm] = useState({ type: "inquiry", subject: "", message: "", name: "", email: "" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const [done, setDone] = useState(false);
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api.post("/feedback", form);
      setDone(true);
      toast.success("Thanks — we'll get back to you soon.");
    } catch (err) {
      setError(err);
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <PageHero eyebrow="Contact & support" title="Let's talk" image="https://images.unsplash.com/photo-1556761175-5973dc0f32e7?auto=format&fit=crop&w=2000&q=70" small>
        <p>Questions, suggestions or a problem to report — we read everything.</p>
      </PageHero>
      <section className="section section--tight">
        <div className="section__inner split">
          <Reveal className="split__text">
            <h2>Reach us directly</h2>
            <p className="prose">✉ hello@eventsphere.com</p>
            <p className="prose">☎ +92 21 555 0199</p>
            <p className="prose">⌖ Expo Centre, University Road, Karachi</p>
            <p className="muted">Office hours: Mon–Sat, 9:00–18:00 PKT</p>
          </Reveal>
          <Reveal delay={0.1} className="panel">
            {done ? (
              <div className="empty">
                <span className="empty__icon">✓</span>
                <h3>Message received</h3>
                <p>We usually reply within one working day.</p>
                <button type="button" className="btn btn--ghost" onClick={() => { setDone(false); setForm((f) => ({ ...f, subject: "", message: "" })); }}>
                  Send another
                </button>
              </div>
            ) : (
              <form className="form-grid" onSubmit={submit}>
                {!user && (
                  <>
                    <Field label="Name">
                      <input required value={form.name} onChange={set("name")} autoComplete="name" />
                    </Field>
                    <Field label="Email">
                      <input required type="email" value={form.email} onChange={set("email")} autoComplete="email" />
                    </Field>
                  </>
                )}
                <Field label="Type">
                  <select value={form.type} onChange={set("type")}>
                    <option value="inquiry">General inquiry</option>
                    <option value="suggestion">Suggestion</option>
                    <option value="issue">Report an issue</option>
                    <option value="feedback">Feedback</option>
                  </select>
                </Field>
                <Field label="Subject">
                  <input required value={form.subject} onChange={set("subject")} maxLength={160} />
                </Field>
                <Field label="Message" full>
                  <textarea required rows={5} value={form.message} onChange={set("message")} />
                </Field>
                <ErrorBox error={error} />
                <div className="form-actions field--full">
                  <button type="submit" className="btn btn--gold" disabled={busy}>
                    {busy ? "Sending…" : "Send message"}
                  </button>
                </div>
              </form>
            )}
          </Reveal>
        </div>
      </section>
    </>
  );
}
