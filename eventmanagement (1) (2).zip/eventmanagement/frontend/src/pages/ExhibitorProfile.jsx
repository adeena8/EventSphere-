import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import PageHero from "../components/PageHero.jsx";
import FloorPlan from "../components/FloorPlan.jsx";
import { Spinner, ErrorBox, Avatar, Empty } from "../components/ui/UI.jsx";
import { Reveal } from "../components/motion/Motion.jsx";
import { useFetch } from "../hooks/useFetch.js";
import { useAuth } from "../context/AuthContext.jsx";
import { api, assetUrl } from "../lib/api.js";
import { fmtRange } from "../lib/format.js";

export default function ExhibitorProfile() {
  const { id } = useParams();
  const { user } = useAuth();
  const { data, loading, error, reload } = useFetch(`/exhibitors/${id}`);
  const [activeBooth, setActiveBooth] = useState(null);
  const [plan, setPlan] = useState(null);

  const booths = data?.booths || [];
  const booth = activeBooth || booths[0];

  // record booth traffic once per profile view
  useEffect(() => {
    if (booths[0]) api.post(`/booths/${booths[0]._id}/visit`, { source: "profile" }).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data]);

  useEffect(() => {
    if (!booth) return;
    api.get(`/expos/${booth.expo._id}/booths`).then(setPlan).catch(() => setPlan(null));
  }, [booth?._id]); // eslint-disable-line react-hooks/exhaustive-deps

  if (loading && !data) return <Spinner full />;
  if (error) {
    return (
      <section className="section">
        <div className="section__inner">
          <ErrorBox error={error} onRetry={reload} />
        </div>
      </section>
    );
  }
  const ex = data.exhibitor;
  const c = ex.company || {};

  return (
    <>
      <PageHero eyebrow={c.category || "Exhibitor"} title={c.name || ex.name} image="https://images.unsplash.com/photo-1556761175-b413da4baf72?auto=format&fit=crop&w=2000&q=70" small />
      <section className="section section--tight">
        <div className="section__inner overview">
          <Reveal className="overview__main">
            <div className="profile-head">
              {c.logo ? <img src={assetUrl(c.logo)} alt="" className="profile-head__logo" onError={(e) => (e.currentTarget.style.visibility = "hidden")} /> : <Avatar name={c.name} size={88} />}
              <div>
                <h2>{c.name}</h2>
                {c.website && (
                  <a href={c.website} target="_blank" rel="noreferrer noopener" className="link-arrow">
                    {c.website.replace(/^https?:\/\//, "")} ↗
                  </a>
                )}
              </div>
            </div>
            <p className="prose">{c.description || "This exhibitor hasn't added a description yet."}</p>
            {c.products?.length > 0 && (
              <>
                <h3 className="mt">Products &amp; services</h3>
                <ul className="tags">
                  {c.products.map((p) => (
                    <li key={p}>{p}</li>
                  ))}
                </ul>
              </>
            )}

            <h3 className="mt">Where to find them</h3>
            {booths.length === 0 ? (
              <Empty title="No booths allocated yet" icon="▦" />
            ) : (
              <>
                <div className="seg">
                  {booths.map((b) => (
                    <button key={b._id} type="button" className={booth?._id === b._id ? "is-active" : ""} onClick={() => setActiveBooth(b)}>
                      {b.expo.title} · {b.code}
                    </button>
                  ))}
                </div>
                {booth && (
                  <p className="muted">
                    Booth <strong className="gold">{booth.code}</strong> · {booth.hall} · {fmtRange(booth.expo.startDate, booth.expo.endDate)} ·{" "}
                    <Link to={`/expos/${booth.expo._id}?tab=floorplan&booth=${booth._id}`}>open expo</Link>
                  </p>
                )}
                {plan && <FloorPlan floorPlan={plan.floorPlan} booths={plan.booths} mode="view" selectedId={booth?._id} highlightIds={[booth?._id]} compact />}
              </>
            )}
          </Reveal>
          <Reveal className="overview__side" delay={0.1}>
            <div className="panel">
              <h3>Contact</h3>
              {c.contactEmail && (
                <p>
                  ✉ <a href={`mailto:${c.contactEmail}`}>{c.contactEmail}</a>
                </p>
              )}
              {user && String(user._id) !== String(ex._id) && ex.allowMessages ? (
                <Link to={`/dashboard/messages/${ex._id}`} className="btn btn--gold btn--block mt-sm">
                  Send a message
                </Link>
              ) : !user ? (
                <Link to="/login" state={{ from: `/exhibitors/${id}` }} className="btn btn--ghost btn--block mt-sm">
                  Log in to message
                </Link>
              ) : null}
            </div>
            {booth?.staff?.length > 0 && (
              <div className="panel">
                <h3>Booth team</h3>
                {booth.staff.map((s) => (
                  <div className="speaker" key={s.name}>
                    <Avatar name={s.name} size={34} />
                    <div>
                      <strong>{s.name}</strong>
                      <span>{s.role}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Reveal>
        </div>
      </section>
    </>
  );
}
