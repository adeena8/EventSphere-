import { useState } from "react";
import PageHero from "../components/PageHero.jsx";
import { ExhibitorCard } from "../components/Cards.jsx";
import { Spinner, Empty, ErrorBox } from "../components/ui/UI.jsx";
import { useFetch, useDebounced } from "../hooks/useFetch.js";

export default function Exhibitors() {
  const [q, setQ] = useState("");
  const [category, setCategory] = useState("");
  const dq = useDebounced(q);
  const { data, loading, error, reload } = useFetch("/exhibitors", { q: dq, category });

  return (
    <>
      <PageHero
        eyebrow="Exhibitor directory"
        title="Meet the companies"
        image="https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=2000&q=70"
      >
        <p>Search by category, product or keyword — then find them on the floor plan or send a message.</p>
      </PageHero>
      <section className="section section--tight">
        <div className="section__inner">
          <div className="filters">
            <input type="search" className="filters__search" placeholder="e.g. robots, solar, cloud hosting…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search exhibitors" />
            <select value={category} onChange={(e) => setCategory(e.target.value)} aria-label="Category">
              <option value="">All categories</option>
              {(data?.categories || []).map((c) => (
                <option key={c}>{c}</option>
              ))}
            </select>
          </div>
          <ErrorBox error={error} onRetry={reload} />
          {loading && !data ? (
            <Spinner />
          ) : data?.items?.length ? (
            <div className="grid grid--3">
              {data.items.map((x, i) => {
                const b = x.booths?.[0];
                return <ExhibitorCard key={x._id} exhibitor={x} booth={b} expoTitle={b?.expo?.title} index={i} />;
              })}
            </div>
          ) : (
            <Empty title="No exhibitors found" icon="❖" />
          )}
        </div>
      </section>
    </>
  );
}
