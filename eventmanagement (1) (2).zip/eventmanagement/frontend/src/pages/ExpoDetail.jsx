import { useMemo, useState } from "react";
import { Link, useNavigate, useParams, useSearchParams } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import PageHero from "../components/PageHero.jsx";
import FloorPlan from "../components/FloorPlan.jsx";
import ApplyModal from "../components/ApplyModal.jsx";
import { SessionCard, ExhibitorCard } from "../components/Cards.jsx";
import { Spinner, Empty, ErrorBox, Tabs, Badge, Avatar } from "../components/ui/UI.jsx";
import { Reveal, Stagger, StaggerItem } from "../components/motion/Motion.jsx";
import { useFetch, useDebounced } from "../hooks/useFetch.js";
import { useAuth } from "../context/AuthContext.jsx";
import { useToast } from "../context/ToastContext.jsx";
import { useSocketEvent, useExpoRoom } from "../context/SocketContext.jsx";
import { api, assetUrl } from "../lib/api.js";
import { fmtRange, fmtDay, fmtDate } from "../lib/format.js";

export default function ExpoDetail() {
  const { id } = useParams();
  const [params, setParams] = useSearchParams();
  const tab = params.get("tab") || "overview";
  const { user } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();

  const expoQ = useFetch(`/expos/${id}`, null, [user?._id]);
  const sessionsQ = useFetch(`/expos/${id}/sessions`, null, [user?._id]);
  const boothsQ = useFetch(`/expos/${id}/booths`);
  const [busy, setBusy] = useState(false);
  const [applyOpen, setApplyOpen] = useState(false);
  const [liveFlash, setLiveFlash] = useState("");

  // real-time
  useExpoRoom(id);
  const flash = (m) => {
    setLiveFlash(m);
    setTimeout(() => setLiveFlash(""), 3500);
  };
  useSocketEvent("schedule:updated", (p) => {
    if (String(p.expoId) !== id) return;
    sessionsQ.reload();
    if (p.action !== "seats") flash("Schedule updated live");
  });
  useSocketEvent("booths:updated", (p) => {
    if (String(p.expoId) !== id) return;
    boothsQ.reload();
    expoQ.reload();
    flash("Floor plan updated live");
  });
  useSocketEvent("expo:updated", (p) => {
    if (String(p.expoId) !== id) return;
    if (p.action === "deleted") navigate("/expos");
    else expoQ.reload();
  });

  const setTab = (t) => {
    const n = new URLSearchParams(params);
    n.set("tab", t);
    setParams(n, { replace: true });
  };

  if (expoQ.loading && !expoQ.data) return <Spinner full />;
  if (expoQ.error) {
    return (
      <section className="section">
        <div className="section__inner">
          <ErrorBox error={expoQ.error} onRetry={expoQ.reload} />
          <Link to="/expos" className="link-arrow">← Back to expos</Link>
        </div>
      </section>
    );
  }
  const expo = expoQ.data.expo;
  const sessions = sessionsQ.data?.items || [];
  const ended = new Date(expo.endDate) < new Date();

  async function register() {
    if (!user) return navigate("/login", { state: { from: `/expos/${id}` } });
    setBusy(true);
    try {
      if (expo.myRegistration) {
        if (!window.confirm("Cancel your registration for this expo?")) return;
        await api.del(`/expos/${id}/register`);
        toast.info("Registration cancelled");
      } else {
        await api.post(`/expos/${id}/register`);
        toast.success("You're in! Your QR ticket is in your dashboard.", { title: "Registered 🎉" });
      }
      expoQ.reload();
      sessionsQ.reload();
    } catch (e) {
      toast.error(e.message);
    } finally {
      setBusy(false);
    }
  }

  async function sessionAction(kind, s) {
    if (!user) return navigate("/login", { state: { from: `/expos/${id}?tab=schedule` } });
    setBusy(true);
    try {
      if (kind === "bookmark") {
        const r = await api.post(`/sessions/${s._id}/bookmark`);
        toast.info(r.bookmarked ? "Bookmarked — we'll remind you 30 min before it starts." : "Bookmark removed");
      } else if (s.isRegistered) {
        await api.del(`/sessions/${s._id}/register`);
        toast.info("Seat released");
      } else {
        await api.post(`/sessions/${s._id}/register`);
        toast.success(`Seat reserved for “${s.title}”`);
      }
      sessionsQ.reload();
    } catch (e) {
      toast.error(e.message);
    } finally {
      setBusy(false);
    }
  }

  const tabs = [
    { value: "overview", label: "Overview" },
    { value: "schedule", label: "Schedule", count: sessions.length },
    { value: "exhibitors", label: "Exhibitors", count: expo.stats?.exhibitors },
    { value: "floorplan", label: "Floor plan" },
  ];

  return (
    <>
      <PageHero eyebrow={`${expo.category}${expo.theme ? ` · ${expo.theme}` : ""}`} title={expo.title} image={assetUrl(expo.banner)}>
        <p>
          {fmtRange(expo.startDate, expo.endDate)} · {[expo.location?.venue, expo.location?.city].filter(Boolean).join(", ")}
        </p>
        <div className="hero__actions">
          {(!user || user.role === "attendee") && !ended && expo.status === "published" && (
            <button type="button" className={`btn ${expo.myRegistration ? "btn--ghost" : "btn--glow"}`} onClick={register} disabled={busy}>
              {expo.myRegistration ? "✓ Registered · Cancel" : expo.stats?.seatsLeft === 0 ? "Fully booked" : "Register — free"}
            </button>
          )}
          {user?.role === "exhibitor" && !ended && expo.status === "published" && (
            expo.myApplication && ["pending", "approved"].includes(expo.myApplication.status) ? (
              <Link to="/dashboard/applications" className="btn btn--ghost">
                Application {expo.myApplication.status}
                {expo.myApplication.assignedBooth ? ` · Booth ${expo.myApplication.assignedBooth.code}` : ""}
              </Link>
            ) : (
              <button type="button" className="btn btn--glow" onClick={() => setApplyOpen(true)}>
                Apply to exhibit
              </button>
            )
          )}
          {expo.canManage && (
            <Link to={`/dashboard/floorplan?expo=${expo._id}`} className="btn btn--ghost">
              Manage expo
            </Link>
          )}
          {expo.myRegistration && (
            <Link to="/dashboard/tickets" className="btn btn--ghost">
              View ticket
            </Link>
          )}
        </div>
      </PageHero>

      <section className="section section--tight">
        <div className="section__inner">
          <AnimatePresence>
            {liveFlash && (
              <motion.div className="live-flash" initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <i className="live-dot is-on" /> {liveFlash}
              </motion.div>
            )}
          </AnimatePresence>

          <Stagger className="kpis">
            {[
              ["Exhibitors", expo.stats?.exhibitors],
              ["Booths available", expo.stats?.boothsAvailable],
              ["Sessions", expo.stats?.sessions],
              ["Attendees", expo.stats?.attendees],
              ...(expo.stats?.seatsLeft != null ? [["Seats left", expo.stats.seatsLeft]] : []),
            ].map(([l, v]) => (
              <StaggerItem key={l} className="kpi">
                <strong>{v ?? 0}</strong>
                <span>{l}</span>
              </StaggerItem>
            ))}
          </Stagger>

          <Tabs tabs={tabs} value={tab} onChange={setTab} />

          <AnimatePresence mode="wait">
            <motion.div key={tab} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.3 }}>
              {tab === "overview" && <Overview expo={expo} sessions={sessions} onTab={setTab} />}
              {tab === "schedule" && (
                <Schedule sessions={sessions} loading={sessionsQ.loading && !sessionsQ.data} busy={busy} onAction={sessionAction} canAct={!ended} />
              )}
              {tab === "exhibitors" && <ExhibitorsTab expoId={id} onLocate={(b) => setParams({ tab: "floorplan", booth: b._id }, { replace: true })} />}
              {tab === "floorplan" && <PlanTab plan={boothsQ.data} expo={expo} focusId={params.get("booth")} user={user} />}
            </motion.div>
          </AnimatePresence>
        </div>
      </section>

      {user?.role === "exhibitor" && (
        <ApplyModal
          expo={expo}
          open={applyOpen}
          onClose={() => setApplyOpen(false)}
          onDone={() => {
            expoQ.reload();
            boothsQ.reload();
          }}
        />
      )}
    </>
  );
}

function Overview({ expo, sessions, onTab }) {
  const highlights = sessions.filter((s) => s.type === "keynote" || s.type === "workshop").slice(0, 3);
  return (
    <div className="overview">
      <Reveal className="overview__main">
        <h2>About this expo</h2>
        <p className="prose">{expo.description || "Details coming soon."}</p>
        {expo.tags?.length > 0 && (
          <ul className="tags">
            {expo.tags.map((t) => (
              <li key={t}>{t}</li>
            ))}
          </ul>
        )}
        {highlights.length > 0 && (
          <>
            <h3 className="mt">Highlights</h3>
            {highlights.map((s) => (
              <SessionCard key={s._id} session={s} actions={false} />
            ))}
            <button type="button" className="link-arrow" onClick={() => onTab("schedule")}>
              Full schedule →
            </button>
          </>
        )}
      </Reveal>
      <Reveal className="overview__side" delay={0.1}>
        <div className="panel">
          <h3>When &amp; where</h3>
          <dl className="dl">
            <dt>Dates</dt>
            <dd>{fmtRange(expo.startDate, expo.endDate)}</dd>
            <dt>Venue</dt>
            <dd>{expo.location?.venue || "TBA"}</dd>
            {expo.location?.address && (
              <>
                <dt>Address</dt>
                <dd>{expo.location.address}</dd>
              </>
            )}
            <dt>City</dt>
            <dd>{expo.location?.city || "—"}</dd>
            <dt>Status</dt>
            <dd>
              <Badge>{expo.status}</Badge>
            </dd>
          </dl>
        </div>
        {expo.organizer && (
          <div className="panel">
            <h3>Organizer</h3>
            <div className="speaker">
              <Avatar src={expo.organizer.avatar} name={expo.organizer.name} size={40} />
              <div>
                <strong>{expo.organizer.name}</strong>
                <span>EventSphere organizer</span>
              </div>
            </div>
            <Link to={`/dashboard/messages/${expo.organizer._id}`} className="btn btn--ghost btn--sm btn--block mt-sm">
              Message organizer
            </Link>
          </div>
        )}
      </Reveal>
    </div>
  );
}

function Schedule({ sessions, loading, busy, onAction, canAct }) {
  const [type, setType] = useState("");
  const days = useMemo(() => {
    const map = new Map();
    for (const s of sessions.filter((x) => !type || x.type === type)) {
      const k = new Date(s.startTime).toDateString();
      if (!map.has(k)) map.set(k, []);
      map.get(k).push(s);
    }
    return [...map.entries()];
  }, [sessions, type]);

  if (loading) return <Spinner />;
  if (!sessions.length) return <Empty title="Schedule coming soon" icon="◷">The organizer hasn't published sessions yet.</Empty>;
  return (
    <div className="schedule">
      <div className="seg" role="group" aria-label="Session type">
        {["", "keynote", "talk", "workshop", "panel", "networking"].map((t) => (
          <button key={t || "all"} type="button" className={type === t ? "is-active" : ""} onClick={() => setType(t)}>
            {t || "All"}
          </button>
        ))}
      </div>
      {days.map(([day, list]) => (
        <div key={day} className="schedule__day">
          <h3 className="schedule__day-title">{fmtDay(list[0].startTime)}</h3>
          {list.map((s) => (
            <SessionCard
              key={s._id}
              session={s}
              busy={busy}
              onRegister={canAct ? (x) => onAction("register", x) : undefined}
              onBookmark={(x) => onAction("bookmark", x)}
            />
          ))}
        </div>
      ))}
    </div>
  );
}

function ExhibitorsTab({ expoId, onLocate }) {
  const [q, setQ] = useState("");
  const [category, setCategory] = useState("");
  const dq = useDebounced(q);
  const { data, loading, error } = useFetch(`/expos/${expoId}/exhibitors`, { q: dq, category });
  return (
    <div>
      <div className="filters">
        <input type="search" className="filters__search" placeholder="Search company, product or booth…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search exhibitors" />
        <select value={category} onChange={(e) => setCategory(e.target.value)} aria-label="Category">
          <option value="">All categories</option>
          {(data?.categories || []).map((c) => (
            <option key={c}>{c}</option>
          ))}
        </select>
      </div>
      <ErrorBox error={error} />
      {loading && !data ? (
        <Spinner />
      ) : data?.items?.length ? (
        <div className="grid grid--3">
          {data.items.map((x, i) => (
            <div key={x.booth._id} className="stack-sm">
              <ExhibitorCard exhibitor={x.exhibitor} booth={x.booth} index={i} />
              <button type="button" className="btn btn--plain btn--sm" onClick={() => onLocate(x.booth)}>
                ⌖ Show booth {x.booth.code} on map
              </button>
            </div>
          ))}
        </div>
      ) : (
        <Empty title="No exhibitors found" icon="❖">Try another search — or check back as applications get approved.</Empty>
      )}
    </div>
  );
}

function PlanTab({ plan, expo, focusId, user }) {
  const [selected, setSelected] = useState(null);
  const focus = selected || plan?.booths?.find((b) => b._id === focusId) || null;

  const select = (b) => {
    setSelected(b);
    api.post(`/booths/${b._id}/visit`, { source: "floorplan" }).catch(() => {});
  };

  if (!plan) return <Spinner />;
  if (!plan.booths.length) return <Empty title="Floor plan not published yet" icon="▦" />;
  const mine = user ? plan.booths.filter((b) => b.exhibitor && String(b.exhibitor._id) === String(user._id)).map((b) => b._id) : [];

  return (
    <div className="plan-layout">
      <FloorPlan floorPlan={plan.floorPlan} booths={plan.booths} mode="view" selectedId={focus?._id} highlightIds={mine} onSelect={select} />
      <AnimatePresence mode="wait">
        <motion.aside key={focus?._id || "none"} className="panel plan-layout__side" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0 }}>
          {focus && focus.exhibitor ? (
            <>
              <p className="eyebrow">Booth {focus.code} · {focus.hall}</p>
              <div className="speaker">
                <Avatar src={focus.exhibitor.company?.logo || focus.exhibitor.avatar} name={focus.exhibitor.company?.name || focus.exhibitor.name} size={48} />
                <div>
                  <strong>{focus.exhibitor.company?.name || focus.displayName}</strong>
                  <span>{focus.exhibitor.company?.category}</span>
                </div>
              </div>
              {focus.description && <p className="mt-sm">{focus.description}</p>}
              {focus.products?.length > 0 && (
                <ul className="tags mt-sm">
                  {focus.products.map((p) => (
                    <li key={p}>{p}</li>
                  ))}
                </ul>
              )}
              <div className="stack-sm mt-sm">
                <Link to={`/exhibitors/${focus.exhibitor._id}`} className="btn btn--gold btn--sm btn--block">
                  View profile
                </Link>
                {user && String(user._id) !== String(focus.exhibitor._id) && (
                  <Link to={`/dashboard/messages/${focus.exhibitor._id}`} className="btn btn--ghost btn--sm btn--block">
                    Message exhibitor
                  </Link>
                )}
              </div>
            </>
          ) : (
            <>
              <p className="eyebrow">Floor plan</p>
              <h3>{expo.title}</h3>
              <p className="muted">
                {plan.floorPlan.rows} × {plan.floorPlan.cols} grid · {plan.booths.length} booths. Click a gold booth to see who's exhibiting.
              </p>
              <p className="muted mt-sm">Updated live as booths are allocated · {fmtDate(new Date())}</p>
            </>
          )}
        </motion.aside>
      </AnimatePresence>
    </div>
  );
}
