import { useState } from "react";
import { useSearchParams } from "react-router-dom";
import PageHero from "../components/PageHero.jsx";
import { ExpoCard } from "../components/Cards.jsx";
import { Spinner, Empty, ErrorBox } from "../components/ui/UI.jsx";
import { useFetch, useDebounced } from "../hooks/useFetch.js";
import { useSocketEvent } from "../context/SocketContext.jsx";

export default function Expos() {
  const [params, setParams] = useSearchParams();
  const [q, setQ] = useState(params.get("q") || "");
  const category = params.get("category") || "";
  const when = params.get("when") || "upcoming";
  const page = Number(params.get("page") || 1);
  const dq = useDebounced(q, 350);

  const { data, loading, error, reload } = useFetch("/expos", { q: dq, category, when, page, limit: 9 });
  useSocketEvent("expo:updated", () => reload());

  const set = (k, v) => {
    const next = new URLSearchParams(params);
    if (v) next.set(k, v);
    else next.delete(k);
    if (k !== "page") next.delete("page");
    setParams(next, { replace: true });
  };

  return (
    <>
      <PageHero
        eyebrow="Expos & trade shows"
        title="Find your next expo"
        image="https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=2000&q=70"
      >
        <p>Browse upcoming shows, explore floor plans and reserve your place.</p>
      </PageHero>

      <section className="section section--tight">
        <div className="section__inner">
          <div className="filters">
            <input
              type="search"
              className="filters__search"
              placeholder="Search by name, theme or city…"
              value={q}
              onChange={(e) => {
                setQ(e.target.value);
                set("q", e.target.value);
              }}
              aria-label="Search expos"
            />
            <select value={category} onChange={(e) => set("category", e.target.value)} aria-label="Category">
              <option value="">All categories</option>
              {(data?.categories || []).map((c) => (
                <option key={c}>{c}</option>
              ))}
            </select>
            <div className="seg" role="group" aria-label="When">
              {[
                ["upcoming", "Upcoming"],
                ["past", "Past"],
                ["all", "All"],
              ].map(([v, l]) => (
                <button key={l} type="button" className={when === v ? "is-active" : ""} onClick={() => set("when", v)}>
                  {l}
                </button>
              ))}
            </div>
          </div>

          <ErrorBox error={error} onRetry={reload} />
          {loading && !data ? (
            <Spinner />
          ) : data?.items?.length ? (
            <>
              <div className="grid grid--3">
                {data.items.map((e, i) => (
                  <ExpoCard key={e._id} expo={e} index={i} />
                ))}
              </div>
              {data.pages > 1 && (
                <nav className="pager" aria-label="Pagination">
                  <button type="button" className="btn btn--ghost btn--sm" disabled={page <= 1} onClick={() => set("page", String(page - 1))}>
                    ← Prev
                  </button>
                  <span>
                    Page {page} of {data.pages}
                  </span>
                  <button type="button" className="btn btn--ghost btn--sm" disabled={page >= data.pages} onClick={() => set("page", String(page + 1))}>
                    Next →
                  </button>
                </nav>
              )}
            </>
          ) : (
            <Empty title="No expos match your search" icon="⌕">
              Try a different keyword or category.
            </Empty>
          )}
        </div>
      </section>
    </>
  );
}
