import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Link } from "react-router-dom";
import PageHero from "../components/PageHero.jsx";
import { Reveal } from "../components/motion/Motion.jsx";

/** User documentation: role guides + FAQ */
const GUIDES = {
  Attendees: [
    ["Create an account", "Click “Get started”, choose Attendee and accept the privacy policy."],
    ["Register for an expo", "Open any expo and press “Register — free”. Your QR ticket appears under Dashboard → My tickets."],
    ["Plan your day", "In the Schedule tab, reserve seats for sessions or ★ bookmark them. You'll be reminded 30 minutes before they start."],
    ["Find exhibitors", "Use the Exhibitors tab or the directory to search by product or category, then “Show booth on map”."],
    ["Get in touch", "Press “Message exhibitor” on any profile — replies arrive in real time under Messages."],
  ],
  Exhibitors: [
    ["Complete your company profile", "Dashboard → Company profile: logo, description, products and contact details."],
    ["Apply to an expo", "Open an expo and press “Apply to exhibit”. Upload documents and click an available booth to reserve it."],
    ["Track your application", "Dashboard → Applications shows pending/approved/rejected and your assigned booth."],
    ["Manage your booth", "Dashboard → My booths: products showcased, staff on duty, booth traffic and neighbouring exhibitors."],
    ["Collaborate", "Message organizers for support or your booth neighbours to plan joint demos."],
  ],
  Organizers: [
    ["Get approved", "Organizer accounts are activated by an administrator after sign-up."],
    ["Create an expo", "Dashboard → My expos → New expo. Tick “generate booths” to create the floor-plan grid automatically."],
    ["Allocate booths", "Dashboard → Floor plans: click any booth to change size/price, block it or assign an approved exhibitor."],
    ["Review exhibitors", "Dashboard → Exhibitor applications: approve (optionally choosing a booth) or reject with a note."],
    ["Build the schedule", "Dashboard → Schedules: add sessions with speakers, rooms and capacity. Changes notify attendees instantly."],
    ["Run the day", "Check-in & tickets lets you check attendees in by ticket code. Analytics updates live."],
  ],
};

const FAQ = [
  ["Is it free for attendees?", "Yes. Registering for expos and sessions is free unless an organizer says otherwise."],
  ["How do reminders work?", "Bookmark or reserve a session and you'll get an in-app notification 30 minutes before it starts."],
  ["Why is a booth marked “reserved”?", "Another exhibitor has requested it and the organizer is reviewing their application."],
  ["Can I change my booth?", "Message the organizer — they can re-assign booths at any time from the floor-plan manager."],
  ["How is my data protected?", "Passwords are hashed with bcrypt, phone numbers are encrypted (AES-256), traffic is protected with HTTPS in production, and you can export or delete your data from Account & privacy."],
  ["I forgot my password", "Use “Forgot password” on the login page. The reset link is valid for 30 minutes."],
  ["Which browsers are supported?", "The latest Chrome, Firefox, Safari and Edge on desktop and mobile."],
];

function Item({ q, a }) {
  const [open, setOpen] = useState(false);
  return (
    <div className={`acc ${open ? "is-open" : ""}`}>
      <button type="button" className="acc__q" aria-expanded={open} onClick={() => setOpen((o) => !o)}>
        {q}
        <span aria-hidden="true">{open ? "−" : "+"}</span>
      </button>
      <AnimatePresence initial={false}>
        {open && (
          <motion.div className="acc__a" initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }}>
            <p>{a}</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function Faq() {
  const [role, setRole] = useState("Attendees");
  return (
    <>
      <PageHero eyebrow="Help centre" title="User guide & FAQ" image="https://images.unsplash.com/photo-1559223607-a43c990c692c?auto=format&fit=crop&w=2000&q=70" small>
        <p>Step-by-step tutorials for every role.</p>
      </PageHero>
      <section className="section section--tight">
        <div className="section__inner">
          <div className="seg">
            {Object.keys(GUIDES).map((r) => (
              <button key={r} type="button" className={role === r ? "is-active" : ""} onClick={() => setRole(r)}>
                {r}
              </button>
            ))}
          </div>
          <AnimatePresence mode="wait">
            <motion.ol key={role} className="guide" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              {GUIDES[role].map(([t, d], i) => (
                <motion.li key={t} initial={{ opacity: 0, x: -16 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.06 }}>
                  <span className="guide__n">{i + 1}</span>
                  <div>
                    <h3>{t}</h3>
                    <p>{d}</p>
                  </div>
                </motion.li>
              ))}
            </motion.ol>
          </AnimatePresence>

          <Reveal className="section__head mt">
            <h2>Frequently asked questions</h2>
          </Reveal>
          <div className="accs">
            {FAQ.map(([q, a]) => (
              <Item key={q} q={q} a={a} />
            ))}
          </div>
          <p className="muted mt">
            Still stuck? <Link to="/contact">Contact support</Link>.
          </p>
        </div>
      </section>
    </>
  );
}
