import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import PageHero from "../components/PageHero.jsx";
import { Spinner, Empty } from "../components/ui/UI.jsx";
import { Parallax } from "../components/motion/Motion.jsx";
import { useFetch } from "../hooks/useFetch.js";
import { assetUrl } from "../lib/api.js";

export default function Gallery() {
  const { data, loading } = useFetch("/gallery");
  const [open, setOpen] = useState(null);
  const items = data?.items || [];
  // split into 3 columns that drift at different speeds
  const cols = [[], [], []];
  items.forEach((it, i) => cols[i % 3].push(it));

  return (
    <>
      <PageHero
        eyebrow="Gallery"
        title="Moments from the floor"
        image="https://images.unsplash.com/photo-1492684223066-81342ee5ff7c?auto=format&fit=crop&w=2000&q=70"
      />
      <section className="section section--tight">
        <div className="section__inner">
          {loading && !data ? (
            <Spinner />
          ) : !items.length ? (
            <Empty title="No photos yet" icon="❒" />
          ) : (
            <div className="masonry">
              {cols.map((col, ci) => (
                <Parallax key={ci} speed={[0.05, -0.12, 0.1][ci]} className="masonry__col">
                  {col.map((it, i) => (
                    <motion.button
                      type="button"
                      key={it._id}
                      className="masonry__item"
                      onClick={() => setOpen(it)}
                      initial={{ opacity: 0, y: 40 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.7, delay: i * 0.05 }}
                      whileHover={{ scale: 1.02 }}
                      layoutId={`g-${it._id}`}
                    >
                      <img src={assetUrl(it.url)} alt={it.caption || ""} loading="lazy" />
                      <span className="masonry__cap">
                        {it.caption}
                        {it.expo?.title ? <em> · {it.expo.title}</em> : null}
                      </span>
                    </motion.button>
                  ))}
                </Parallax>
              ))}
            </div>
          )}
        </div>
      </section>
      <AnimatePresence>
        {open && (
          <motion.div className="lightbox" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setOpen(null)} data-lenis-prevent>
            <motion.figure layoutId={`g-${open._id}`} onClick={(e) => e.stopPropagation()}>
              <img src={assetUrl(open.url)} alt={open.caption || ""} />
              <figcaption>{open.caption}</figcaption>
            </motion.figure>
            <button type="button" className="icon-btn lightbox__close" aria-label="Close" onClick={() => setOpen(null)}>
              ×
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
