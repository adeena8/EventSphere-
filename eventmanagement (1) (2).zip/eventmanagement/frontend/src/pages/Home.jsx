import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { AnimatePresence, motion, useReducedMotion, useScroll, useSpring, useTransform } from "framer-motion";
import { useFetch } from "../hooks/useFetch.js";
import { useAuth } from "../context/AuthContext.jsx";
import { Reveal, Stagger, StaggerItem, Parallax, ParallaxImage, CountUp, SplitText, Magnetic, Tilt } from "../components/motion/Motion.jsx";
import { assetUrl } from "../lib/api.js";
import { fmtRange } from "../lib/format.js";

const U = (id, w = 1600) => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=${w}&q=75`;

/* ============================== HERO ============================== */
function Hero() {
  const ref = useRef(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const p = useSpring(scrollYProgress, { stiffness: 90, damping: 24, mass: 0.4 });

  const videoScale = useTransform(p, [0, 1], [1, 1.35]);
  const videoY = useTransform(p, [0, 1], ["0%", "18%"]);
  const veil = useTransform(p, [0, 0.8], [0.35, 0.92]);
  const titleY = useTransform(p, [0, 1], ["0%", "-60%"]);
  const titleOpacity = useTransform(p, [0, 0.55], [1, 0]);
  const titleScale = useTransform(p, [0, 1], [1, 0.86]);
  const chip1 = useTransform(p, [0, 1], [0, -260]);
  const chip2 = useTransform(p, [0, 1], [0, -420]);
  const chip3 = useTransform(p, [0, 1], [0, -180]);
  const glowX = useTransform(p, [0, 1], ["20%", "80%"]);

  const [videoOk, setVideoOk] = useState(true);

  return (
    <section ref={ref} className="hero" aria-label="EventSphere introduction">
      <div className="hero__sticky">
        <motion.div className="hero__media" style={reduce ? undefined : { scale: videoScale, y: videoY }}>
          {videoOk ? (
            <video
              className="hero__video"
              autoPlay
              muted
              loop
              playsInline
              preload="auto"
              poster="/poster.jpg"
              onError={() => setVideoOk(false)}
            >
              <source src="/hero.mp4" type="video/mp4" />
            </video>
          ) : (
            <img className="hero__video" src="/poster.jpg" alt="" />
          )}
        </motion.div>
        <motion.div className="hero__veil" style={{ opacity: veil }} aria-hidden="true" />
        <motion.div className="hero__glow" style={{ left: glowX }} aria-hidden="true" />

        <motion.div className="hero__content" style={reduce ? undefined : { y: titleY, opacity: titleOpacity, scale: titleScale }}>
          <motion.p className="eyebrow" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
            Expo &amp; trade-show management
          </motion.p>
          <h1 className="hero__wordmark">
            <SplitText text="EVENTSPHERE" delay={0.2} />
          </h1>
          <motion.p className="hero__sub" initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.9, duration: 0.8 }}>
            Live floor plans, real-time schedules and a direct line between organizers, exhibitors and attendees —
            crafted for expos that people remember.
          </motion.p>
          <motion.div className="hero__actions" initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1.1, duration: 0.8 }}>
            <Magnetic>
              <Link className="btn btn--glow" to="/expos">
                Explore expos
              </Link>
            </Magnetic>
            <Link className="btn btn--ghost" to="/register?role=exhibitor">
              Become an exhibitor
            </Link>
          </motion.div>
        </motion.div>

        {!reduce && (
          <>
            <motion.div className="hero__chip hero__chip--1" style={{ y: chip1 }} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.4 }}>
              <strong>▦</strong> Interactive floor plans
            </motion.div>
            <motion.div className="hero__chip hero__chip--2" style={{ y: chip2 }} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.6 }}>
              <strong>◷</strong> Live schedule updates
            </motion.div>
            <motion.div className="hero__chip hero__chip--3" style={{ y: chip3 }} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.8 }}>
              <strong>✉</strong> Exhibitor chat
            </motion.div>
          </>
        )}

        <motion.div className="scroll-hint" style={{ opacity: titleOpacity }} aria-hidden="true">
          <span>Scroll</span>
          <i />
        </motion.div>
      </div>
    </section>
  );
}

/* ============================== MARQUEE ============================== */
function Marquee() {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const x1 = useTransform(scrollYProgress, [0, 1], ["0%", "-35%"]);
  const x2 = useTransform(scrollYProgress, [0, 1], ["-35%", "0%"]);
  const words = ["Technology", "Healthcare", "Energy", "Food & Beverage", "Robotics", "Design", "Automotive", "Fashion"];
  return (
    <section ref={ref} className="marquee" aria-hidden="true">
      <motion.div className="marquee__row" style={{ x: x1 }}>
        {[...words, ...words].map((w, i) => (
          <span key={i}>
            {w} <em>✦</em>
          </span>
        ))}
      </motion.div>
      <motion.div className="marquee__row marquee__row--outline" style={{ x: x2 }}>
        {[...words, ...words].reverse().map((w, i) => (
          <span key={i}>
            {w} <em>✦</em>
          </span>
        ))}
      </motion.div>
    </section>
  );
}

/* ============================== ROLES ============================== */
const ROLES = [
  {
    title: "Organizers",
    img: U("photo-1556761175-5973dc0f32e7", 900),
    text: "Create expos, design the floor plan, approve exhibitors, build the schedule and watch engagement in real time.",
    points: ["Booth allocation", "Session planning", "Live analytics"],
    to: "/register?role=organizer",
    speed: 0.12,
  },
  {
    title: "Exhibitors",
    img: U("photo-1511578314322-379afb476865", 900),
    text: "Apply in minutes, pick your booth on the map, showcase products and chat with organizers and neighbours.",
    points: ["Pick your booth", "Company profile", "Booth traffic stats"],
    to: "/register?role=exhibitor",
    speed: -0.08,
  },
  {
    title: "Attendees",
    img: U("photo-1515187029135-18ee286d815b", 900),
    text: "Get your QR ticket, bookmark sessions, receive reminders and find exhibitors by product or category.",
    points: ["QR tickets", "Session reminders", "Exhibitor search"],
    to: "/register",
    speed: 0.18,
  },
];

function Roles() {
  return (
    <section className="section roles" id="roles">
      <div className="section__inner">
        <Reveal className="section__head">
          <p className="eyebrow">One platform · three journeys</p>
          <h2>Built for everyone on the expo floor</h2>
          <p className="lede">Every role gets its own portal — connected by real-time updates so nobody works from an outdated plan.</p>
        </Reveal>
        <div className="roles__grid">
          {ROLES.map((r, i) => (
            <Parallax key={r.title} speed={r.speed} className="roles__col">
              <Reveal delay={i * 0.1}>
                <Tilt className="role-card" max={6}>
                  <ParallaxImage src={r.img} className="role-card__media" strength={0.12} />
                  <div className="role-card__body">
                    <span className="role-card__num">0{i + 1}</span>
                    <h3>{r.title}</h3>
                    <p>{r.text}</p>
                    <ul>
                      {r.points.map((p) => (
                        <li key={p}>{p}</li>
                      ))}
                    </ul>
                    <Link to={r.to} className="link-arrow">
                      Get started <span aria-hidden="true">→</span>
                    </Link>
                  </div>
                </Tilt>
              </Reveal>
            </Parallax>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ============================== FEATURED (horizontal parallax) ============================== */
function Featured() {
  const { data } = useFetch("/expos", { when: "upcoming", limit: 6 });
  const items = data?.items || [];
  const wrapRef = useRef(null);
  const trackRef = useRef(null);
  const [dist, setDist] = useState(0);
  const [isWide, setIsWide] = useState(() => typeof window !== "undefined" && window.innerWidth > 900);
  const reduce = useReducedMotion();

  useLayoutEffect(() => {
    const measure = () => {
      setIsWide(window.innerWidth > 900);
      if (trackRef.current) setDist(Math.max(0, trackRef.current.scrollWidth - window.innerWidth + 64));
    };
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, [items.length]);

  const { scrollYProgress } = useScroll({ target: wrapRef, offset: ["start start", "end end"] });
  const xRaw = useTransform(scrollYProgress, [0, 1], [0, -dist]);
  const x = useSpring(xRaw, { stiffness: 120, damping: 30, mass: 0.3 });
  const horizontal = isWide && !reduce && items.length > 2;

  return (
    <section
      ref={wrapRef}
      className={`featured ${horizontal ? "featured--horizontal" : ""}`}
      style={horizontal ? { height: `calc(100vh + ${dist}px)` } : undefined}
    >
      <div className="featured__sticky">
        <div className="featured__head section__inner">
          <Reveal>
            <p className="eyebrow">Live from the database</p>
            <h2>Upcoming expos</h2>
          </Reveal>
          <Link to="/expos" className="link-arrow">
            View all <span aria-hidden="true">→</span>
          </Link>
        </div>
        <motion.div ref={trackRef} className="featured__track" style={horizontal ? { x } : undefined}>
          {items.length === 0 && (
            <div className="featured__empty">
              <p>Start the backend and run <code>npm run seed</code> to see live expos here.</p>
            </div>
          )}
          {items.map((e, i) => (
            <Link key={e._id} to={`/expos/${e._id}`} className="feature-slide">
              <ParallaxImage src={assetUrl(e.banner) || U("photo-1540575467063-178a50c2df87")} className="feature-slide__media" strength={0.1} />
              <div className="feature-slide__body">
                <span className="feature-slide__num">{String(i + 1).padStart(2, "0")}</span>
                <span className="chip chip--gold">{e.category}</span>
                <h3>{e.title}</h3>
                <p>{fmtRange(e.startDate, e.endDate)} · {e.location?.city || "TBA"}</p>
                <span className="link-arrow">
                  Explore <span aria-hidden="true">→</span>
                </span>
              </div>
            </Link>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

/* ============================== PARALLAX BAND ============================== */
function Band() {
  return (
    <section className="band">
      <ParallaxImage src={U("photo-1505373877841-8d25f7d46678", 2000)} className="band__img" strength={0.22}>
        <div className="band__content">
          <Parallax speed={-0.25}>
            <p className="eyebrow">The EventSphere promise</p>
            <h2 className="band__quote">“Every booth tells a story. We make sure the right people hear it.”</h2>
          </Parallax>
        </div>
      </ParallaxImage>
    </section>
  );
}

/* ============================== FEATURES ============================== */
const FEATURES = [
  ["▦", "Floor plans & booth booking", "Visual grid of every hall. Exhibitors reserve, organizers allocate — conflicts are impossible."],
  ["◷", "Real-time schedules", "Sessions, speakers and rooms update live on every screen the moment an organizer changes them."],
  ["★", "Bookmarks & reminders", "Attendees bookmark sessions and get a notification 30 minutes before they start."],
  ["⌕", "Exhibitor search", "Filter by category, product or keyword and jump straight to the booth on the map."],
  ["✉", "Built-in messaging", "Chat with organizers, neighbouring exhibitors or the companies you want to meet."],
  ["▤", "Analytics & reports", "Registrations, check-ins, booth traffic and session popularity — streaming in live."],
  ["⌁", "QR tickets & check-in", "Every attendee gets a QR ticket; staff scan or type the code to check them in."],
  ["⛨", "Secure & private", "Encrypted passwords and personal data, role-based access, data export and deletion."],
];

function Features() {
  return (
    <section className="section features" id="features">
      <div className="section__inner">
        <Reveal className="section__head">
          <p className="eyebrow">Everything in one place</p>
          <h2>Tools that keep the whole floor in sync</h2>
        </Reveal>
        <Stagger className="features__grid" gap={0.07}>
          {FEATURES.map(([icon, title, text]) => (
            <StaggerItem key={title} className="feature">
              <span className="feature__icon" aria-hidden="true">
                {icon}
              </span>
              <h3>{title}</h3>
              <p>{text}</p>
            </StaggerItem>
          ))}
        </Stagger>
      </div>
    </section>
  );
}

/* ============================== STATS ============================== */
function Stats() {
  return (
    <section className="stats">
      <Parallax speed={0.35} className="stats__bg" aria-hidden="true">
        <span />
      </Parallax>
      <div className="section__inner stats__inner">
        {[
          [480, "+", 0, "Expos managed"],
          [12, "K+", 0, "Exhibitors connected"],
          [1.2, "M+", 1, "Attendees checked in"],
          [99.9, "%", 1, "Platform uptime"],
        ].map(([v, s, d, label], i) => (
          <Reveal key={label} delay={i * 0.08} className="stat">
            <span className="stat__value">
              <CountUp to={v} suffix={s} decimals={d} />
            </span>
            <span className="stat__label">{label}</span>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

/* ============================== STEPS (scroll-drawn timeline) ============================== */
const STEPS = [
  ["Create", "Organizers publish an expo with dates, venue, theme and an auto-generated booth grid.", U("photo-1454165804606-c3d57bc86b40", 800)],
  ["Apply", "Exhibitors submit company details & documents and reserve their preferred booth.", U("photo-1556761175-b413da4baf72", 800)],
  ["Schedule", "Sessions, speakers and rooms go live — attendees register, bookmark and get reminders.", U("photo-1475721027785-f74eccf877e2", 800)],
  ["Connect", "On the day: QR check-in, booth visits, chat and live analytics for everyone.", U("photo-1531058020387-3be344556be6", 800)],
];

function Steps() {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start 75%", "end 60%"] });
  const line = useSpring(scrollYProgress, { stiffness: 100, damping: 25 });
  return (
    <section className="section steps" ref={ref}>
      <div className="section__inner">
        <Reveal className="section__head">
          <p className="eyebrow">How it works</p>
          <h2>From first idea to a full hall</h2>
        </Reveal>
        <div className="steps__list">
          <motion.span className="steps__line" style={{ scaleY: line }} aria-hidden="true" />
          {STEPS.map(([t, d, img], i) => (
            <div key={t} className={`step ${i % 2 ? "step--right" : ""}`}>
              <Reveal x={i % 2 ? 50 : -50} y={0} className="step__card">
                <span className="step__index">0{i + 1}</span>
                <h3>{t}</h3>
                <p>{d}</p>
              </Reveal>
              <Parallax speed={0.15 * (i % 2 ? 1 : -1)} className="step__media">
                <ParallaxImage src={img} strength={0.1} />
              </Parallax>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ============================== TESTIMONIALS ============================== */
const QUOTES = [
  ["Booth allocation used to take us two weeks of spreadsheets. With EventSphere it took an afternoon.", "Maya Chen", "Expo Director, Global Tech Expo"],
  ["We found our two biggest clients through the in-app chat — they messaged us before the doors even opened.", "Usman Tariq", "Founder, GreenLeaf Energy"],
  ["The session reminders are magic. I didn't miss a single keynote I'd bookmarked.", "Sara Khan", "Attendee"],
];

function Testimonials() {
  const [i, setI] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setI((x) => (x + 1) % QUOTES.length), 6500);
    return () => clearInterval(t);
  }, []);
  const [q, who, role] = QUOTES[i];
  return (
    <section className="section testimonials">
      <div className="section__inner">
        <Reveal className="section__head">
          <p className="eyebrow">Stories from the floor</p>
          <h2>What it felt like</h2>
        </Reveal>
        <div className="quote-wrap">
          <AnimatePresence mode="wait">
            <motion.blockquote
              key={i}
              className="quote"
              initial={{ opacity: 0, y: 24, filter: "blur(6px)" }}
              animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
              exit={{ opacity: 0, y: -20, filter: "blur(6px)" }}
              transition={{ duration: 0.6 }}
            >
              <p>“{q}”</p>
              <footer>
                <cite>{who}</cite>
                <span>{role}</span>
              </footer>
            </motion.blockquote>
          </AnimatePresence>
          <div className="quote-dots" role="tablist" aria-label="Testimonials">
            {QUOTES.map((_, k) => (
              <button key={k} type="button" aria-label={`Testimonial ${k + 1}`} aria-selected={k === i} className={k === i ? "is-active" : ""} onClick={() => setI(k)} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ============================== CTA ============================== */
function Cta() {
  const { user } = useAuth();
  return (
    <section className="cta">
      <Parallax speed={0.5} className="cta__orb cta__orb--a" aria-hidden="true">
        <span />
      </Parallax>
      <Parallax speed={-0.4} className="cta__orb cta__orb--b" aria-hidden="true">
        <span />
      </Parallax>
      <Reveal className="cta__inner">
        <p className="eyebrow">Your next expo starts here</p>
        <h2>Ready to fill the hall?</h2>
        <p className="lede">Create a free account and be part of the next show — as an organizer, exhibitor or attendee.</p>
        <div className="hero__actions">
          <Magnetic>
            <Link to={user ? "/dashboard" : "/register"} className="btn btn--glow">
              {user ? "Go to dashboard" : "Create free account"}
            </Link>
          </Magnetic>
          <Link to="/contact" className="btn btn--ghost">
            Talk to us
          </Link>
        </div>
      </Reveal>
    </section>
  );
}

export default function Home() {
  return (
    <div className="home">
      <Hero />
      <Marquee />
      <Roles />
      <Featured />
      <Band />
      <Features />
      <Stats />
      <Steps />
      <Testimonials />
      <Cta />
    </div>
  );
}
