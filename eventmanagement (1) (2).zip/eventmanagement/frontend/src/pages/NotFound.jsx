import { Link } from "react-router-dom";
import { SplitText } from "../components/motion/Motion.jsx";

export default function NotFound() {
  return (
    <section className="notfound">
      <h1>
        <SplitText text="404" />
      </h1>
      <p>This hall is empty — the page you're looking for doesn't exist.</p>
      <Link to="/" className="btn btn--glow">
        Back to the entrance
      </Link>
    </section>
  );
}
