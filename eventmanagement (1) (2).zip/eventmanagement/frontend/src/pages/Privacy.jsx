import { Link } from "react-router-dom";
import PageHero from "../components/PageHero.jsx";

export default function Privacy() {
  return (
    <>
      <PageHero eyebrow="Legal" title="Privacy policy" small />
      <section className="section section--tight">
        <div className="section__inner prose-page">
          <p className="muted">Last updated: {new Date().getFullYear()}</p>
          <h2>What we collect</h2>
          <p>Account details (name, email, role), optional phone number, company profile for exhibitors, and activity needed to run the service — expo registrations, session reservations, messages and booth visits.</p>
          <h2>How we protect it</h2>
          <ul>
            <li>Passwords are hashed with bcrypt and never stored in plain text.</li>
            <li>Phone numbers are encrypted at rest with AES-256-GCM.</li>
            <li>All traffic is encrypted with HTTPS in production.</li>
            <li>Role-based access control: you can only see your own private data.</li>
            <li>Automated daily backups protect against data loss.</li>
          </ul>
          <h2>Your choices (GDPR)</h2>
          <ul>
            <li><strong>Consent</strong> — recorded when you sign up; marketing emails are opt-in.</li>
            <li><strong>Visibility</strong> — hide your exhibitor profile or block new messages at any time.</li>
            <li><strong>Access &amp; portability</strong> — download all your data as JSON.</li>
            <li><strong>Erasure</strong> — delete your account and personal data permanently.</li>
          </ul>
          <p>
            Manage all of this in <Link to="/dashboard/profile">Account &amp; privacy</Link>, or <Link to="/contact">contact us</Link>.
          </p>
        </div>
      </section>
    </>
  );
}
