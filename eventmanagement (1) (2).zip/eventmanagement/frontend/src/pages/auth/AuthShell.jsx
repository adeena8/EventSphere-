import { motion } from "framer-motion";
import { ParallaxImage } from "../../components/motion/Motion.jsx";

export default function AuthShell({ title, subtitle, image, children }) {
  return (
    <section className="auth">
      <div className="auth__visual">
        <ParallaxImage
          src={image || "https://images.unsplash.com/photo-1505373877841-8d25f7d46678?auto=format&fit=crop&w=1400&q=70"}
          strength={0.08}
        >
          <motion.blockquote className="auth__quote" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
            “The floor plan, the schedule and every conversation — in one place.”
          </motion.blockquote>
        </ParallaxImage>
      </div>
      <motion.div className="auth__panel" initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}>
        <h1>{title}</h1>
        {subtitle && <p className="lede">{subtitle}</p>}
        {children}
      </motion.div>
    </section>
  );
}
