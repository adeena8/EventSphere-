import { useState } from "react";
import { Link } from "react-router-dom";
import AuthShell from "./AuthShell.jsx";
import { Field, ErrorBox } from "../../components/ui/UI.jsx";
import { api } from "../../lib/api.js";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const [result, setResult] = useState(null);

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      setResult(await api.post("/auth/forgot-password", { email }));
    } catch (err) {
      setError(err);
    } finally {
      setBusy(false);
    }
  }

  return (
    <AuthShell title="Forgot your password?" subtitle="Enter your email and we'll send you a reset link.">
      {result ? (
        <div className="stack">
          <div className="alert alert--success">{result.message}</div>
          {result.devResetUrl && (
            <div className="alert">
              <span>
                <strong>Development mode:</strong> no SMTP configured, so here's your link:{" "}
                <Link to={new URL(result.devResetUrl).pathname}>reset password</Link>
              </span>
            </div>
          )}
          <Link to="/login" className="btn btn--ghost">
            Back to login
          </Link>
        </div>
      ) : (
        <form className="stack" onSubmit={submit}>
          <Field label="Email">
            <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
          </Field>
          <ErrorBox error={error} />
          <button type="submit" className="btn btn--gold btn--block" disabled={busy}>
            {busy ? "Sending…" : "Send reset link"}
          </button>
          <Link to="/login" className="muted">
            ← Back to login
          </Link>
        </form>
      )}
    </AuthShell>
  );
}
