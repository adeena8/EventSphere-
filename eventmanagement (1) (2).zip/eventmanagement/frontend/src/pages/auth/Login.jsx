import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import AuthShell from "./AuthShell.jsx";
import { Field, ErrorBox } from "../../components/ui/UI.jsx";
import { useAuth } from "../../context/AuthContext.jsx";
import { useToast } from "../../context/ToastContext.jsx";

const DEMO = [
  ["Admin", "admin@eventsphere.com", "Admin@123"],
  ["Organizer", "organizer@eventsphere.com", "Organizer@123"],
  ["Exhibitor", "techvision@eventsphere.com", "Exhibitor@123"],
  ["Attendee", "ali@eventsphere.com", "Attendee@123"],
];

export default function Login() {
  const { login } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const { user } = await login(email, password);
      toast.success(`Welcome back, ${user.name.split(" ")[0]}!`);
      navigate(location.state?.from || "/dashboard", { replace: true });
    } catch (err) {
      setError(err);
    } finally {
      setBusy(false);
    }
  }

  return (
    <AuthShell title="Welcome back" subtitle="Log in to manage expos, booths and your schedule.">
      <form className="stack" onSubmit={submit}>
        <Field label="Email">
          <input type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} />
        </Field>
        <Field label="Password">
          <div className="input-addon">
            <input type={show ? "text" : "password"} required autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} />
            <button type="button" className="input-addon__btn" onClick={() => setShow((s) => !s)} aria-label={show ? "Hide password" : "Show password"}>
              {show ? "Hide" : "Show"}
            </button>
          </div>
        </Field>
        <div className="row-between">
          <Link to="/forgot-password" className="muted">
            Forgot password?
          </Link>
        </div>
        <ErrorBox error={error} />
        <button type="submit" className="btn btn--gold btn--block" disabled={busy}>
          {busy ? "Signing in…" : "Log in"}
        </button>
      </form>
      <p className="muted mt-sm">
        New here? <Link to="/register">Create an account</Link>
      </p>
      <div className="demo">
        <p className="eyebrow">Demo accounts (after npm run seed)</p>
        <div className="demo__grid">
          {DEMO.map(([r, e, p]) => (
            <button
              key={r}
              type="button"
              className="chip chip--btn"
              onClick={() => {
                setEmail(e);
                setPassword(p);
              }}
            >
              {r}
            </button>
          ))}
        </div>
      </div>
    </AuthShell>
  );
}
