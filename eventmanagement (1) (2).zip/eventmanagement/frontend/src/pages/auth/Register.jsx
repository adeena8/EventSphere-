import { useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { motion } from "framer-motion";
import AuthShell from "./AuthShell.jsx";
import { Field, ErrorBox } from "../../components/ui/UI.jsx";
import { useAuth } from "../../context/AuthContext.jsx";
import { useToast } from "../../context/ToastContext.jsx";

const ROLES = [
  ["attendee", "Attendee", "Visit expos, book sessions"],
  ["exhibitor", "Exhibitor", "Showcase your company"],
  ["organizer", "Organizer", "Run expos (needs approval)"],
];

function strength(pw) {
  let s = 0;
  if (pw.length >= 8) s++;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) s++;
  if (/\d/.test(pw)) s++;
  if (/[^A-Za-z0-9]/.test(pw)) s++;
  return s;
}

export default function Register() {
  const [params] = useSearchParams();
  const { register } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const [form, setForm] = useState({
    role: ROLES.some(([r]) => r === params.get("role")) ? params.get("role") : "attendee",
    name: "",
    email: "",
    password: "",
    phone: "",
    companyName: "",
    consent: false,
    marketingEmails: false,
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const [pending, setPending] = useState(null);
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value }));
  const pw = strength(form.password);

  async function submit(e) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      const res = await register(form);
      if (res.pending) {
        setPending(res.message);
        return;
      }
      toast.success("Account created — welcome to EventSphere!");
      navigate(form.role === "exhibitor" ? "/dashboard/company" : "/dashboard", { replace: true });
    } catch (err) {
      setError(err);
    } finally {
      setBusy(false);
    }
  }

  if (pending) {
    return (
      <AuthShell title="Almost there" subtitle={pending}>
        <Link to="/" className="btn btn--ghost">
          Back to home
        </Link>
      </AuthShell>
    );
  }

  return (
    <AuthShell title="Create your account" subtitle="Choose how you'll take part.">
      <form className="stack" onSubmit={submit}>
        <div className="role-pick" role="radiogroup" aria-label="Account type">
          {ROLES.map(([value, label, hint]) => (
            <label key={value} className={`role-pick__opt ${form.role === value ? "is-active" : ""}`}>
              <input type="radio" name="role" value={value} checked={form.role === value} onChange={set("role")} />
              <strong>{label}</strong>
              <span>{hint}</span>
              {form.role === value && <motion.i layoutId="role-ink" className="role-pick__ink" />}
            </label>
          ))}
        </div>
        <Field label="Full name">
          <input required value={form.name} onChange={set("name")} autoComplete="name" />
        </Field>
        {form.role === "exhibitor" && (
          <Field label="Company name">
            <input required value={form.companyName} onChange={set("companyName")} autoComplete="organization" />
          </Field>
        )}
        <Field label="Email">
          <input type="email" required value={form.email} onChange={set("email")} autoComplete="email" />
        </Field>
        <Field label="Phone (optional, stored encrypted)">
          <input type="tel" value={form.phone} onChange={set("phone")} autoComplete="tel" />
        </Field>
        <Field label="Password" hint="At least 8 characters with letters and numbers">
          <input type="password" required minLength={8} value={form.password} onChange={set("password")} autoComplete="new-password" />
        </Field>
        <div className="pw-meter" aria-hidden="true">
          {[0, 1, 2, 3].map((i) => (
            <span key={i} className={i < pw ? `on s${pw}` : ""} />
          ))}
        </div>
        <label className="check">
          <input type="checkbox" checked={form.consent} onChange={set("consent")} required />
          <span>
            I agree to the <Link to="/privacy" target="_blank">privacy policy</Link> and consent to my data being processed to provide the service.
          </span>
        </label>
        <label className="check">
          <input type="checkbox" checked={form.marketingEmails} onChange={set("marketingEmails")} />
          <span>Send me occasional emails about new expos (optional)</span>
        </label>
        <ErrorBox error={error} />
        <button type="submit" className="btn btn--gold btn--block" disabled={busy}>
          {busy ? "Creating account…" : "Create account"}
        </button>
      </form>
      <p className="muted mt-sm">
        Already have an account? <Link to="/login">Log in</Link>
      </p>
    </AuthShell>
  );
}
