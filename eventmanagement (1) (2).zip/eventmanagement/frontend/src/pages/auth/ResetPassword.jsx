import { useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import AuthShell from "./AuthShell.jsx";
import { Field, ErrorBox } from "../../components/ui/UI.jsx";
import { api } from "../../lib/api.js";
import { useAuth } from "../../context/AuthContext.jsx";
import { useToast } from "../../context/ToastContext.jsx";

export default function ResetPassword() {
  const { token } = useParams();
  const { applySession } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);

  async function submit(e) {
    e.preventDefault();
    if (password !== confirm) return setError(new Error("Passwords don't match"));
    setBusy(true);
    setError(null);
    try {
      applySession(await api.post(`/auth/reset-password/${token}`, { password }));
      toast.success("Password updated — you're logged in.");
      navigate("/dashboard", { replace: true });
    } catch (err) {
      setError(err);
    } finally {
      setBusy(false);
    }
  }

  return (
    <AuthShell title="Choose a new password">
      <form className="stack" onSubmit={submit}>
        <Field label="New password" hint="At least 8 characters with letters and numbers">
          <input type="password" required minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="new-password" />
        </Field>
        <Field label="Confirm password">
          <input type="password" required value={confirm} onChange={(e) => setConfirm(e.target.value)} autoComplete="new-password" />
        </Field>
        <ErrorBox error={error} />
        <button type="submit" className="btn btn--gold btn--block" disabled={busy}>
          {busy ? "Saving…" : "Update password"}
        </button>
        <Link to="/forgot-password" className="muted">
          Link expired? Request a new one
        </Link>
      </form>
    </AuthShell>
  );
}
