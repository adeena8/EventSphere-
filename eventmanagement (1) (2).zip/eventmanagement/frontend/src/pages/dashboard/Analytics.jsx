import { useState } from "react";
import { Link } from "react-router-dom";
import { PageHead, Spinner, ErrorBox, StatCard, Badge } from "../../components/ui/UI.jsx";
import { BarChart, HBars, Donut, Ring } from "../../components/ui/Charts.jsx";
import { useFetch } from "../../hooks/useFetch.js";
import { useSocketEvent } from "../../context/SocketContext.jsx";
import { useManagedExpos, ExpoPicker } from "./shared.jsx";
import { fmtDate, fmtDateTime } from "../../lib/format.js";

/** Staff analytics: attendee engagement, booth traffic, session popularity — refreshes live */
export function AnalyticsBoard({ compact = false }) {
  const expos = useManagedExpos();
  const [expo, setExpo] = useState("");
  const { data, loading, error, reload } = useFetch("/analytics/overview", { expo });
  const [pulse, setPulse] = useState(0);

  useSocketEvent("analytics:update", (p) => {
    if (!expo || String(p.expoId) === expo) {
      reload();
      setPulse((x) => x + 1);
    }
  });
  useSocketEvent("booths:updated", () => reload());
  useSocketEvent("schedule:updated", () => reload());

  if (loading && !data) return <Spinner />;
  if (error) return <ErrorBox error={error} onRetry={reload} />;
  const t = data.totals;

  return (
    <div className="stack-lg">
      <div className="toolbar">
        <ExpoPicker expos={expos.data?.items || []} value={expo} onChange={setExpo} allowAll />
        <span className="muted live-note" key={pulse}>
          <i className="live-dot is-on" /> Live · updated {fmtDateTime(data.generatedAt)}
        </span>
      </div>

      <div className="stat-grid">
        <StatCard label="Registered attendees" value={t.attendees} hint={`${t.checkedIn} checked in`} icon="☺" />
        <StatCard label="Exhibitors" value={t.exhibitors} hint={`${t.pendingApplications} applications pending`} icon="❖" tone="teal" />
        <StatCard label="Booth occupancy" value={`${t.occupancy}%`} hint={`${t.booths - t.boothsAvailable}/${t.booths} booths taken`} icon="▦" />
        <StatCard label="Booth visits" value={t.boothVisits} hint="profile & floor-plan views" icon="⌖" tone="wine" />
        {!compact && (
          <>
            <StatCard label="Sessions" value={t.sessions} hint={`${t.sessionSeats} seats reserved`} icon="◷" tone="teal" />
            <StatCard label="Avg sessions / attendee" value={t.avgSessionsPerAttendee} icon="★" />
            <StatCard label="Avg rating" value={t.avgRating ?? "—"} hint={`${t.ratings} ratings`} icon="✦" tone="wine" />
            <StatCard label="Online now" value={t.onlineNow} hint="connected users" icon="●" tone="teal" />
          </>
        )}
      </div>

      <div className="grid grid--2">
        <div className="panel">
          <h3>Registrations · last 30 days</h3>
          <BarChart
            data={data.registrationsByDay.map((d) => ({ label: fmtDate(d.date), short: d.date.slice(8), value: d.value }))}
            labelEvery={5}
          />
        </div>
        <div className="panel">
          <h3>Booth traffic · last 14 days</h3>
          <BarChart
            color="#7a8f7a"
            data={data.visitsByDay.map((d) => ({ label: fmtDate(d.date), short: d.date.slice(8), value: d.value }))}
            labelEvery={2}
          />
        </div>
      </div>

      <div className="grid grid--3">
        <div className="panel">
          <h3>Engagement</h3>
          <div className="rings">
            <Ring value={t.checkInRate} label="Check-in rate" />
            <Ring value={t.occupancy} label="Occupancy" />
          </div>
        </div>
        <div className="panel">
          <h3>Applications</h3>
          <Donut
            data={["approved", "pending", "rejected", "withdrawn"]
              .map((k) => ({ label: k, value: data.applications[k] || 0 }))
              .filter((d) => d.value > 0)}
            center={Object.values(data.applications).reduce((a, b) => a + b, 0)}
          />
        </div>
        <div className="panel">
          <h3>Session formats</h3>
          <Donut data={data.sessionTypes} center={t.sessions} />
        </div>
      </div>

      {!compact && (
        <div className="grid grid--2">
          <div className="panel">
            <h3>Most popular sessions</h3>
            {data.topSessions.length ? (
              <HBars
                data={data.topSessions.map((s) => ({
                  label: s.title,
                  value: s.registered,
                  sub: `${s.bookmarks} bookmarks · ${s.expoTitle || ""}${s.capacity ? ` · cap ${s.capacity}` : ""}`,
                }))}
                format={(v) => `${v} seats`}
              />
            ) : (
              <p className="muted">No sessions yet.</p>
            )}
          </div>
          <div className="panel">
            <h3>Top booths by traffic</h3>
            {data.boothTraffic.length ? (
              <HBars
                data={data.boothTraffic.map((b) => ({ label: `${b.code} · ${b.company || "—"}`, value: b.visits, sub: `${b.uniqueVisitors} unique visitors · ${b.hall}` }))}
                format={(v) => `${v} visits`}
              />
            ) : (
              <p className="muted">No booth visits recorded yet.</p>
            )}
          </div>
        </div>
      )}

      <div className="panel">
        <h3>Expo performance report</h3>
        <div className="table-wrap" data-lenis-prevent>
          <table className="table">
            <thead>
              <tr>
                <th>Expo</th>
                <th>Status</th>
                <th>Starts</th>
                <th>Attendees</th>
                <th>Checked in</th>
                <th>Booths</th>
                <th>Occupancy</th>
              </tr>
            </thead>
            <tbody>
              {data.perExpo.map((e) => (
                <tr key={e._id}>
                  <td>
                    <Link to={`/expos/${e._id}`}>{e.title}</Link>
                  </td>
                  <td>
                    <Badge>{e.status}</Badge>
                  </td>
                  <td>{fmtDate(e.startDate)}</td>
                  <td>{e.attendees}</td>
                  <td>{e.checkedIn}</td>
                  <td>
                    {e.occupied}/{e.booths}
                  </td>
                  <td>
                    <div className="mini-bar">
                      <span style={{ width: `${e.occupancy}%` }} />
                    </div>
                    {e.occupancy}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <button type="button" className="btn btn--ghost btn--sm mt-sm" onClick={() => exportCsv(data.perExpo)}>
          ⤓ Export CSV
        </button>
      </div>
    </div>
  );
}

function exportCsv(rows) {
  const head = ["Expo", "Status", "Start", "Attendees", "Checked in", "Booths", "Occupied", "Occupancy %"];
  const lines = rows.map((r) => [r.title, r.status, fmtDate(r.startDate), r.attendees, r.checkedIn, r.booths, r.occupied, r.occupancy]);
  const csv = [head, ...lines].map((l) => l.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(",")).join("\n");
  const url = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = `eventsphere-report-${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

export default function Analytics() {
  return (
    <>
      <PageHead eyebrow="Reports" title="Analytics">
        Attendee engagement, booth traffic and session popularity — updated in real time.
      </PageHead>
      <AnalyticsBoard />
    </>
  );
}
