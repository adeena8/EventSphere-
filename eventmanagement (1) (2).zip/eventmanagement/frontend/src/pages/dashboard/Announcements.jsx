import { useState } from "react";
import { PageHead, Field, ErrorBox } from "../../components/ui/UI.jsx";
import { useAuth } from "../../context/AuthContext.jsx";
import { useToast } from "../../context/ToastContext.jsx";
import { useManagedExpos } from "./shared.jsx";
import { api } from "../../lib/api.js";

export default function Announcements() {
  const { user } = useAuth();
  const toast = useToast();
  const expos = useManagedExpos();
  const [f, setF] = useState({ audience: "expo", expo: "", title: "", body: "" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const set = (k) => (e) => setF((x) => ({ ...x, [k]: e.target.value }));

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const r = await api.post("/notifications/broadcast", f);
      toast.success(`Announcement delivered to ${r.sent} people`);
      setF((x) => ({ ...x, title: "", body: "" }));
    } catch (err) {
      setError(err);
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <PageHead eyebrow="Communication" title="Announcements">
        Push a real-time notification to attendees and exhibitors — e.g. venue changes, parking info, reminders.
      </PageHead>
      <form className="panel form-grid" onSubmit={submit}>
        <Field label="Audience">
          <select value={f.audience} onChange={set("audience")}>
            <option value="expo">Everyone at one expo</option>
            <option value="attendee">All attendees</option>
            <option value="exhibitor">All exhibitors</option>
            {user.role === "admin" && <option value="organizer">All organizers</option>}
            {user.role === "admin" && <option value="all">Everyone</option>}
          </select>
        </Field>
        {f.audience === "expo" && (
          <Field label="Expo">
            <select required value={f.expo} onChange={set("expo")}>
              <option value="">Select…</option>
              {(expos.data?.items || []).map((e) => <option key={e._id} value={e._id}>{e.title}</option>)}
            </select>
          </Field>
        )}
        <Field label="Title" full><input required maxLength={120} value={f.title} onChange={set("title")} /></Field>
        <Field label="Message" full><textarea required rows={4} maxLength={1000} value={f.body} onChange={set("body")} /></Field>
        <ErrorBox error={error} />
        <div className="form-actions field--full">
          <button type="submit" className="btn btn--gold" disabled={busy}>{busy ? "Sending…" : "📣 Send announcement"}</button>
        </div>
      </form>
    </>
  );
}
