import { useState } from "react";
import { Link } from "react-router-dom";
import { PageHead, Spinner, Empty, Badge, Modal, Field, ErrorBox, Avatar } from "../../components/ui/UI.jsx";
import FloorPlan from "../../components/FloorPlan.jsx";
import ApplyModal from "../../components/ApplyModal.jsx";
import { ExpoCard } from "../../components/Cards.jsx";
import { useFetch } from "../../hooks/useFetch.js";
import { useAuth } from "../../context/AuthContext.jsx";
import { useToast } from "../../context/ToastContext.jsx";
import { useSocketEvent } from "../../context/SocketContext.jsx";
import { api, assetUrl } from "../../lib/api.js";
import { fmtDate, fmtRange, timeAgo } from "../../lib/format.js";
import { useManagedExpos, ExpoPicker } from "./shared.jsx";

export default function Applications() {
  const { user } = useAuth();
  return user.role === "exhibitor" ? <ExhibitorApplications /> : <ReviewApplications />;
}

/* ============================== Exhibitor view ============================== */
function ExhibitorApplications() {
  const { data, loading, reload } = useFetch("/applications/mine");
  const open = useFetch("/expos", { when: "upcoming", limit: 12 });
  const [applyTo, setApplyTo] = useState(null);
  const toast = useToast();
  useSocketEvent("notification:new", (n) => n.type === "application" && reload());

  const items = data?.items || [];
  const appliedIds = new Set(items.filter((a) => ["pending", "approved"].includes(a.status)).map((a) => String(a.expo?._id)));
  const available = (open.data?.items || []).filter((e) => !appliedIds.has(String(e._id)));

  async function withdraw(a) {
    if (!window.confirm("Withdraw this application? Your reserved booth will be released.")) return;
    try {
      await api.del(`/applications/${a._id}`);
      toast.info("Application withdrawn");
      reload();
    } catch (e) {
      toast.error(e.message);
    }
  }

  return (
    <>
      <PageHead eyebrow="Exhibitor portal" title="Applications">
        Apply to expos, reserve your preferred booth and follow the organizer's decision.
      </PageHead>
      {loading && !data ? (
        <Spinner />
      ) : items.length ? (
        <div className="cards-list">
          {items.map((a) => (
            <article key={a._id} className="app-card">
              <div className="app-card__main">
                <div className="row-gap">
                  <Badge>{a.status}</Badge>
                  <span className="muted">applied {timeAgo(a.createdAt)}</span>
                </div>
                <h3>{a.expo?.title}</h3>
                <p className="muted">{fmtRange(a.expo?.startDate, a.expo?.endDate)} · {a.expo?.location?.city}</p>
                <p>
                  {a.assignedBooth ? (
                    <>Assigned booth <strong className="gold">{a.assignedBooth.code}</strong> ({a.assignedBooth.hall})</>
                  ) : a.preferredBooth ? (
                    <>Requested booth <strong>{a.preferredBooth.code}</strong> — held while under review</>
                  ) : (
                    "No booth requested — the organizer will allocate one"
                  )}
                </p>
                {a.reviewNote && <p className="note">Organizer note: {a.reviewNote}</p>}
              </div>
              <div className="app-card__actions">
                <Link to={`/expos/${a.expo?._id}`} className="btn btn--ghost btn--sm">View expo</Link>
                {a.status === "approved" && <Link to="/dashboard/booths" className="btn btn--gold btn--sm">Manage booth</Link>}
                {a.status === "pending" && (
                  <button type="button" className="btn btn--plain btn--sm" onClick={() => withdraw(a)}>Withdraw</button>
                )}
              </div>
            </article>
          ))}
        </div>
      ) : (
        <Empty title="No applications yet" icon="✎">Choose an expo below to apply.</Empty>
      )}

      <h2 className="mt">Open for applications</h2>
      <div className="grid grid--3">
        {available.map((e) => (
          <div key={e._id} className="stack-sm">
            <ExpoCard expo={e} />
            <button type="button" className="btn btn--gold btn--sm" onClick={() => setApplyTo(e)}>Apply to exhibit</button>
          </div>
        ))}
        {!available.length && !open.loading && <p className="muted">You've applied to every upcoming expo 🎉</p>}
      </div>
      <ApplyModal expo={applyTo} open={!!applyTo} onClose={() => setApplyTo(null)} onDone={reload} />
    </>
  );
}

/* ============================== Organizer/admin review ============================== */
function ReviewApplications() {
  const expos = useManagedExpos();
  const [expo, setExpo] = useState("");
  const [status, setStatus] = useState("pending");
  const { data, loading, error, reload } = useFetch("/applications", { expo, status });
  const [reviewing, setReviewing] = useState(null);
  useSocketEvent("applications:updated", () => reload());

  const items = data?.items || [];
  return (
    <>
      <PageHead eyebrow="Exhibitor management" title="Exhibitor applications">
        Review company details and documents, approve or reject, and assign booths.
      </PageHead>
      <div className="toolbar">
        <ExpoPicker expos={expos.data?.items || []} value={expo} onChange={setExpo} allowAll />
        <div className="seg">
          {["pending", "approved", "rejected", ""].map((s) => (
            <button key={s || "all"} type="button" className={status === s ? "is-active" : ""} onClick={() => setStatus(s)}>
              {s || "All"}
            </button>
          ))}
        </div>
      </div>
      <ErrorBox error={error} onRetry={reload} />
      {loading && !data ? (
        <Spinner />
      ) : !items.length ? (
        <Empty title={`No ${status || ""} applications`} icon="✎" />
      ) : (
        <div className="cards-list">
          {items.map((a) => (
            <article key={a._id} className="app-card">
              <div className="app-card__main">
                <div className="speaker">
                  <Avatar src={a.exhibitor?.company?.logo} name={a.companyName} size={46} />
                  <div>
                    <strong>{a.companyName}</strong>
                    <span>{a.category} · {a.exhibitor?.email}</span>
                  </div>
                  <Badge>{a.status}</Badge>
                </div>
                <p className="muted mt-sm">
                  {a.expo?.title} · applied {fmtDate(a.createdAt)}
                  {a.preferredBooth && <> · wants booth <strong className="gold">{a.preferredBooth.code}</strong></>}
                  {a.assignedBooth && <> · assigned <strong className="gold">{a.assignedBooth.code}</strong></>}
                </p>
                {a.description && <p>{a.description}</p>}
                {a.products?.length > 0 && (
                  <ul className="tags">{a.products.map((p) => <li key={p}>{p}</li>)}</ul>
                )}
                {a.documents?.length > 0 && (
                  <p className="docs">
                    📎 {a.documents.map((d) => (
                      <a key={d.url} href={assetUrl(d.url)} target="_blank" rel="noreferrer">{d.name}</a>
                    ))}
                  </p>
                )}
              </div>
              <div className="app-card__actions">
                {a.status === "pending" ? (
                  <button type="button" className="btn btn--gold btn--sm" onClick={() => setReviewing(a)}>Review</button>
                ) : (
                  <button type="button" className="btn btn--ghost btn--sm" onClick={() => setReviewing(a)}>Change decision</button>
                )}
                <Link to={`/dashboard/messages/${a.exhibitor?._id}`} className="btn btn--plain btn--sm">Message</Link>
              </div>
            </article>
          ))}
        </div>
      )}
      <ReviewModal app={reviewing} onClose={() => setReviewing(null)} onDone={() => { setReviewing(null); reload(); }} />
    </>
  );
}

function ReviewModal({ app, onClose, onDone }) {
  const toast = useToast();
  const plan = useFetch(app ? `/expos/${app.expo._id}/booths` : null);
  const [booth, setBooth] = useState(null);
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);

  const preferred = app?.preferredBooth?._id;
  const chosen = booth?._id || preferred;

  async function decide(status) {
    setBusy(true);
    setError(null);
    try {
      await api.patch(`/applications/${app._id}/status`, { status, note, boothId: status === "approved" ? chosen : undefined });
      toast.success(`Application ${status} — exhibitor notified`);
      setBooth(null);
      setNote("");
      onDone();
    } catch (e) {
      setError(e);
    } finally {
      setBusy(false);
    }
  }

  // allow selecting available booths + the booth reserved by this applicant
  const booths = (plan.data?.booths || []).map((b) => (b._id === preferred && b.status === "reserved" ? { ...b, status: "available" } : b));

  return (
    <Modal open={!!app} onClose={onClose} title={app ? `Review: ${app.companyName}` : ""} wide>
      {app && (
        <div className="stack">
          <p className="muted">
            Choose a booth (optional) — {preferred ? `requested ${app.preferredBooth.code}` : "no preference given"}.
            {chosen && <> Selected: <strong className="gold">{booths.find((b) => b._id === chosen)?.code}</strong></>}
          </p>
          {plan.data ? <FloorPlan floorPlan={plan.data.floorPlan} booths={booths} mode="select" selectedId={chosen} onSelect={setBooth} compact /> : <Spinner />}
          <Field label="Note to exhibitor (optional)">
            <textarea rows={2} value={note} onChange={(e) => setNote(e.target.value)} />
          </Field>
          <ErrorBox error={error} />
          <div className="form-actions">
            <button type="button" className="btn btn--danger" disabled={busy} onClick={() => decide("rejected")}>Reject</button>
            <button type="button" className="btn btn--gold" disabled={busy} onClick={() => decide("approved")}>
              Approve{chosen ? " & assign booth" : ""}
            </button>
          </div>
        </div>
      )}
    </Modal>
  );
}
