import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { PageHead, Spinner, Empty, Badge, ErrorBox } from "../../components/ui/UI.jsx";
import { useManagedExpos, useSelectedExpo, ExpoPicker } from "./shared.jsx";
import { useFetch, useDebounced } from "../../hooks/useFetch.js";
import { useToast } from "../../context/ToastContext.jsx";
import { api } from "../../lib/api.js";
import { fmtDateTime } from "../../lib/format.js";

export default function CheckIn() {
  const expos = useManagedExpos();
  const [expoId, setExpoId] = useSelectedExpo(expos.data?.items);
  const regs = useFetch(expoId ? `/expos/${expoId}/registrations` : null);
  const [code, setCode] = useState("");
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [q, setQ] = useState("");
  const dq = useDebounced(q, 200).toLowerCase();
  const toast = useToast();

  async function submit(e, ticketCode = code) {
    e?.preventDefault();
    setError(null);
    setResult(null);
    try {
      const r = await api.post("/registrations/check-in", { ticketCode });
      setResult(r);
      setCode("");
      if (!r.already) toast.success(r.message);
      regs.reload();
    } catch (err) {
      setError(err);
    }
  }

  const items = (regs.data?.items || []).filter(
    (r) => !dq || r.attendee?.name?.toLowerCase().includes(dq) || r.attendee?.email?.toLowerCase().includes(dq) || r.ticketCode.toLowerCase().includes(dq)
  );
  const confirmed = (regs.data?.items || []).filter((r) => r.status === "confirmed");
  const checked = confirmed.filter((r) => r.checkedIn).length;

  return (
    <>
      <PageHead eyebrow="Event day" title="Check-in & tickets">
        Type or scan the code printed under an attendee's QR ticket.
      </PageHead>
      <div className="toolbar">
        <ExpoPicker expos={expos.data?.items || []} value={expoId} onChange={setExpoId} />
        <span className="chip chip--gold">{checked} / {confirmed.length} checked in</span>
      </div>
      <form className="checkin" onSubmit={submit}>
        <input
          className="checkin__input"
          placeholder="ES-XXXXXXXXXX"
          value={code}
          onChange={(e) => setCode(e.target.value.toUpperCase())}
          aria-label="Ticket code"
          autoFocus
        />
        <button type="submit" className="btn btn--gold" disabled={!code.trim()}>Check in</button>
      </form>
      <AnimatePresence>
        {result && (
          <motion.div className={`alert ${result.already ? "" : "alert--success"}`} initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}>
            <span>
              {result.already ? "⚠ " : "✓ "}
              {result.message} — {result.registration.expo.title}
            </span>
          </motion.div>
        )}
      </AnimatePresence>
      <ErrorBox error={error} />

      <div className="panel mt">
        <div className="row-between">
          <h3>Registrations</h3>
          <input type="search" placeholder="Search name, email, code" value={q} onChange={(e) => setQ(e.target.value)} className="search-sm" />
        </div>
        {regs.loading && !regs.data ? (
          <Spinner />
        ) : !items.length ? (
          <Empty title="No registrations" icon="⌁" />
        ) : (
          <div className="table-wrap" data-lenis-prevent>
            <table className="table">
              <thead>
                <tr><th>Attendee</th><th>Ticket</th><th>Status</th><th>Registered</th><th>Check-in</th></tr>
              </thead>
              <tbody>
                {items.map((r) => (
                  <tr key={r._id}>
                    <td><strong>{r.attendee?.name}</strong><br /><span className="muted">{r.attendee?.email}</span></td>
                    <td><code>{r.ticketCode}</code></td>
                    <td><Badge>{r.status}</Badge></td>
                    <td>{fmtDateTime(r.createdAt)}</td>
                    <td>
                      {r.checkedIn ? (
                        <span className="gold">✓ {fmtDateTime(r.checkedInAt)}</span>
                      ) : r.status === "confirmed" ? (
                        <button type="button" className="btn btn--ghost btn--sm" onClick={() => submit(null, r.ticketCode)}>Check in</button>
                      ) : "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </>
  );
}
