import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { PageHead, Field, ErrorBox, Avatar } from "../../components/ui/UI.jsx";
import { useAuth } from "../../context/AuthContext.jsx";
import { useToast } from "../../context/ToastContext.jsx";
import { api, assetUrl, toFormData } from "../../lib/api.js";

export default function CompanyProfile() {
  const { user, setUser } = useAuth();
  const toast = useToast();
  const [c, setC] = useState({});
  const [logo, setLogo] = useState(null);
  const [preview, setPreview] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    const k = user.company || {};
    setC({
      name: k.name || "", category: k.category || "", website: k.website || "", description: k.description || "",
      products: (k.products || []).join(", "), contactEmail: k.contactEmail || "", contactPhone: k.contactPhone || "", address: k.address || "",
    });
  }, [user]);

  useEffect(() => {
    if (!logo) return undefined;
    const url = URL.createObjectURL(logo);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [logo]);

  const set = (k) => (e) => setC((x) => ({ ...x, [k]: e.target.value }));

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const d = await api("/auth/me", { method: "PUT", body: toFormData({ company: c, logo: logo || undefined }) });
      setUser(d.user);
      setLogo(null);
      toast.success("Company profile updated");
    } catch (err) {
      setError(err);
    } finally {
      setBusy(false);
    }
  }

  const logoSrc = preview || assetUrl(user.company?.logo);
  return (
    <>
      <PageHead
        eyebrow="Exhibitor portal"
        title="Company profile"
        actions={<Link to={`/exhibitors/${user._id}`} className="btn btn--ghost btn--sm">View public profile</Link>}
      >
        This is what attendees see in the exhibitor directory and on the floor plan.
      </PageHead>
      <form className="panel form-grid" onSubmit={submit}>
        <div className="field field--full logo-upload">
          {logoSrc ? <img src={logoSrc} alt="Company logo" /> : <Avatar name={c.name} size={80} />}
          <label className="btn btn--ghost btn--sm">
            Upload logo
            <input type="file" accept="image/*" hidden onChange={(e) => setLogo(e.target.files[0] || null)} />
          </label>
        </div>
        <Field label="Company name"><input required value={c.name || ""} onChange={set("name")} /></Field>
        <Field label="Category"><input value={c.category || ""} onChange={set("category")} placeholder="Technology, Healthcare…" /></Field>
        <Field label="Website"><input type="url" value={c.website || ""} onChange={set("website")} placeholder="https://" /></Field>
        <Field label="Contact email"><input type="email" value={c.contactEmail || ""} onChange={set("contactEmail")} /></Field>
        <Field label="Contact phone" hint="Stored encrypted, never shown publicly"><input value={c.contactPhone || ""} onChange={set("contactPhone")} /></Field>
        <Field label="Address"><input value={c.address || ""} onChange={set("address")} /></Field>
        <Field label="Products / services" hint="Comma separated — used by search" full><input value={c.products || ""} onChange={set("products")} /></Field>
        <Field label="Description" full><textarea rows={5} value={c.description || ""} onChange={set("description")} /></Field>
        <ErrorBox error={error} />
        <div className="form-actions field--full">
          <button type="submit" className="btn btn--gold" disabled={busy}>{busy ? "Saving…" : "Save profile"}</button>
        </div>
      </form>
    </>
  );
}
