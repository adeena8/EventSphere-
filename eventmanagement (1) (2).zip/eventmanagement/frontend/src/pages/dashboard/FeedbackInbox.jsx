import { useState } from "react";
import { PageHead, Spinner, Empty, Badge, ErrorBox, StatCard } from "../../components/ui/UI.jsx";
import { useFetch } from "../../hooks/useFetch.js";
import { useSocketEvent } from "../../context/SocketContext.jsx";
import { useToast } from "../../context/ToastContext.jsx";
import { api } from "../../lib/api.js";
import { timeAgo } from "../../lib/format.js";

export default function FeedbackInbox() {
  const [status, setStatus] = useState("open");
  const [type, setType] = useState("");
  const { data, loading, error, reload } = useFetch("/feedback", { status, type });
  useSocketEvent("feedback:new", () => reload());
  const items = data?.items || [];

  return (
    <>
      <PageHead eyebrow="Feedback & support" title="Inbox">
        Suggestions, issue reports and inquiries from users. Replies are delivered as notifications (or email for guests).
      </PageHead>
      <div className="stat-grid stat-grid--3">
        <StatCard label="Average rating" value={data?.avgRating ? data.avgRating.toFixed(1) + " / 5" : "—"} hint={`${data?.ratings || 0} ratings`} icon="★" />
        <StatCard label="Showing" value={items.length} icon="✉" tone="teal" />
      </div>
      <div className="toolbar">
        <div className="seg">
          {["open", "in_progress", "resolved", ""].map((s) => (
            <button key={s || "all"} type="button" className={status === s ? "is-active" : ""} onClick={() => setStatus(s)}>{(s || "all").replace("_", " ")}</button>
          ))}
        </div>
        <select value={type} onChange={(e) => setType(e.target.value)} aria-label="Type">
          <option value="">All types</option>
          {["suggestion", "issue", "feedback", "inquiry"].map((t) => <option key={t}>{t}</option>)}
        </select>
      </div>
      <ErrorBox error={error} onRetry={reload} />
      {loading && !data ? <Spinner /> : !items.length ? <Empty title="Inbox zero ✨" icon="✉" /> : (
        <div className="cards-list">
          {items.map((f) => <FeedbackItem key={f._id} f={f} onChanged={reload} />)}
        </div>
      )}
    </>
  );
}

function FeedbackItem({ f, onChanged }) {
  const toast = useToast();
  const [reply, setReply] = useState(f.response || "");
  const [busy, setBusy] = useState(false);
  async function save(body, msg) {
    setBusy(true);
    try {
      await api.patch(`/feedback/${f._id}`, body);
      toast.success(msg);
      onChanged();
    } catch (e) {
      toast.error(e.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <article className="app-card">
      <div className="app-card__main">
        <div className="row-gap">
          <Badge tone={f.type === "issue" ? "red" : f.type === "suggestion" ? "teal" : "gold"}>{f.type}</Badge>
          <Badge>{f.status}</Badge>
          {f.rating && <span className="gold">{"★".repeat(f.rating)}{"☆".repeat(5 - f.rating)}</span>}
          <span className="muted">{timeAgo(f.createdAt)}</span>
        </div>
        <h3>{f.subject}</h3>
        <p>{f.message}</p>
        <p className="muted">— {f.name || "Anonymous"}{f.email ? ` · ${f.email}` : ""}{f.expo?.title ? ` · ${f.expo.title}` : ""}</p>
        <textarea rows={2} placeholder="Write a reply…" value={reply} onChange={(e) => setReply(e.target.value)} />
      </div>
      <div className="app-card__actions">
        <button type="button" className="btn btn--gold btn--sm" disabled={busy || !reply.trim()} onClick={() => save({ response: reply, status: "resolved" }, "Reply sent")}>Reply & resolve</button>
        {f.status === "open" && <button type="button" className="btn btn--ghost btn--sm" disabled={busy} onClick={() => save({ status: "in_progress" }, "Marked in progress")}>In progress</button>}
        {f.status !== "resolved" && <button type="button" className="btn btn--plain btn--sm" disabled={busy} onClick={() => save({ status: "resolved" }, "Resolved")}>Resolve</button>}
      </div>
    </article>
  );
}
