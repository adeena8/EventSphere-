import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Link } from "react-router-dom";
import { PageHead, Spinner, Empty, Field, Badge, ErrorBox } from "../../components/ui/UI.jsx";
import FloorPlan from "../../components/FloorPlan.jsx";
import { useManagedExpos, useSelectedExpo, ExpoPicker } from "./shared.jsx";
import { useFetch } from "../../hooks/useFetch.js";
import { useSocketEvent, useExpoRoom } from "../../context/SocketContext.jsx";
import { useToast } from "../../context/ToastContext.jsx";
import { api } from "../../lib/api.js";

export default function FloorPlanManager() {
  const expos = useManagedExpos();
  const [expoId, setExpoId] = useSelectedExpo(expos.data?.items);
  const plan = useFetch(expoId ? `/expos/${expoId}/booths` : null);
  const options = useFetch(expoId ? `/booths/exhibitor-options/${expoId}` : null);
  const [selected, setSelected] = useState(null);
  const [grid, setGrid] = useState({ rows: 5, cols: 8, price: 1000 });
  const toast = useToast();

  useExpoRoom(expoId);
  useSocketEvent("booths:updated", (p) => {
    if (String(p.expoId) === expoId) {
      plan.reload();
      options.reload();
    }
  });

  useEffect(() => {
    if (plan.data?.floorPlan) setGrid((g) => ({ ...g, rows: plan.data.floorPlan.rows, cols: plan.data.floorPlan.cols }));
  }, [plan.data?.floorPlan]);

  // keep the side panel in sync with fresh data
  useEffect(() => {
    if (selected && plan.data) setSelected(plan.data.booths.find((b) => b._id === selected._id) || null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [plan.data]);

  async function generate(e) {
    e.preventDefault();
    try {
      const r = await api.post(`/expos/${expoId}/booths`, { generate: true, rows: grid.rows, cols: grid.cols, price: grid.price });
      toast.success(r.created ? `${r.created} booths added` : "Grid updated — no empty cells to fill");
      plan.reload();
    } catch (err) {
      toast.error(err.message);
    }
  }

  const booths = plan.data?.booths || [];
  const counts = booths.reduce((acc, b) => ({ ...acc, [b.status]: (acc[b.status] || 0) + 1 }), {});

  return (
    <>
      <PageHead eyebrow="Booth allocation" title="Floor plans">
        Click any booth to edit it, block it, or assign an approved exhibitor. Exhibitors and attendees see changes instantly.
      </PageHead>
      {expos.loading && !expos.data ? (
        <Spinner />
      ) : !expos.data?.items?.length ? (
        <Empty title="Create an expo first" icon="◉" action={<Link className="btn btn--gold" to="/dashboard/expos?new=1">New expo</Link>} />
      ) : (
        <>
          <div className="toolbar">
            <ExpoPicker expos={expos.data.items} value={expoId} onChange={(id) => { setSelected(null); setExpoId(id); }} />
            <div className="row-gap">
              {["available", "reserved", "occupied", "blocked"].map((s) => (
                <span key={s} className="chip">
                  <i className={`dot dot--${s}`} /> {counts[s] || 0} {s}
                </span>
              ))}
            </div>
          </div>
          <form className="inline-form" onSubmit={generate}>
            <Field label="Rows">
              <input type="number" min={1} max={30} value={grid.rows} onChange={(e) => setGrid({ ...grid, rows: e.target.value })} />
            </Field>
            <Field label="Columns">
              <input type="number" min={1} max={30} value={grid.cols} onChange={(e) => setGrid({ ...grid, cols: e.target.value })} />
            </Field>
            <Field label="Price for new booths">
              <input type="number" min={0} value={grid.price} onChange={(e) => setGrid({ ...grid, price: e.target.value })} />
            </Field>
            <button type="submit" className="btn btn--ghost">Resize / fill empty cells</button>
          </form>

          {plan.loading && !plan.data ? (
            <Spinner />
          ) : (
            <div className="plan-layout">
              <FloorPlan floorPlan={plan.data?.floorPlan} booths={booths} mode="manage" selectedId={selected?._id} onSelect={setSelected} />
              <AnimatePresence mode="wait">
                <motion.aside key={selected?._id || "none"} className="panel plan-layout__side" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0 }}>
                  {selected ? (
                    <BoothEditor booth={selected} options={options.data?.items || []} onChanged={() => { plan.reload(); options.reload(); }} onDeleted={() => { setSelected(null); plan.reload(); }} />
                  ) : (
                    <p className="muted">Select a booth on the plan to manage it.</p>
                  )}
                </motion.aside>
              </AnimatePresence>
            </div>
          )}
        </>
      )}
    </>
  );
}

function BoothEditor({ booth, options, onChanged, onDeleted }) {
  const toast = useToast();
  const [f, setF] = useState({});
  const [assignee, setAssignee] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    setF({ code: booth.code, hall: booth.hall, size: booth.size, price: booth.price });
    setAssignee(booth.exhibitor?._id || "");
    setError(null);
  }, [booth]);

  const run = async (fn, ok) => {
    setBusy(true);
    setError(null);
    try {
      await fn();
      if (ok) toast.success(ok);
      onChanged();
    } catch (e) {
      setError(e);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="stack">
      <div className="row-between">
        <h3>Booth {booth.code}</h3>
        <Badge>{booth.status}</Badge>
      </div>
      {booth.exhibitor && (
        <p className="muted">
          Allocated to <strong className="gold">{booth.exhibitor.company?.name || booth.exhibitor.name}</strong>
        </p>
      )}
      <form className="form-grid form-grid--2" onSubmit={(e) => { e.preventDefault(); run(() => api.put(`/booths/${booth._id}`, f), "Booth saved"); }}>
        <Field label="Code"><input value={f.code || ""} onChange={(e) => setF({ ...f, code: e.target.value })} /></Field>
        <Field label="Hall"><input value={f.hall || ""} onChange={(e) => setF({ ...f, hall: e.target.value })} /></Field>
        <Field label="Size">
          <select value={f.size || "medium"} onChange={(e) => setF({ ...f, size: e.target.value })}>
            <option value="small">Small</option>
            <option value="medium">Medium</option>
            <option value="large">Large</option>
          </select>
        </Field>
        <Field label="Price ($)"><input type="number" min={0} value={f.price ?? 0} onChange={(e) => setF({ ...f, price: e.target.value })} /></Field>
        <button type="submit" className="btn btn--ghost btn--sm field--full" disabled={busy}>Save details</button>
      </form>

      <div className="divider" />
      <Field label="Assign exhibitor" hint="Only exhibitors with an approved application for this expo">
        <select value={assignee} onChange={(e) => setAssignee(e.target.value)}>
          <option value="">— none —</option>
          {options.map((o) => (
            <option key={o._id} value={o._id}>
              {o.company || o.name} {o.assignedBooth && o.assignedBooth !== booth.code ? `(now at ${o.assignedBooth})` : ""}
            </option>
          ))}
        </select>
      </Field>
      <div className="row-gap">
        <button
          type="button"
          className="btn btn--gold btn--sm"
          disabled={busy || !assignee || assignee === booth.exhibitor?._id}
          onClick={() => run(() => api.patch(`/booths/${booth._id}/assign`, { exhibitorId: assignee }), "Exhibitor assigned & notified")}
        >
          Assign
        </button>
        {booth.exhibitor && (
          <button type="button" className="btn btn--ghost btn--sm" disabled={busy} onClick={() => run(() => api.patch(`/booths/${booth._id}/assign`, { exhibitorId: null }), "Booth released")}>
            Unassign
          </button>
        )}
      </div>

      {!booth.exhibitor && (
        <>
          <div className="divider" />
          <div className="row-gap">
            {booth.status === "blocked" ? (
              <button type="button" className="btn btn--ghost btn--sm" onClick={() => run(() => api.put(`/booths/${booth._id}`, { status: "available" }), "Booth available")}>
                Make available
              </button>
            ) : booth.status === "available" ? (
              <button type="button" className="btn btn--ghost btn--sm" onClick={() => run(() => api.put(`/booths/${booth._id}`, { status: "blocked" }), "Booth blocked")}>
                Block booth
              </button>
            ) : null}
            <button
              type="button"
              className="btn btn--danger btn--sm"
              disabled={busy}
              onClick={async () => {
                if (!window.confirm(`Delete booth ${booth.code}?`)) return;
                try {
                  await api.del(`/booths/${booth._id}`);
                  toast.success("Booth deleted");
                  onDeleted();
                } catch (e) {
                  setError(e);
                }
              }}
            >
              Delete
            </button>
          </div>
        </>
      )}
      {booth.status === "reserved" && <p className="muted">Reserved by a pending application — review it under Exhibitor applications.</p>}
      <ErrorBox error={error} />
    </div>
  );
}
