import { useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { PageHead, Spinner, Empty, Badge, Modal, Field, ErrorBox } from "../../components/ui/UI.jsx";
import { useManagedExpos } from "./shared.jsx";
import { api, assetUrl, toFormData } from "../../lib/api.js";
import { fmtRange, toDateInput } from "../../lib/format.js";
import { useToast } from "../../context/ToastContext.jsx";

const EMPTY = {
  title: "", theme: "", category: "Technology", description: "", startDate: "", endDate: "",
  venue: "", city: "", address: "", capacity: 0, status: "draft", bannerUrl: "", tags: "",
  rows: 5, cols: 8, generateBooths: true, boothPrice: 1000,
};

export default function ManageExpos() {
  const { data, loading, error, reload } = useManagedExpos();
  const [params, setParams] = useSearchParams();
  const [editing, setEditing] = useState(null); // null | "new" | expo
  const toast = useToast();

  useEffect(() => {
    if (params.get("new")) {
      setEditing("new");
      setParams({}, { replace: true });
    }
  }, [params, setParams]);

  async function remove(expo) {
    if (!window.confirm(`Delete “${expo.title}”? Booths, sessions, applications and registrations will be removed and attendees notified.`)) return;
    try {
      await api.del(`/expos/${expo._id}`);
      toast.success("Expo deleted");
      reload();
    } catch (e) {
      toast.error(e.message);
    }
  }

  async function quickStatus(expo, status) {
    try {
      await api.put(`/expos/${expo._id}`, { status });
      toast.success(`“${expo.title}” is now ${status}`);
      reload();
    } catch (e) {
      toast.error(e.message);
    }
  }

  const items = data?.items || [];
  return (
    <>
      <PageHead
        eyebrow="Expo management"
        title="Expos"
        actions={
          <button type="button" className="btn btn--gold" onClick={() => setEditing("new")}>
            + New expo
          </button>
        }
      >
        Create, edit, publish and remove expos. Changes reach attendees and exhibitors instantly.
      </PageHead>
      <ErrorBox error={error} onRetry={reload} />
      {loading && !data ? (
        <Spinner />
      ) : !items.length ? (
        <Empty title="No expos yet" icon="◉" action={<button type="button" className="btn btn--gold" onClick={() => setEditing("new")}>Create your first expo</button>} />
      ) : (
        <div className="expo-rows">
          {items.map((e) => (
            <article key={e._id} className="expo-row">
              <img src={assetUrl(e.banner)} alt="" onError={(ev) => (ev.currentTarget.style.visibility = "hidden")} />
              <div className="expo-row__main">
                <div className="row-gap">
                  <Badge>{e.status}</Badge>
                  <span className="muted">{e.category}</span>
                </div>
                <h3>
                  <Link to={`/expos/${e._id}`}>{e.title}</Link>
                </h3>
                <p className="muted">
                  {fmtRange(e.startDate, e.endDate)} · {[e.location?.venue, e.location?.city].filter(Boolean).join(", ")}
                </p>
                <p className="expo-row__stats">
                  <span>{e.stats?.exhibitors ?? 0} exhibitors</span>
                  <span>{e.stats?.boothsAvailable ?? 0}/{e.stats?.booths ?? 0} booths free</span>
                  <span>{e.stats?.attendees ?? 0} attendees</span>
                </p>
              </div>
              <div className="expo-row__actions">
                {e.status === "draft" && (
                  <button type="button" className="btn btn--sm btn--gold" onClick={() => quickStatus(e, "published")}>
                    Publish
                  </button>
                )}
                <button type="button" className="btn btn--sm btn--ghost" onClick={() => setEditing(e)}>
                  Edit
                </button>
                <Link to={`/dashboard/floorplan?expo=${e._id}`} className="btn btn--sm btn--ghost">
                  Floor plan
                </Link>
                <Link to={`/dashboard/schedule?expo=${e._id}`} className="btn btn--sm btn--ghost">
                  Schedule
                </Link>
                {e.status === "published" && (
                  <button type="button" className="btn btn--sm btn--plain" onClick={() => quickStatus(e, "cancelled")}>
                    Cancel
                  </button>
                )}
                <button type="button" className="btn btn--sm btn--danger" onClick={() => remove(e)}>
                  Delete
                </button>
              </div>
            </article>
          ))}
        </div>
      )}
      <ExpoForm
        open={!!editing}
        expo={editing === "new" ? null : editing}
        onClose={() => setEditing(null)}
        onSaved={() => {
          setEditing(null);
          reload();
        }}
      />
    </>
  );
}

function ExpoForm({ open, expo, onClose, onSaved }) {
  const toast = useToast();
  const [f, setF] = useState(EMPTY);
  const [banner, setBanner] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!open) return;
    setError(null);
    setBanner(null);
    setF(
      expo
        ? {
            ...EMPTY,
            title: expo.title,
            theme: expo.theme || "",
            category: expo.category || "",
            description: expo.description || "",
            startDate: toDateInput(expo.startDate),
            endDate: toDateInput(expo.endDate),
            venue: expo.location?.venue || "",
            city: expo.location?.city || "",
            address: expo.location?.address || "",
            capacity: expo.capacity || 0,
            status: expo.status,
            bannerUrl: expo.banner?.startsWith("http") ? expo.banner : "",
            tags: (expo.tags || []).join(", "),
            rows: expo.floorPlan?.rows || 5,
            cols: expo.floorPlan?.cols || 8,
            generateBooths: false,
          }
        : EMPTY
    );
  }, [open, expo]);

  const set = (k) => (e) => setF((x) => ({ ...x, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value }));

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const start = new Date(`${f.startDate}T09:00`);
      const end = new Date(`${f.endDate}T18:00`);
      const payload = {
        title: f.title,
        theme: f.theme,
        category: f.category,
        description: f.description,
        startDate: start,
        endDate: end,
        status: f.status,
        capacity: Number(f.capacity) || 0,
        tags: f.tags,
        location: { venue: f.venue, city: f.city, address: f.address },
        floorPlan: { rows: Number(f.rows), cols: Number(f.cols) },
        bannerUrl: f.bannerUrl || undefined,
        banner: banner || undefined,
        ...(expo ? {} : { generateBooths: f.generateBooths, boothPrice: f.boothPrice }),
      };
      await api(expo ? `/expos/${expo._id}` : "/expos", { method: expo ? "PUT" : "POST", body: toFormData(payload) });
      toast.success(expo ? "Expo updated" : "Expo created");
      onSaved();
    } catch (err) {
      setError(err);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal open={open} onClose={onClose} title={expo ? `Edit ${expo.title}` : "New expo"} wide>
      <form className="form-grid" onSubmit={submit}>
        <Field label="Title" full>
          <input required value={f.title} onChange={set("title")} maxLength={140} />
        </Field>
        <Field label="Theme">
          <input value={f.theme} onChange={set("theme")} placeholder="e.g. Intelligence Everywhere" />
        </Field>
        <Field label="Category">
          <input list="expo-cats" value={f.category} onChange={set("category")} />
          <datalist id="expo-cats">
            {["Technology", "Healthcare", "Energy", "Food & Beverage", "Automotive", "Fashion", "Education", "Real Estate"].map((c) => (
              <option key={c} value={c} />
            ))}
          </datalist>
        </Field>
        <Field label="Start date">
          <input type="date" required value={f.startDate} onChange={set("startDate")} />
        </Field>
        <Field label="End date">
          <input type="date" required value={f.endDate} min={f.startDate} onChange={set("endDate")} />
        </Field>
        <Field label="Venue">
          <input value={f.venue} onChange={set("venue")} />
        </Field>
        <Field label="City">
          <input value={f.city} onChange={set("city")} />
        </Field>
        <Field label="Address" full>
          <input value={f.address} onChange={set("address")} />
        </Field>
        <Field label="Description" full>
          <textarea rows={4} value={f.description} onChange={set("description")} />
        </Field>
        <Field label="Attendee capacity" hint="0 = unlimited">
          <input type="number" min={0} value={f.capacity} onChange={set("capacity")} />
        </Field>
        <Field label="Status">
          <select value={f.status} onChange={set("status")}>
            <option value="draft">Draft (hidden)</option>
            <option value="published">Published</option>
            <option value="cancelled">Cancelled</option>
            <option value="completed">Completed</option>
          </select>
        </Field>
        <Field label="Tags" hint="Comma separated">
          <input value={f.tags} onChange={set("tags")} />
        </Field>
        <Field label="Banner image" hint="Upload, or paste an image URL below">
          <input type="file" accept="image/*" onChange={(e) => setBanner(e.target.files[0] || null)} />
        </Field>
        <Field label="Banner URL" full>
          <input type="url" value={f.bannerUrl} onChange={set("bannerUrl")} placeholder="https://images.unsplash.com/…" />
        </Field>
        <Field label="Floor plan rows">
          <input type="number" min={1} max={30} value={f.rows} onChange={set("rows")} />
        </Field>
        <Field label="Floor plan columns">
          <input type="number" min={1} max={30} value={f.cols} onChange={set("cols")} />
        </Field>
        {!expo && (
          <>
            <label className="check field--full">
              <input type="checkbox" checked={f.generateBooths} onChange={set("generateBooths")} />
              <span>Generate a booth for every grid cell ({f.rows * f.cols} booths)</span>
            </label>
            {f.generateBooths && (
              <Field label="Default booth price ($)">
                <input type="number" min={0} value={f.boothPrice} onChange={set("boothPrice")} />
              </Field>
            )}
          </>
        )}
        <ErrorBox error={error} />
        <div className="form-actions field--full">
          <button type="button" className="btn btn--ghost" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn btn--gold" disabled={busy}>
            {busy ? "Saving…" : expo ? "Save changes" : "Create expo"}
          </button>
        </div>
      </form>
    </Modal>
  );
}
