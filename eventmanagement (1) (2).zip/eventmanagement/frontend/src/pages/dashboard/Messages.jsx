import { useEffect, useRef, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { Avatar, Spinner, Empty, ErrorBox } from "../../components/ui/UI.jsx";
import { useFetch, useDebounced } from "../../hooks/useFetch.js";
import { useAuth } from "../../context/AuthContext.jsx";
import { useSocket, useSocketEvent } from "../../context/SocketContext.jsx";
import { api } from "../../lib/api.js";
import { timeAgo, fmtTime, ROLE_LABEL } from "../../lib/format.js";

export default function Messages() {
  const { userId } = useParams();
  const navigate = useNavigate();
  const convs = useFetch("/messages/conversations");
  const [picker, setPicker] = useState(false);

  useSocketEvent("message:new", () => convs.reload());
  useSocketEvent("message:read", () => convs.reload());

  return (
    <div className={`chat ${userId ? "has-thread" : ""}`}>
      <aside className="chat__list" data-lenis-prevent>
        <div className="chat__list-head">
          <h2>Messages</h2>
          <button type="button" className="btn btn--gold btn--sm" onClick={() => setPicker(true)}>+ New</button>
        </div>
        {convs.loading && !convs.data ? (
          <Spinner />
        ) : !convs.data?.items?.length ? (
          <Empty title="No conversations" icon="✉">Start one with an organizer, exhibitor or your booth neighbours.</Empty>
        ) : (
          <ul>
            {convs.data.items.map((c) => (
              <li key={c.partner._id}>
                <Link to={`/dashboard/messages/${c.partner._id}`} className={`conv ${userId === String(c.partner._id) ? "is-active" : ""}`}>
                  <span className="conv__avatar">
                    <Avatar src={c.partner.company?.logo || c.partner.avatar} name={c.partner.company?.name || c.partner.name} size={42} />
                    {c.online && <i className="live-dot is-on" />}
                  </span>
                  <span className="conv__body">
                    <strong>{c.partner.company?.name || c.partner.name}</strong>
                    <span className="conv__last">{c.lastMessage.fromMe ? "You: " : ""}{c.lastMessage.body}</span>
                  </span>
                  <span className="conv__meta">
                    <span>{timeAgo(c.lastMessage.createdAt)}</span>
                    {c.unread > 0 && <span className="pill">{c.unread}</span>}
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </aside>
      <section className="chat__thread">
        {userId ? <Thread key={userId} userId={userId} onBack={() => navigate("/dashboard/messages")} onSent={() => convs.reload()} /> : (
          <Empty title="Select a conversation" icon="✉" action={<button type="button" className="btn btn--ghost" onClick={() => setPicker(true)}>Start a new chat</button>} />
        )}
      </section>
      <ContactPicker open={picker} onClose={() => setPicker(false)} onPick={(id) => { setPicker(false); navigate(`/dashboard/messages/${id}`); }} />
    </div>
  );
}

function Thread({ userId, onBack, onSent }) {
  const { user } = useAuth();
  const { socket, refreshCounts } = useSocket();
  const { data, loading, error, setData } = useFetch(`/messages/with/${userId}`);
  const [text, setText] = useState("");
  const [typing, setTyping] = useState(false);
  const [sending, setSending] = useState(false);
  const endRef = useRef(null);
  const typingTimer = useRef(null);
  const lastTypingSent = useRef(0);

  useEffect(() => {
    if (data) refreshCounts();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data?.items?.length]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [data?.items?.length, typing]);

  useSocketEvent("message:new", (m) => {
    const involved = [String(m.from), String(m.to)];
    if (!involved.includes(userId)) return;
    setData((d) => (d && !d.items.some((x) => x._id === m._id) ? { ...d, items: [...d.items, m] } : d));
    if (String(m.from) === userId) api.get(`/messages/with/${userId}`).catch(() => {}); // mark read
  });
  useSocketEvent("typing", ({ from }) => {
    if (String(from) !== userId) return;
    setTyping(true);
    clearTimeout(typingTimer.current);
    typingTimer.current = setTimeout(() => setTyping(false), 2500);
  });
  useSocketEvent("presence", (p) => {
    if (String(p.userId) === userId) setData((d) => (d ? { ...d, online: p.online } : d));
  });

  async function send(e) {
    e.preventDefault();
    const body = text.trim();
    if (!body) return;
    setSending(true);
    try {
      const { message } = await api.post("/messages", { to: userId, body });
      if (message) setData((d) => (d.items.some((x) => x._id === message._id) ? d : { ...d, items: [...d.items, message], sendError: null }));
      setText("");
      onSent?.();
    } catch (err) {
      setData((d) => ({ ...d, sendError: err.message }));
    } finally {
      setSending(false);
    }
  }

  function onType(v) {
    setText(v);
    const now = Date.now();
    if (socket && now - lastTypingSent.current > 1500) {
      socket.emit("typing", { to: userId });
      lastTypingSent.current = now;
    }
  }

  if (loading && !data) return <Spinner />;
  if (error) return <ErrorBox error={error} />;
  const p = data.partner;

  return (
    <>
      <header className="thread__head">
        <button type="button" className="icon-btn thread__back" onClick={onBack} aria-label="Back to conversations">←</button>
        <Avatar src={p.company?.logo || p.avatar} name={p.company?.name || p.name} size={40} />
        <div>
          <strong>{p.company?.name || p.name}</strong>
          <span className="muted">
            {ROLE_LABEL[p.role]} · {data.online ? <span className="gold">online</span> : "offline"}
          </span>
        </div>
        {p.role === "exhibitor" && <Link to={`/exhibitors/${p._id}`} className="btn btn--plain btn--sm">Profile</Link>}
      </header>
      <div className="thread__body" data-lenis-prevent>
        {!data.items.length && <p className="muted center">Say hello 👋</p>}
        <AnimatePresence initial={false}>
          {data.items.map((m) => {
            const mine = String(m.from) === String(user._id);
            return (
              <motion.div
                key={m._id}
                className={`bubble ${mine ? "bubble--me" : ""}`}
                initial={{ opacity: 0, y: 12, scale: 0.97 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ type: "spring", stiffness: 400, damping: 30 }}
              >
                <p>{m.body}</p>
                <span>
                  {fmtTime(m.createdAt)}
                  {mine && (m.read ? " · seen" : "")}
                </span>
              </motion.div>
            );
          })}
        </AnimatePresence>
        {typing && <div className="typing" aria-live="polite"><i /><i /><i /></div>}
        <div ref={endRef} />
      </div>
      {data.canReply ? (
        <form className="thread__compose" onSubmit={send}>
          <textarea
            rows={1}
            placeholder="Write a message…"
            value={text}
            onChange={(e) => onType(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) send(e);
            }}
            aria-label="Message"
          />
          <button type="submit" className="btn btn--gold" disabled={sending || !text.trim()}>Send</button>
        </form>
      ) : (
        <p className="muted thread__compose">This user isn't accepting messages.</p>
      )}
      {data.sendError && <ErrorBox error={new Error(data.sendError)} />}
    </>
  );
}

function ContactPicker({ open, onClose, onPick }) {
  const [q, setQ] = useState("");
  const dq = useDebounced(q);
  const { data, loading } = useFetch(open ? "/messages/contacts" : null, { q: dq });
  if (!open) return null;
  return (
    <div className="modal" onMouseDown={(e) => e.target === e.currentTarget && onClose()} data-lenis-prevent>
      <motion.div className="modal__panel" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} role="dialog" aria-label="New message">
        <header className="modal__head">
          <h2>New message</h2>
          <button type="button" className="icon-btn" onClick={onClose} aria-label="Close">×</button>
        </header>
        <div className="modal__body">
          <input type="search" autoFocus placeholder="Search people or companies…" value={q} onChange={(e) => setQ(e.target.value)} className="search-sm" />
          {loading && !data ? <Spinner /> : (
            (data?.groups || []).map((g) => (
              <div key={g.label} className="mt-sm">
                <p className="eyebrow">{g.label}</p>
                <ul className="list">
                  {g.users.map((u) => (
                    <li key={u._id}>
                      <button type="button" className="conv conv--btn" onClick={() => onPick(u._id)}>
                        <Avatar src={u.company?.logo || u.avatar} name={u.company?.name || u.name} size={36} />
                        <span className="conv__body">
                          <strong>{u.company?.name || u.name}</strong>
                          <span className="conv__last">{ROLE_LABEL[u.role]}{u.company?.name ? ` · ${u.name}` : ""}</span>
                        </span>
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            ))
          )}
          {data && !data.groups?.length && <p className="muted">No contacts found.</p>}
        </div>
      </motion.div>
    </div>
  );
}
