import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { PageHead, Spinner, Empty, Field, Avatar, ErrorBox, Badge } from "../../components/ui/UI.jsx";
import FloorPlan from "../../components/FloorPlan.jsx";
import { useFetch } from "../../hooks/useFetch.js";
import { useToast } from "../../context/ToastContext.jsx";
import { useSocketEvent } from "../../context/SocketContext.jsx";
import { api } from "../../lib/api.js";
import { fmtRange } from "../../lib/format.js";

export default function MyBooths() {
  const { data, loading, reload } = useFetch("/booths/mine");
  useSocketEvent("notification:new", (n) => n.type === "booth" && reload());
  const items = data?.items || [];
  return (
    <>
      <PageHead eyebrow="Exhibitor portal" title="My booths">
        Manage what you showcase, who's on staff, and see who's next door.
      </PageHead>
      {loading && !data ? (
        <Spinner />
      ) : !items.length ? (
        <Empty title="No booths allocated yet" icon="▦" action={<Link to="/dashboard/applications" className="btn btn--gold">Apply to an expo</Link>}>
          Once an organizer approves your application, your booth appears here.
        </Empty>
      ) : (
        <div className="stack-lg">{items.map((b) => <BoothPanel key={b._id} booth={b} onSaved={reload} />)}</div>
      )}
    </>
  );
}

function BoothPanel({ booth, onSaved }) {
  const toast = useToast();
  const [f, setF] = useState({ displayName: "", description: "", products: "" });
  const [staff, setStaff] = useState([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const neighbors = useFetch(`/booths/${booth._id}/neighbors`);
  const plan = useFetch(`/expos/${booth.expo._id}/booths`);

  useEffect(() => {
    setF({ displayName: booth.displayName || "", description: booth.description || "", products: (booth.products || []).join(", ") });
    setStaff(booth.staff?.length ? booth.staff : []);
  }, [booth]);

  async function save(e) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api.put(`/booths/${booth._id}/details`, { ...f, staff: staff.filter((s) => s.name.trim()) });
      toast.success("Booth details saved — visible to attendees now");
      onSaved();
    } catch (err) {
      setError(err);
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="panel booth-panel">
      <header className="row-between">
        <div>
          <p className="eyebrow">{booth.expo.title} · {fmtRange(booth.expo.startDate, booth.expo.endDate)}</p>
          <h2>Booth {booth.code} <span className="muted">· {booth.hall} · {booth.size}</span></h2>
        </div>
        <div className="row-gap">
          <Badge tone="gold">{booth.visits} visits</Badge>
          <Link to={`/expos/${booth.expo._id}?tab=floorplan&booth=${booth._id}`} className="btn btn--ghost btn--sm">View on map</Link>
        </div>
      </header>
      <div className="booth-panel__grid">
        <form className="form-grid" onSubmit={save}>
          <Field label="Display name" full><input value={f.displayName} onChange={(e) => setF({ ...f, displayName: e.target.value })} /></Field>
          <Field label="Booth description" full><textarea rows={3} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} placeholder="Live demos every hour, free samples…" /></Field>
          <Field label="Products / services showcased" hint="Comma separated" full><input value={f.products} onChange={(e) => setF({ ...f, products: e.target.value })} /></Field>
          <div className="field field--full">
            <span className="field__label">Booth staff</span>
            {staff.map((s, i) => (
              <div key={i} className="staff-row">
                <input placeholder="Name" value={s.name} onChange={(e) => setStaff(staff.map((x, k) => (k === i ? { ...x, name: e.target.value } : x)))} />
                <input placeholder="Role" value={s.role || ""} onChange={(e) => setStaff(staff.map((x, k) => (k === i ? { ...x, role: e.target.value } : x)))} />
                <input placeholder="Email" type="email" value={s.email || ""} onChange={(e) => setStaff(staff.map((x, k) => (k === i ? { ...x, email: e.target.value } : x)))} />
                <button type="button" className="icon-btn" aria-label="Remove" onClick={() => setStaff(staff.filter((_, k) => k !== i))}>×</button>
              </div>
            ))}
            <button type="button" className="btn btn--plain btn--sm" onClick={() => setStaff([...staff, { name: "", role: "", email: "" }])}>+ Add staff member</button>
          </div>
          <ErrorBox error={error} />
          <div className="form-actions field--full">
            <button type="submit" className="btn btn--gold" disabled={busy}>{busy ? "Saving…" : "Save booth"}</button>
          </div>
        </form>
        <div className="stack">
          {plan.data && <FloorPlan floorPlan={plan.data.floorPlan} booths={plan.data.booths} highlightIds={[booth._id]} compact />}
          <div>
            <h3>Neighbouring exhibitors</h3>
            {neighbors.loading ? <Spinner /> : neighbors.data?.items?.length ? (
              <ul className="list">
                {neighbors.data.items.map((n) => (
                  <li key={n._id}>
                    <div className="speaker">
                      <Avatar src={n.exhibitor?.company?.logo} name={n.exhibitor?.company?.name || n.exhibitor?.name} size={34} />
                      <div>
                        <strong>{n.exhibitor?.company?.name || n.exhibitor?.name}</strong>
                        <span>Booth {n.code} · {n.exhibitor?.company?.category}</span>
                      </div>
                    </div>
                    <Link to={`/dashboard/messages/${n.exhibitor?._id}`} className="btn btn--ghost btn--sm">Say hi</Link>
                  </li>
                ))}
              </ul>
            ) : <p className="muted">No neighbours allocated yet.</p>}
          </div>
        </div>
      </div>
    </section>
  );
}
