import { useState } from "react";
import { Link } from "react-router-dom";
import { PageHead, Spinner, Empty, Tabs } from "../../components/ui/UI.jsx";
import { SessionCard } from "../../components/Cards.jsx";
import { useFetch } from "../../hooks/useFetch.js";
import { useToast } from "../../context/ToastContext.jsx";
import { useSocketEvent } from "../../context/SocketContext.jsx";
import { api } from "../../lib/api.js";

export default function MySessions() {
  const { data, loading, reload } = useFetch("/sessions/mine");
  const [tab, setTab] = useState("upcoming");
  const [busy, setBusy] = useState(false);
  const toast = useToast();
  useSocketEvent("notification:new", (n) => n.type === "schedule" && reload());

  const all = data?.items || [];
  const now = new Date();
  const lists = {
    upcoming: all.filter((s) => new Date(s.endTime) >= now),
    registered: all.filter((s) => s.isRegistered),
    bookmarked: all.filter((s) => s.isBookmarked),
    past: all.filter((s) => new Date(s.endTime) < now),
  };

  async function act(kind, s) {
    setBusy(true);
    try {
      if (kind === "bookmark") await api.post(`/sessions/${s._id}/bookmark`);
      else if (s.isRegistered) await api.del(`/sessions/${s._id}/register`);
      else await api.post(`/sessions/${s._id}/register`);
      reload();
    } catch (e) {
      toast.error(e.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <PageHead eyebrow="Schedule" title="My sessions">
        Sessions you've reserved or bookmarked. You'll get a reminder 30 minutes before each one starts.
      </PageHead>
      <Tabs
        value={tab}
        onChange={setTab}
        tabs={Object.keys(lists).map((k) => ({ value: k, label: k[0].toUpperCase() + k.slice(1), count: lists[k].length }))}
      />
      {loading && !data ? (
        <Spinner />
      ) : !lists[tab].length ? (
        <Empty title="Nothing here" icon="◷" action={<Link to="/expos" className="btn btn--gold">Browse expo schedules</Link>} />
      ) : (
        lists[tab].map((s) => (
          <SessionCard key={s._id} session={s} showExpo busy={busy} onRegister={(x) => act("register", x)} onBookmark={(x) => act("bookmark", x)} />
        ))
      )}
    </>
  );
}
