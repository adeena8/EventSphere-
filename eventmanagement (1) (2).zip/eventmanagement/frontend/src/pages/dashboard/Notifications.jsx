import { Link } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { PageHead, Spinner, Empty } from "../../components/ui/UI.jsx";
import { useFetch } from "../../hooks/useFetch.js";
import { useSocket, useSocketEvent } from "../../context/SocketContext.jsx";
import { api } from "../../lib/api.js";
import { timeAgo } from "../../lib/format.js";

const ICON = { info: "ℹ", schedule: "◷", booth: "▦", application: "✎", message: "✉", reminder: "⏰", announcement: "📣", feedback: "★" };

export default function Notifications() {
  const { data, loading, setData, reload } = useFetch("/notifications", { limit: 100 });
  const { setUnreadNotifications } = useSocket();

  useSocketEvent("notification:new", (n) => setData((d) => (d ? { ...d, items: [n, ...d.items], unread: d.unread + 1 } : d)));

  async function read(n) {
    if (n.read) return;
    await api.patch(`/notifications/${n._id}/read`).catch(() => {});
    setData((d) => ({ ...d, items: d.items.map((x) => (x._id === n._id ? { ...x, read: true } : x)), unread: Math.max(0, d.unread - 1) }));
    setUnreadNotifications((c) => Math.max(0, c - 1));
  }
  async function readAll() {
    await api.patch("/notifications/read-all");
    setUnreadNotifications(0);
    reload();
  }
  async function remove(n) {
    await api.del(`/notifications/${n._id}`).catch(() => {});
    if (!n.read) setUnreadNotifications((c) => Math.max(0, c - 1));
    setData((d) => ({ ...d, items: d.items.filter((x) => x._id !== n._id) }));
  }

  const items = data?.items || [];
  return (
    <>
      <PageHead
        eyebrow="Inbox"
        title="Notifications"
        actions={data?.unread > 0 && <button type="button" className="btn btn--ghost btn--sm" onClick={readAll}>Mark all read</button>}
      >
        Schedule changes, booth updates, application decisions, reminders and announcements — delivered in real time.
      </PageHead>
      {loading && !data ? (
        <Spinner />
      ) : !items.length ? (
        <Empty title="You're all caught up" icon="🔔" />
      ) : (
        <ul className="notifs">
          <AnimatePresence initial={false}>
            {items.map((n) => (
              <motion.li
                key={n._id}
                layout
                className={`notif ${n.read ? "" : "is-unread"}`}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 40, height: 0 }}
                onMouseEnter={() => read(n)}
              >
                <span className={`notif__icon notif__icon--${n.type}`} aria-hidden="true">{ICON[n.type] || "•"}</span>
                <div className="notif__body">
                  <strong>{n.title}</strong>
                  {n.body && <p>{n.body}</p>}
                  <span className="muted">{timeAgo(n.createdAt)}</span>
                </div>
                <div className="notif__actions">
                  {n.link && <Link to={n.link} className="btn btn--ghost btn--sm" onClick={() => read(n)}>Open</Link>}
                  <button type="button" className="icon-btn" aria-label="Delete notification" onClick={() => remove(n)}>×</button>
                </div>
              </motion.li>
            ))}
          </AnimatePresence>
        </ul>
      )}
    </>
  );
}
