import { Link } from "react-router-dom";
import { useAuth } from "../../context/AuthContext.jsx";
import { useFetch } from "../../hooks/useFetch.js";
import { PageHead, Spinner, StatCard, Empty, Badge } from "../../components/ui/UI.jsx";
import { BarChart } from "../../components/ui/Charts.jsx";
import { SessionCard, ExpoCard } from "../../components/Cards.jsx";
import { AnalyticsBoard } from "./Analytics.jsx";
import { fmtDate, fmtRange, daysUntil } from "../../lib/format.js";

function greeting() {
  const h = new Date().getHours();
  return h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening";
}

export default function Overview() {
  const { user } = useAuth();
  const first = user.name.split(" ")[0];
  return (
    <>
      <PageHead eyebrow={greeting()} title={`Welcome, ${first}`} />
      {user.role === "admin" || user.role === "organizer" ? (
        <>
          <div className="quick-actions">
            <Link to="/dashboard/expos?new=1" className="btn btn--gold btn--sm">+ New expo</Link>
            <Link to="/dashboard/applications" className="btn btn--ghost btn--sm">Review applications</Link>
            <Link to="/dashboard/schedule" className="btn btn--ghost btn--sm">Edit schedule</Link>
            <Link to="/dashboard/checkin" className="btn btn--ghost btn--sm">Check-in</Link>
          </div>
          <AnalyticsBoard compact />
        </>
      ) : user.role === "exhibitor" ? (
        <ExhibitorHome />
      ) : (
        <AttendeeHome />
      )}
    </>
  );
}

function ExhibitorHome() {
  const apps = useFetch("/applications/mine");
  const stats = useFetch("/analytics/exhibitor");
  const open = useFetch("/expos", { when: "upcoming", limit: 3 });
  const s = stats.data;
  const items = apps.data?.items || [];
  const profileIncomplete = !useAuth().user.company?.description;

  return (
    <div className="stack-lg">
      {profileIncomplete && (
        <div className="alert">
          <span>Complete your company profile so attendees can find you.</span>
          <Link to="/dashboard/company" className="btn btn--sm btn--gold">Complete profile</Link>
        </div>
      )}
      <div className="stat-grid">
        <StatCard label="Applications" value={items.length} hint={`${items.filter((a) => a.status === "pending").length} pending`} icon="✎" />
        <StatCard label="Booths" value={items.filter((a) => a.assignedBooth).length} icon="▦" tone="teal" />
        <StatCard label="Booth visits" value={s?.totalVisits ?? "—"} icon="⌖" tone="wine" />
        <StatCard label="Unique visitors" value={s?.uniqueVisitors ?? "—"} icon="☺" />
      </div>
      {s && (
        <div className="panel">
          <h3>Booth traffic · last 14 days</h3>
          <BarChart data={s.visitsByDay.map((d) => ({ label: fmtDate(d.date), short: d.date.slice(8), value: d.value }))} labelEvery={2} color="#7a8f7a" />
        </div>
      )}
      <div className="panel">
        <div className="row-between">
          <h3>Your applications</h3>
          <Link to="/dashboard/applications" className="link-arrow">All →</Link>
        </div>
        {apps.loading ? (
          <Spinner />
        ) : items.length ? (
          <ul className="list">
            {items.slice(0, 5).map((a) => (
              <li key={a._id}>
                <div>
                  <strong>{a.expo?.title}</strong>
                  <span className="muted">{fmtRange(a.expo?.startDate, a.expo?.endDate)}</span>
                </div>
                <div className="row-gap">
                  {a.assignedBooth && <span className="chip chip--gold">Booth {a.assignedBooth.code}</span>}
                  <Badge>{a.status}</Badge>
                </div>
              </li>
            ))}
          </ul>
        ) : (
          <Empty title="No applications yet" icon="✎">Pick an upcoming expo below and apply to exhibit.</Empty>
        )}
      </div>
      <h3>Open for exhibitors</h3>
      <div className="grid grid--3">
        {(open.data?.items || []).map((e, i) => (
          <ExpoCard key={e._id} expo={e} index={i} />
        ))}
      </div>
    </div>
  );
}

function AttendeeHome() {
  const tickets = useFetch("/registrations/mine");
  const sessions = useFetch("/sessions/mine");
  const expos = useFetch("/expos", { when: "upcoming", limit: 3 });
  const upcoming = (sessions.data?.items || []).filter((s) => new Date(s.endTime) > new Date()).slice(0, 3);
  const next = (tickets.data?.items || []).filter((t) => new Date(t.expo.endDate) >= new Date()).sort((a, b) => new Date(a.expo.startDate) - new Date(b.expo.startDate))[0];

  return (
    <div className="stack-lg">
      <div className="stat-grid">
        <StatCard label="Tickets" value={tickets.data?.items?.length ?? "—"} icon="⌁" />
        <StatCard label="Sessions reserved" value={(sessions.data?.items || []).filter((s) => s.isRegistered).length} icon="◷" tone="teal" />
        <StatCard label="Bookmarked" value={(sessions.data?.items || []).filter((s) => s.isBookmarked).length} icon="★" />
        <StatCard label="Next expo" value={next ? `${Math.max(0, daysUntil(next.expo.startDate))} days` : "—"} hint={next?.expo.title} icon="◉" tone="wine" />
      </div>
      <div className="panel">
        <div className="row-between">
          <h3>Coming up on your schedule</h3>
          <Link to="/dashboard/sessions" className="link-arrow">Full schedule →</Link>
        </div>
        {sessions.loading ? <Spinner /> : upcoming.length ? upcoming.map((s) => <SessionCard key={s._id} session={s} showExpo actions={false} />) : (
          <Empty title="Nothing planned yet" icon="◷">Open an expo's Schedule tab to reserve or bookmark sessions.</Empty>
        )}
      </div>
      <h3>Discover expos</h3>
      <div className="grid grid--3">
        {(expos.data?.items || []).map((e, i) => (
          <ExpoCard key={e._id} expo={e} index={i} />
        ))}
      </div>
    </div>
  );
}
