import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { PageHead, Field, ErrorBox, Avatar } from "../../components/ui/UI.jsx";
import { useAuth } from "../../context/AuthContext.jsx";
import { useToast } from "../../context/ToastContext.jsx";
import { api, toFormData } from "../../lib/api.js";
import { ROLE_LABEL, fmtDate } from "../../lib/format.js";

export default function Profile() {
  const { user, setUser, applySession, logout } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();

  const [p, setP] = useState({ name: "", phone: "", bio: "" });
  const [avatar, setAvatar] = useState(null);
  const [pw, setPw] = useState({ currentPassword: "", newPassword: "" });
  const [delPw, setDelPw] = useState("");
  const [err, setErr] = useState({});
  const [busy, setBusy] = useState("");

  useEffect(() => setP({ name: user.name, phone: user.phone || "", bio: user.bio || "" }), [user]);

  const run = async (key, fn) => {
    setBusy(key);
    setErr((e) => ({ ...e, [key]: null }));
    try {
      await fn();
    } catch (e) {
      setErr((x) => ({ ...x, [key]: e }));
    } finally {
      setBusy("");
    }
  };

  const saveProfile = (e) => {
    e.preventDefault();
    run("profile", async () => {
      const d = await api("/auth/me", { method: "PUT", body: toFormData({ ...p, avatar: avatar || undefined }) });
      setUser(d.user);
      setAvatar(null);
      toast.success("Profile saved");
    });
  };
  const changePw = (e) => {
    e.preventDefault();
    run("pw", async () => {
      applySession(await api.put("/auth/password", pw));
      setPw({ currentPassword: "", newPassword: "" });
      toast.success("Password changed");
    });
  };
  const privacy = (k, v) =>
    run("privacy", async () => {
      const d = await api.put("/auth/privacy", { [k]: v });
      setUser(d.user);
      toast.info("Privacy preference saved");
    });
  const exportData = () =>
    run("export", async () => {
      const res = await api("/auth/me/export", { raw: true });
      if (!res.ok) throw new Error("Export failed");
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `eventsphere-my-data-${fmtDate(new Date()).replace(/\s/g, "-")}.json`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success("Your data export has been downloaded");
    });
  const deleteAccount = (e) => {
    e.preventDefault();
    if (!window.confirm("This permanently deletes your account, tickets, applications and messages. Continue?")) return;
    run("delete", async () => {
      await api.del("/auth/me", { password: delPw });
      logout();
      toast.info("Your account has been deleted");
      navigate("/");
    });
  };

  const pv = user.privacy || {};
  return (
    <>
      <PageHead eyebrow={ROLE_LABEL[user.role]} title="Account & privacy">
        Member since {fmtDate(user.createdAt)} · consent recorded {pv.consentAt ? fmtDate(pv.consentAt) : "—"}
      </PageHead>
      <div className="grid grid--2">
        <form className="panel form-grid form-grid--1" onSubmit={saveProfile}>
          <h3>Profile</h3>
          <div className="logo-upload">
            <Avatar src={avatar ? URL.createObjectURL(avatar) : user.avatar} name={user.name} size={72} />
            <label className="btn btn--ghost btn--sm">
              Change photo
              <input type="file" accept="image/*" hidden onChange={(e) => setAvatar(e.target.files[0] || null)} />
            </label>
          </div>
          <Field label="Name"><input required value={p.name} onChange={(e) => setP({ ...p, name: e.target.value })} /></Field>
          <Field label="Email" hint="Contact support to change your email"><input value={user.email} disabled /></Field>
          <Field label="Phone" hint="Encrypted at rest"><input value={p.phone} onChange={(e) => setP({ ...p, phone: e.target.value })} /></Field>
          <Field label="Bio"><textarea rows={3} value={p.bio} onChange={(e) => setP({ ...p, bio: e.target.value })} maxLength={500} /></Field>
          <ErrorBox error={err.profile} />
          <button type="submit" className="btn btn--gold" disabled={busy === "profile"}>Save profile</button>
        </form>

        <div className="stack">
          <form className="panel form-grid form-grid--1" onSubmit={changePw}>
            <h3>Change password</h3>
            <Field label="Current password"><input type="password" required value={pw.currentPassword} onChange={(e) => setPw({ ...pw, currentPassword: e.target.value })} autoComplete="current-password" /></Field>
            <Field label="New password" hint="8+ characters, letters and numbers"><input type="password" required minLength={8} value={pw.newPassword} onChange={(e) => setPw({ ...pw, newPassword: e.target.value })} autoComplete="new-password" /></Field>
            <ErrorBox error={err.pw} />
            <button type="submit" className="btn btn--ghost" disabled={busy === "pw"}>Update password</button>
          </form>

          <div className="panel">
            <h3>Privacy controls</h3>
            {user.role === "exhibitor" && (
              <label className="switch">
                <input type="checkbox" checked={pv.profilePublic !== false} onChange={(e) => privacy("profilePublic", e.target.checked)} />
                <span>Show my company in the public exhibitor directory</span>
              </label>
            )}
            <label className="switch">
              <input type="checkbox" checked={pv.allowMessages !== false} onChange={(e) => privacy("allowMessages", e.target.checked)} />
              <span>Allow new messages from other users</span>
            </label>
            <label className="switch">
              <input type="checkbox" checked={!!pv.marketingEmails} onChange={(e) => privacy("marketingEmails", e.target.checked)} />
              <span>Receive emails about new expos</span>
            </label>
            <ErrorBox error={err.privacy} />
            <div className="divider" />
            <h3>Your data</h3>
            <p className="muted">Download everything we store about you (GDPR data portability).</p>
            <button type="button" className="btn btn--ghost btn--sm" onClick={exportData} disabled={busy === "export"}>⤓ Export my data (JSON)</button>
            <ErrorBox error={err.export} />
          </div>

          <form className="panel panel--danger" onSubmit={deleteAccount}>
            <h3>Delete account</h3>
            <p className="muted">Permanently erase your account and personal data. This can't be undone.</p>
            <Field label="Confirm with your password"><input type="password" required value={delPw} onChange={(e) => setDelPw(e.target.value)} /></Field>
            <ErrorBox error={err.delete} />
            <button type="submit" className="btn btn--danger mt-sm" disabled={busy === "delete"}>Delete my account</button>
          </form>
        </div>
      </div>
    </>
  );
}
