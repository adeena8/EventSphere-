import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { PageHead, Spinner, Empty, Modal, Field, ErrorBox } from "../../components/ui/UI.jsx";
import { SessionCard } from "../../components/Cards.jsx";
import { useManagedExpos, useSelectedExpo, ExpoPicker } from "./shared.jsx";
import { useFetch } from "../../hooks/useFetch.js";
import { useSocketEvent, useExpoRoom } from "../../context/SocketContext.jsx";
import { useToast } from "../../context/ToastContext.jsx";
import { api } from "../../lib/api.js";
import { fmtDay, toLocalInput } from "../../lib/format.js";

const BLANK = { title: "", topic: "", type: "talk", description: "", location: "", startTime: "", endTime: "", capacity: 0, speakerName: "", speakerTitle: "", speakerBio: "", speakerPhoto: "" };

export default function ScheduleManager() {
  const expos = useManagedExpos();
  const [expoId, setExpoId] = useSelectedExpo(expos.data?.items);
  const sessions = useFetch(expoId ? `/expos/${expoId}/sessions` : null);
  const [editing, setEditing] = useState(null);
  const toast = useToast();
  const expo = expos.data?.items?.find((e) => e._id === expoId);

  useExpoRoom(expoId);
  useSocketEvent("schedule:updated", (p) => String(p.expoId) === expoId && sessions.reload());

  const days = useMemo(() => {
    const map = new Map();
    for (const s of sessions.data?.items || []) {
      const k = new Date(s.startTime).toDateString();
      if (!map.has(k)) map.set(k, []);
      map.get(k).push(s);
    }
    return [...map.values()];
  }, [sessions.data]);

  async function remove(s) {
    if (!window.confirm(`Delete “${s.title}”? Registered attendees will be notified.`)) return;
    try {
      await api.del(`/sessions/${s._id}`);
      toast.success("Session deleted");
      sessions.reload();
    } catch (e) {
      toast.error(e.message);
    }
  }

  return (
    <>
      <PageHead
        eyebrow="Schedule management"
        title="Sessions & speakers"
        actions={expoId && <button type="button" className="btn btn--gold" onClick={() => setEditing("new")}>+ Add session</button>}
      >
        Time slots, speakers, topics and rooms. Updates are pushed live and attendees get notified of changes.
      </PageHead>
      {!expos.data?.items?.length && !expos.loading ? (
        <Empty title="Create an expo first" icon="◉" action={<Link className="btn btn--gold" to="/dashboard/expos?new=1">New expo</Link>} />
      ) : (
        <>
          <div className="toolbar">
            <ExpoPicker expos={expos.data?.items || []} value={expoId} onChange={setExpoId} />
          </div>
          {sessions.loading && !sessions.data ? (
            <Spinner />
          ) : !days.length ? (
            <Empty title="No sessions yet" icon="◷" action={<button type="button" className="btn btn--gold" onClick={() => setEditing("new")}>Add the first session</button>} />
          ) : (
            days.map((list) => (
              <div key={list[0]._id} className="schedule__day">
                <h3 className="schedule__day-title">{fmtDay(list[0].startTime)}</h3>
                {list.map((s) => (
                  <div key={s._id} className="session-admin">
                    <SessionCard session={s} actions={false} />
                    <div className="session-admin__bar">
                      <span className="muted">
                        {s.registeredCount} registered · {s.bookmarkCount} bookmarked{s.capacity ? ` · capacity ${s.capacity}` : ""}
                      </span>
                      <div className="row-gap">
                        <button type="button" className="btn btn--ghost btn--sm" onClick={() => setEditing(s)}>Edit</button>
                        <button type="button" className="btn btn--danger btn--sm" onClick={() => remove(s)}>Delete</button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ))
          )}
        </>
      )}
      <SessionForm
        open={!!editing}
        session={editing === "new" ? null : editing}
        expo={expo}
        onClose={() => setEditing(null)}
        onSaved={() => {
          setEditing(null);
          sessions.reload();
        }}
      />
    </>
  );
}

function SessionForm({ open, session, expo, onClose, onSaved }) {
  const toast = useToast();
  const [f, setF] = useState(BLANK);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!open) return;
    setError(null);
    if (session) {
      setF({
        title: session.title, topic: session.topic || "", type: session.type, description: session.description || "",
        location: session.location || "", startTime: toLocalInput(session.startTime), endTime: toLocalInput(session.endTime),
        capacity: session.capacity || 0, speakerName: session.speaker?.name || "", speakerTitle: session.speaker?.title || "",
        speakerBio: session.speaker?.bio || "", speakerPhoto: session.speaker?.photo || "",
      });
    } else if (expo) {
      const d = new Date(expo.startDate);
      d.setHours(10, 0, 0, 0);
      setF({ ...BLANK, startTime: toLocalInput(d), endTime: toLocalInput(new Date(+d + 3600000)) });
    }
  }, [open, session, expo]);

  const set = (k) => (e) => setF((x) => ({ ...x, [k]: e.target.value }));

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    const body = {
      expo: expo._id,
      title: f.title,
      topic: f.topic,
      type: f.type,
      description: f.description,
      location: f.location,
      startTime: new Date(f.startTime),
      endTime: new Date(f.endTime),
      capacity: Number(f.capacity) || 0,
      speaker: { name: f.speakerName, title: f.speakerTitle, bio: f.speakerBio, photo: f.speakerPhoto },
    };
    try {
      if (session) await api.put(`/sessions/${session._id}`, body);
      else await api.post("/sessions", body);
      toast.success(session ? "Session updated — attendees notified of changes" : "Session added");
      onSaved();
    } catch (err) {
      setError(err);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal open={open} onClose={onClose} title={session ? "Edit session" : "New session"} wide>
      <form className="form-grid" onSubmit={submit}>
        <Field label="Title" full><input required value={f.title} onChange={set("title")} /></Field>
        <Field label="Type">
          <select value={f.type} onChange={set("type")}>
            {["keynote", "talk", "workshop", "panel", "networking"].map((t) => <option key={t} value={t}>{t}</option>)}
          </select>
        </Field>
        <Field label="Topic"><input value={f.topic} onChange={set("topic")} /></Field>
        <Field label="Starts"><input type="datetime-local" required value={f.startTime} onChange={set("startTime")} /></Field>
        <Field label="Ends"><input type="datetime-local" required value={f.endTime} min={f.startTime} onChange={set("endTime")} /></Field>
        <Field label="Location / room" hint="Double-booking a room is prevented"><input value={f.location} onChange={set("location")} /></Field>
        <Field label="Capacity" hint="0 = unlimited"><input type="number" min={0} value={f.capacity} onChange={set("capacity")} /></Field>
        <Field label="Description" full><textarea rows={3} value={f.description} onChange={set("description")} /></Field>
        <Field label="Speaker name"><input value={f.speakerName} onChange={set("speakerName")} /></Field>
        <Field label="Speaker title"><input value={f.speakerTitle} onChange={set("speakerTitle")} /></Field>
        <Field label="Speaker photo URL" full><input type="url" value={f.speakerPhoto} onChange={set("speakerPhoto")} /></Field>
        <Field label="Speaker bio" full><textarea rows={2} value={f.speakerBio} onChange={set("speakerBio")} /></Field>
        <ErrorBox error={error} />
        <div className="form-actions field--full">
          <button type="button" className="btn btn--ghost" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn--gold" disabled={busy}>{busy ? "Saving…" : "Save session"}</button>
        </div>
      </form>
    </Modal>
  );
}
