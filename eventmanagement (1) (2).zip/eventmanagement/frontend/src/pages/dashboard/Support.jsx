import { useState } from "react";
import { PageHead, Spinner, Field, ErrorBox, Badge, Empty } from "../../components/ui/UI.jsx";
import { useFetch } from "../../hooks/useFetch.js";
import { useToast } from "../../context/ToastContext.jsx";
import { api } from "../../lib/api.js";
import { timeAgo } from "../../lib/format.js";

export default function Support() {
  const toast = useToast();
  const mine = useFetch("/feedback/mine");
  const expos = useFetch("/expos", { limit: 50, when: "all" });
  const [f, setF] = useState({ type: "feedback", subject: "", message: "", rating: "", expo: "" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const set = (k) => (e) => setF((x) => ({ ...x, [k]: e.target.value }));

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api.post("/feedback", f);
      toast.success("Thanks! Our team will review it shortly.");
      setF({ type: "feedback", subject: "", message: "", rating: "", expo: "" });
      mine.reload();
    } catch (err) {
      setError(err);
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <PageHead eyebrow="Feedback & support" title="Support">
        Share a suggestion, rate an expo, or report a problem. Replies show up here and in your notifications.
      </PageHead>
      <div className="grid grid--2">
        <form className="panel form-grid form-grid--1" onSubmit={submit}>
          <Field label="Type">
            <select value={f.type} onChange={set("type")}>
              <option value="feedback">Feedback</option>
              <option value="suggestion">Suggestion</option>
              <option value="issue">Report an issue</option>
              <option value="inquiry">Question</option>
            </select>
          </Field>
          <Field label="Related expo (optional)">
            <select value={f.expo} onChange={set("expo")}>
              <option value="">—</option>
              {(expos.data?.items || []).map((e) => <option key={e._id} value={e._id}>{e.title}</option>)}
            </select>
          </Field>
          <Field label="Rating (optional)">
            <div className="stars" role="radiogroup" aria-label="Rating">
              {[1, 2, 3, 4, 5].map((n) => (
                <button key={n} type="button" role="radio" aria-checked={Number(f.rating) === n} className={Number(f.rating) >= n ? "is-on" : ""} onClick={() => setF((x) => ({ ...x, rating: x.rating === n ? "" : n }))}>
                  ★
                </button>
              ))}
            </div>
          </Field>
          <Field label="Subject"><input required value={f.subject} onChange={set("subject")} maxLength={160} /></Field>
          <Field label="Message"><textarea required rows={5} value={f.message} onChange={set("message")} /></Field>
          <ErrorBox error={error} />
          <button type="submit" className="btn btn--gold" disabled={busy}>{busy ? "Sending…" : "Submit"}</button>
        </form>
        <div className="panel">
          <h3>Your tickets</h3>
          {mine.loading && !mine.data ? <Spinner /> : !mine.data?.items?.length ? <Empty title="No submissions yet" icon="✉" /> : (
            <ul className="list list--stack">
              {mine.data.items.map((x) => (
                <li key={x._id}>
                  <div className="row-between">
                    <strong>{x.subject}</strong>
                    <Badge>{x.status}</Badge>
                  </div>
                  <span className="muted">{x.type} · {timeAgo(x.createdAt)}{x.expo?.title ? ` · ${x.expo.title}` : ""}</span>
                  {x.response && <p className="note">Reply: {x.response}</p>}
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </>
  );
}
