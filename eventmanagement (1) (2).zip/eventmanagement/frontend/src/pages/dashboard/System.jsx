import { useState } from "react";
import { PageHead, Spinner, StatCard, ErrorBox } from "../../components/ui/UI.jsx";
import { useFetch } from "../../hooks/useFetch.js";
import { useToast } from "../../context/ToastContext.jsx";
import { api } from "../../lib/api.js";
import { fmtDateTime } from "../../lib/format.js";

export default function System() {
  const toast = useToast();
  const sys = useFetch("/admin/system");
  const backups = useFetch("/admin/backups");
  const [action, setAction] = useState("");
  const activity = useFetch("/admin/activity", { action, limit: 200 });
  const [busy, setBusy] = useState(false);

  async function backupNow() {
    setBusy(true);
    try {
      const r = await api.post("/admin/backups");
      toast.success(`Backup saved: ${r.documents} documents in ${r.collections} collections`);
      backups.reload();
    } catch (e) {
      toast.error(e.message);
    } finally {
      setBusy(false);
    }
  }

  const s = sys.data;
  return (
    <>
      <PageHead eyebrow="Administration" title="System & backups">
        Monitoring, automated backups and an audit trail of user activity.
      </PageHead>
      <div className="stat-grid">
        <StatCard label="Uptime" value={s ? `${Math.floor(s.uptimeSeconds / 3600)}h ${Math.floor((s.uptimeSeconds % 3600) / 60)}m` : "—"} icon="⏱" />
        <StatCard label="Memory" value={s ? `${s.memoryMB} MB` : "—"} icon="▤" tone="teal" />
        <StatCard label="Online users" value={s?.onlineUsers ?? "—"} icon="●" />
        <StatCard label="Node.js" value={s?.node ?? "—"} icon="⬢" tone="wine" />
      </div>

      <div className="grid grid--2 mt">
        <div className="panel">
          <div className="row-between">
            <h3>Backups</h3>
            <button type="button" className="btn btn--gold btn--sm" onClick={backupNow} disabled={busy}>{busy ? "Backing up…" : "Back up now"}</button>
          </div>
          <p className="muted">Automatic daily backups (configurable with BACKUP_CRON). Restore with <code>npm run restore -- &lt;folder&gt;</code>.</p>
          {backups.loading ? <Spinner /> : (
            <ul className="list">
              {(backups.data?.items || []).map((b) => <li key={b}><code>{b}</code></li>)}
              {!backups.data?.items?.length && <li className="muted">No backups yet.</li>}
            </ul>
          )}
        </div>
        <div className="panel">
          <h3>Logs</h3>
          <p className="muted">Request and error logs are written daily to <code>backend/logs/app-YYYY-MM-DD.log</code> and <code>error-YYYY-MM-DD.log</code>. Requests slower than 2s are flagged automatically. Every API response carries an <code>X-Response-Time</code> header.</p>
        </div>
      </div>

      <div className="panel mt">
        <div className="row-between">
          <h3>Activity log</h3>
          <select value={action} onChange={(e) => setAction(e.target.value)} aria-label="Filter actions">
            <option value="">All actions</option>
            {["login", "register", "expo", "booth", "application", "session", "user", "password", "backup", "broadcast"].map((a) => <option key={a}>{a}</option>)}
          </select>
        </div>
        <ErrorBox error={activity.error} />
        {activity.loading && !activity.data ? <Spinner /> : (
          <div className="table-wrap" data-lenis-prevent>
            <table className="table">
              <thead><tr><th>When</th><th>User</th><th>Action</th><th>Entity</th><th>IP</th></tr></thead>
              <tbody>
                {(activity.data?.items || []).map((a) => (
                  <tr key={a._id}>
                    <td>{fmtDateTime(a.createdAt)}</td>
                    <td>{a.user ? `${a.user.name} (${a.user.role})` : "—"}</td>
                    <td><code>{a.action}</code></td>
                    <td>{a.entity || ""}</td>
                    <td className="muted">{a.ip || ""}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </>
  );
}
