import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { PageHead, Spinner, Empty } from "../../components/ui/UI.jsx";
import { useFetch } from "../../hooks/useFetch.js";
import { useToast } from "../../context/ToastContext.jsx";
import { api } from "../../lib/api.js";
import { fmtRange, fmtDateTime } from "../../lib/format.js";

export default function Tickets() {
  const { data, loading, reload } = useFetch("/registrations/mine");
  const toast = useToast();
  const items = data?.items || [];

  async function cancel(t) {
    if (!window.confirm(`Cancel your ticket for ${t.expo.title}?`)) return;
    try {
      await api.del(`/expos/${t.expo._id}/register`);
      toast.info("Ticket cancelled");
      reload();
    } catch (e) {
      toast.error(e.message);
    }
  }

  return (
    <>
      <PageHead eyebrow="Attendee" title="My tickets">
        Show the QR code (or the code underneath) at the entrance.
      </PageHead>
      {loading && !data ? (
        <Spinner />
      ) : !items.length ? (
        <Empty title="No tickets yet" icon="⌁" action={<Link to="/expos" className="btn btn--gold">Find an expo</Link>} />
      ) : (
        <div className="tickets">
          {items.map((t, i) => {
            const past = new Date(t.expo.endDate) < new Date();
            return (
              <motion.article
                key={t._id}
                className={`ticket ${past ? "is-past" : ""}`}
                initial={{ opacity: 0, y: 30, rotateX: -12 }}
                animate={{ opacity: 1, y: 0, rotateX: 0 }}
                transition={{ delay: i * 0.08, duration: 0.6 }}
              >
                <div className="ticket__main">
                  <p className="eyebrow">Admit one</p>
                  <h3>{t.expo.title}</h3>
                  <p>{fmtRange(t.expo.startDate, t.expo.endDate)}</p>
                  <p className="muted">{[t.expo.location?.venue, t.expo.location?.city].filter(Boolean).join(", ")}</p>
                  <div className="row-gap mt-sm">
                    <Link to={`/expos/${t.expo._id}?tab=schedule`} className="btn btn--ghost btn--sm">Schedule</Link>
                    {!past && <button type="button" className="btn btn--plain btn--sm" onClick={() => cancel(t)}>Cancel</button>}
                  </div>
                  {t.checkedIn && <p className="gold mt-sm">✓ Checked in {fmtDateTime(t.checkedInAt)}</p>}
                </div>
                <div className="ticket__stub">
                  <img src={t.qr} alt={`QR code for ticket ${t.ticketCode}`} />
                  <code>{t.ticketCode}</code>
                </div>
              </motion.article>
            );
          })}
        </div>
      )}
    </>
  );
}
