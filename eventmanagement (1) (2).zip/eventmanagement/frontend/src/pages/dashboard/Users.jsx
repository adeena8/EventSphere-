import { useState } from "react";
import { Link } from "react-router-dom";
import { PageHead, Spinner, Empty, Badge, Avatar, ErrorBox } from "../../components/ui/UI.jsx";
import { useFetch, useDebounced } from "../../hooks/useFetch.js";
import { useAuth } from "../../context/AuthContext.jsx";
import { useToast } from "../../context/ToastContext.jsx";
import { api } from "../../lib/api.js";
import { fmtDate } from "../../lib/format.js";

export default function Users() {
  const { user: me } = useAuth();
  const toast = useToast();
  const [q, setQ] = useState("");
  const [role, setRole] = useState("");
  const [status, setStatus] = useState("");
  const dq = useDebounced(q);
  const { data, loading, error, reload } = useFetch("/admin/users", { q: dq, role, status });

  async function update(u, body, msg) {
    try {
      await api.patch(`/admin/users/${u._id}`, body);
      toast.success(msg);
      reload();
    } catch (e) {
      toast.error(e.message);
    }
  }
  async function remove(u) {
    if (!window.confirm(`Permanently delete ${u.name} (${u.email}) and their personal data?`)) return;
    try {
      await api.del(`/admin/users/${u._id}`);
      toast.success("User deleted");
      reload();
    } catch (e) {
      toast.error(e.message);
    }
  }

  const items = data?.items || [];
  const pending = items.filter((u) => u.status === "pending").length;

  return (
    <>
      <PageHead eyebrow="Administration" title="Users">
        Approve organizers, change roles, suspend or remove accounts.
      </PageHead>
      <div className="toolbar">
        <input type="search" placeholder="Search name, email, company" value={q} onChange={(e) => setQ(e.target.value)} className="search-sm" />
        <select value={role} onChange={(e) => setRole(e.target.value)} aria-label="Role">
          <option value="">All roles</option>
          {["admin", "organizer", "exhibitor", "attendee"].map((r) => <option key={r}>{r}</option>)}
        </select>
        <select value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Status">
          <option value="">Any status</option>
          {["active", "pending", "suspended"].map((r) => <option key={r}>{r}</option>)}
        </select>
        {pending > 0 && <span className="chip chip--gold">{pending} awaiting approval</span>}
      </div>
      <ErrorBox error={error} onRetry={reload} />
      {loading && !data ? (
        <Spinner />
      ) : !items.length ? (
        <Empty title="No users found" icon="☺" />
      ) : (
        <div className="table-wrap" data-lenis-prevent>
          <table className="table">
            <thead>
              <tr><th>User</th><th>Role</th><th>Status</th><th>Joined</th><th>Last login</th><th /></tr>
            </thead>
            <tbody>
              {items.map((u) => (
                <tr key={u._id}>
                  <td>
                    <div className="speaker">
                      <Avatar src={u.avatar} name={u.name} size={34} />
                      <div>
                        <strong>{u.name} {u.online && <i className="live-dot is-on" title="online" />}</strong>
                        <span>{u.email}{u.company?.name ? ` · ${u.company.name}` : ""}</span>
                      </div>
                    </div>
                  </td>
                  <td>
                    <select value={u.role} disabled={u._id === me._id} onChange={(e) => update(u, { role: e.target.value }, `Role changed to ${e.target.value}`)} aria-label="Role">
                      {["admin", "organizer", "exhibitor", "attendee"].map((r) => <option key={r}>{r}</option>)}
                    </select>
                  </td>
                  <td><Badge>{u.status}</Badge></td>
                  <td>{fmtDate(u.createdAt)}</td>
                  <td>{u.lastLoginAt ? fmtDate(u.lastLoginAt) : "—"}</td>
                  <td>
                    {u._id !== me._id && (
                      <div className="row-gap">
                        {u.status === "pending" && <button type="button" className="btn btn--gold btn--sm" onClick={() => update(u, { status: "active" }, "Organizer approved")}>Approve</button>}
                        {u.status === "active" && <button type="button" className="btn btn--ghost btn--sm" onClick={() => update(u, { status: "suspended" }, "User suspended")}>Suspend</button>}
                        {u.status === "suspended" && <button type="button" className="btn btn--ghost btn--sm" onClick={() => update(u, { status: "active" }, "User reactivated")}>Reactivate</button>}
                        <Link to={`/dashboard/messages/${u._id}`} className="btn btn--plain btn--sm">Message</Link>
                        <button type="button" className="btn btn--danger btn--sm" onClick={() => remove(u)}>Delete</button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}
