import { useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { useFetch } from "../../hooks/useFetch.js";
import { useSocketEvent } from "../../context/SocketContext.jsx";

/** Expos the current staff member can manage (organizer → own, admin → all) */
export function useManagedExpos() {
  const q = useFetch("/expos", { mine: 1, limit: 50 });
  useSocketEvent("expo:updated", () => q.reload());
  return q;
}

/** Expo selector bound to ?expo= in the URL */
export function useSelectedExpo(expos) {
  const [params, setParams] = useSearchParams();
  const selected = params.get("expo") || "";
  useEffect(() => {
    if (!selected && expos?.length) {
      const upcoming = expos.find((e) => new Date(e.endDate) >= new Date()) || expos[0];
      const n = new URLSearchParams(params);
      n.set("expo", upcoming._id);
      setParams(n, { replace: true });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [expos, selected]);
  const setSelected = (id) => {
    const n = new URLSearchParams(params);
    if (id) n.set("expo", id);
    else n.delete("expo");
    setParams(n, { replace: true });
  };
  return [selected, setSelected];
}

export function ExpoPicker({ expos = [], value, onChange, allowAll = false }) {
  return (
    <select className="expo-picker" value={value} onChange={(e) => onChange(e.target.value)} aria-label="Select expo">
      {allowAll && <option value="">All my expos</option>}
      {expos.map((e) => (
        <option key={e._id} value={e._id}>
          {e.title} {e.status !== "published" ? `(${e.status})` : ""}
        </option>
      ))}
    </select>
  );
}
